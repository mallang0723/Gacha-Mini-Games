// Generated from upstream v1.3.1; see README.md and NOTICE.
/* Gacha Mini Games v1.3.1 — personal extension for Gacha Forge on Marinara Engine.
 * While a chapter or story is being generated, the generation screen gets a column of small games on its right:
 * 지뢰찾기, 사과 상자 (the fruit follows the 말랑 colour preset), 2048, 짝 맞추기, 쿠키 가게, 디저트 핀볼 and more. Closing the column or
 * finishing generation removes them; nothing here touches the run, rewards or the generation request.
 * Split out of Gacha UI Style · 말랑 (1.12.0). Works on its own; with 말랑 on it takes 말랑's colours, preset and
 * SD sprites. Best records live in this browser only. */
(() => {
  "use strict";
  // Local resources include inherited game timers/frames: no global monkey patches.
  function resources() {
    const controller = new AbortController(), timeouts = new Set(), intervals = new Set(), frames = new Set();
    let closed = false;
    return {
      signal: controller.signal,
      setTimeout(fn, ms, ...args) {
        if (closed) return 0;
        const id = window.setTimeout(() => { timeouts.delete(id); if (!closed) fn(...args); }, ms);
        timeouts.add(id); return id;
      },
      clearTimeout(id) { window.clearTimeout(id); timeouts.delete(id); },
      setInterval(fn, ms, ...args) {
        if (closed) return 0;
        const id = window.setInterval(() => { if (!closed) fn(...args); }, ms); intervals.add(id); return id;
      },
      clearInterval(id) { window.clearInterval(id); intervals.delete(id); },
      requestAnimationFrame(fn) {
        if (closed) return 0;
        const id = window.requestAnimationFrame(t => { frames.delete(id); if (!closed) fn(t); }); frames.add(id); return id;
      },
      cancelAnimationFrame(id) { window.cancelAnimationFrame(id); frames.delete(id); },
      clearTimers() {
        timeouts.forEach(id => window.clearTimeout(id)); timeouts.clear();
        intervals.forEach(id => window.clearInterval(id)); intervals.clear();
        frames.forEach(id => window.cancelAnimationFrame(id)); frames.clear();
      },
      dispose() { closed = true; controller.abort(); this.clearTimers(); },
    };
  }
  const APP_KEY = 'gacha_minigames_me';
  window[APP_KEY]?.dispose?.();
  const lifetime = resources();
  const { setTimeout, clearTimeout, setInterval, clearInterval, requestAnimationFrame, cancelAnimationFrame } = lifetime;
  function focusedElement() {
    let active = document.activeElement;
    while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
    return active;
  }
  const editable = node => !!node?.closest?.('textarea,input,select,[contenteditable]:not([contenteditable="false"])');
  function gameKeyAllowed(event, target) {
    const panel = target.closest?.('.gfx-load-games');
    const active = focusedElement();
    return !!panel && panel.isConnected && !panel.closest('[hidden]') && panel.contains(active)
      && !editable(active) && !event.composedPath().some(editable);
  }
  function listen(scope, target, type, fn, opts = {}) {
    target.addEventListener(type, event => {
      if ((type === 'keydown' || type === 'keyup') && !gameKeyAllowed(event, target)) return;
      fn(event);
    }, { ...opts, signal: scope.signal });
  }
  // Keep shared SD images only when already in memory. External URLs must never trigger a request.
  const safeFace = value => typeof value === 'string' && (
    /^data:image\/(png|jpeg|gif|webp);base64,/i.test(value) || value.startsWith(`blob:${location.origin}/`)
  );

  const KEY = "__GF_MINIGAMES_EXTENSION";
  const HOST_TAG = "marinara-capability-gacha-forge";
  const MARINARA = typeof marinara !== "undefined" && marinara ? marinara : null;
  const life = new AbortController();
  const on = (target, type, fn, opts = {}) => listen(life, target, type, fn, opts);
  const el = (tag, cls = "", text = "") => { const n = document.createElement(tag); if (cls) n.className = cls; if (text) n.textContent = text; return n; };
  let disposed = false;

  /* Loading games: local UI state only; never touch the run, rewards or generation request. */
  function newMineGame(random = Math.random, difficulty = "easy") {
    const [cols, mines] = ({ easy: [8, 10], normal: [10, 18], hard: [12, 30] })[difficulty] || [8, 10];
    const cells = Array.from({ length: cols * cols }, () => ({ mine: false, open: false, flag: false, count: 0 }));
    const game = { cells, cols, rows: cols, mines, started: false, ended: false, won: false, boom: -1 };
    const neighbours = (i) => cells.map((_, j) => j).filter((j) => j !== i && Math.abs(j % cols - i % cols) <= 1 && Math.abs(Math.floor(j / cols) - Math.floor(i / cols)) <= 1);
    game.neighbours = neighbours;
    game.flag = (i) => { if (!game.ended && !cells[i].open) cells[i].flag = !cells[i].flag; };
    game.reveal = (i) => {
      if (game.ended || cells[i].flag || cells[i].open) return;
      if (!game.started) {
        const safe = new Set([i, ...neighbours(i)]), pool = cells.map((_, j) => j).filter((j) => !safe.has(j));
        for (let k = 0; k < mines; k++) { const at = k + Math.floor(random() * (pool.length - k)); [pool[k], pool[at]] = [pool[at], pool[k]]; cells[pool[k]].mine = true; }
        cells.forEach((c, j) => c.count = neighbours(j).filter((n) => cells[n].mine).length);
        game.started = true;
      }
      if (cells[i].mine) { cells[i].open = true; game.ended = true; game.boom = i; return; }
      const queue = [i];
      while (queue.length) { const j = queue.pop(), c = cells[j]; if (c.open || c.flag || c.mine) continue; c.open = true; if (!c.count) queue.push(...neighbours(j)); }
      if (cells.filter((c) => c.open).length === cells.length - mines) { game.ended = true; game.won = true; }
    };
    // Pressing an opened number whose flags are all placed opens the rest around it (as in the classic game).
    game.chord = (i) => {
      const c = cells[i];
      if (game.ended || !c.open || !c.count) return;
      const around = neighbours(i);
      if (around.filter((j) => cells[j].flag).length !== c.count) return;
      for (const j of around) { game.reveal(j); if (game.ended) return; }
    };
    return game;
  }
  function newFruitGame(random = Math.random, difficulty = "normal") {
    const [cols, rows, max, time] = ({ easy: [8, 6, 5, 180], normal: [10, 8, 9, 120], hard: [12, 10, 9, 90] })[difficulty] || [10, 8, 9, 120];
    const game = { cols, rows, time, cells: Array.from({ length: cols * rows }, () => 1 + Math.floor(random() * max)), score: 0, ended: false };
    game.cells[0] = max === 5 ? 5 : 1; game.cells[1] = 10 - game.cells[0]; // Every new board has at least one legal selection.
    game.select = (a, b, remove = false) => {
      const x0 = Math.min(a % cols, b % cols), x1 = Math.max(a % cols, b % cols), y0 = Math.min(Math.floor(a / cols), Math.floor(b / cols)), y1 = Math.max(Math.floor(a / cols), Math.floor(b / cols));
      const ids = game.cells.map((_, i) => i).filter((i) => i % cols >= x0 && i % cols <= x1 && Math.floor(i / cols) >= y0 && Math.floor(i / cols) <= y1);
      const sum = ids.reduce((n, i) => n + game.cells[i], 0);
      if (remove && sum === 10 && !game.ended) { game.score += ids.filter((i) => game.cells[i]).length; ids.forEach((i) => game.cells[i] = 0); }
      return { ids, sum };
    };
    // A rectangle that still sums to 10 (for the hint, and to end a board with nothing left to clear).
    game.findMove = () => {
      const sum = (x0, y0, x1, y1) => { let n = 0; for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) n += game.cells[y * cols + x]; return n; };
      for (let y0 = 0; y0 < rows; y0++) for (let x0 = 0; x0 < cols; x0++) for (let y1 = y0; y1 < rows; y1++) {
        if (sum(x0, y0, x0, y1) > 10) break;
        for (let x1 = x0; x1 < cols; x1++) { const s = sum(x0, y0, x1, y1); if (s === 10) return { a: y0 * cols + x0, b: y1 * cols + x1 }; if (s > 10) break; }
      }
      return null;
    };
    return game;
  }
  function new2048Game(random = Math.random, difficulty = "normal") {
    const [size, goal] = ({ easy: [5, 2048], normal: [4, 2048], hard: [3, 256] })[difficulty] || [4, 2048];
    const cells = Array(size * size).fill(0);
    const game = { size, cols: size, goal, cells, score: 0, ended: false, won: false, fresh: -1, merged: [] };
    const spawn = () => {
      const empty = cells.map((v, i) => v ? -1 : i).filter((i) => i >= 0);
      if (!empty.length) { game.fresh = -1; return; }
      const i = empty[Math.floor(random() * empty.length)];
      cells[i] = random() < 0.9 ? 2 : 4; game.fresh = i;
    };
    // The cells of one row or column, listed from the side the tiles slide towards.
    const line = (k, dir) => Array.from({ length: size }, (_, i) => dir === "left" ? k * size + i : dir === "right" ? k * size + size - 1 - i : dir === "up" ? i * size + k : (size - 1 - i) * size + k);
    game.canMove = () => cells.some((v, i) => !v || (i % size < size - 1 && cells[i + 1] === v) || (i + size < cells.length && cells[i + size] === v));
    game.move = (dir) => {
      if (game.ended) return false;
      let moved = false; game.merged = [];
      for (let k = 0; k < size; k++) {
        const idx = line(k, dir), vals = idx.map((i) => cells[i]).filter(Boolean), out = [], merged = [];
        for (let j = 0; j < vals.length; j++) {
          if (j + 1 < vals.length && vals[j] === vals[j + 1]) { const v = vals[j] * 2; out.push(v); merged.push(out.length - 1); game.score += v; if (v >= goal) game.won = true; j++; }
          else out.push(vals[j]);
        }
        idx.forEach((i, p) => { const v = out[p] || 0; if (cells[i] !== v) moved = true; cells[i] = v; });
        game.merged.push(...merged.map((p) => idx[p]));
      }
      if (moved) spawn(); else game.fresh = -1;
      if (!game.canMove()) game.ended = true;
      return moved;
    };
    spawn(); spawn();
    return game;
  }
  const MEMORY_SYMBOLS = ["🍎", "🍋", "🍇", "🍓", "🍑", "🍒", "🥝", "🍍", "🍉", "🍊", "🫐", "🥥"];
  function newMemoryGame(random = Math.random, difficulty = "easy", faces = []) {
    const [cols, pairs] = ({ easy: [4, 6], normal: [4, 8], hard: [6, 12] })[difficulty] || [4, 6];
    const shuffle = (list) => { const a = list.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
    // The world's own SD characters are the cards; fruit fills in when there are fewer of them than pairs.
    const pool = [...shuffle([...new Set(faces)]).slice(0, pairs), ...MEMORY_SYMBOLS].slice(0, pairs);
    const cells = shuffle([...pool, ...pool]).map((face) => ({ face, open: false, done: false }));
    const game = { cols, rows: cells.length / cols, pairs, cells, moves: 0, ended: false, won: false };
    game.flip = (i) => {
      const c = cells[i];
      if (game.ended || c.open || c.done) return "ignored";
      const up = cells.map((x, j) => x.open && !x.done ? j : -1).filter((j) => j >= 0);
      if (up.length >= 2) return "busy";
      c.open = true;
      if (!up.length) return "open";
      game.moves++;
      const other = cells[up[0]];
      if (other.face !== c.face) return "miss";
      other.done = c.done = true;
      if (cells.every((x) => x.done)) game.ended = game.won = true;
      return "match";
    };
    game.hide = () => cells.forEach((x) => { if (x.open && !x.done) x.open = false; });
    return game;
  }
  /* More games: 쿠키 가게, 디저트 핀볼, 비스킷 벽돌깨기, 스네이크, 딸기 우유 레시피, 초코칩 터뜨리기, 꽃밭 퍼즐, 별 밝히기. */
  // 쿠키 가게, in the manner of 슈의 라면집. Guests queue at the counter (three at most), each with an order — plain,
  // chocolate chip, cream or both — and a patience that runs out. An oven goes: butter the tray → light it → wait for
  // the preheat lamp → dough → sugar → bake. While the cookie is golden (it steams), top it as ordered, then plate it:
  // the guest who ordered that cookie takes it (else whoever waited longest) and pays by how it was made (game.judge),
  // plus a tip when it came quickly. A lit oven left too long — empty or not — burns: clearing it uses one of three
  // spares, and with no spare left that oven is gone. A guest who gives up costs a heart. Reach the day's goal to win;
  // run out of hearts or ovens and the shop closes. Time is passed in (now), so the game can be paused by shifting it.
  const SHOP_TOOLS = [["butter", "버터"], ["fire", "불 켜기"], ["dough", "반죽"], ["sugar", "설탕"], ["chip", "초코칩"], ["cream", "크림"], ["serve", "접시"]];
  const SHOP_ORDERS = { plain: "플레인", chip: "초코칩", cream: "크림", both: "스페셜" };
  function newShopGame(random = Math.random, difficulty = "normal") {
    // preheat, bake, golden, over, empty oven burns after, goal, a guest every, patience, hearts
    const [heat, bake, ready, over, empty, goal, every, patience, hearts] = ({
      easy: [1500, 5000, 4500, 3500, 9000, 6000, 9000, 34000, 5],
      normal: [1500, 4000, 3500, 2500, 7000, 10000, 7000, 26000, 4],
      hard: [1200, 3500, 2600, 2000, 5500, 15000, 5500, 20000, 3],
    })[difficulty] || [1500, 4000, 3500, 2500, 7000, 10000, 7000, 26000, 4];
    const fresh = () => ({ butter: false, lit: null, dough: null, flat: false, sugar: false, chip: "", cream: "" });
    const game = { heat, bake, ready, over, empty, goal, patience, hearts, ovens: [fresh(), fresh(), fresh(), fresh()], spares: 3, money: 0, tips: 0, served: 0, perfect: 0, left: 0,
      queue: [], guests: 0, next: 0, opened: null, ended: false, won: false, last: null };
    // cold → heat (preheating) → hot (ready for dough) → burnt; with dough: raw → ready (golden) → over → burnt.
    game.stage = (o, now) => {
      if (o === null) return "gone";
      if (o.lit == null) return "";
      if (o.dough == null) { const t = now - o.lit; return t < heat ? "heat" : t < empty ? "hot" : "burnt"; }
      const t = now - Math.max(o.dough, o.lit);
      return t < bake ? "raw" : t < bake + ready ? "ready" : t < bake + ready + over ? "over" : "burnt";
    };
    // How far the oven's dial has turned, 0–1: the bake once there is dough, else how close the empty oven is to burning.
    game.dial = (o, now) => !o || o.lit == null ? 0 : Math.min(1, o.dough == null ? (now - o.lit) / empty : (now - Math.max(o.dough, o.lit)) / (bake + ready + over));
    const lost = (o) => o === null;
    const want = () => ["plain", "chip", "cream", "both"][Math.floor(random() * 4)];
    game.open = (now) => { if (game.opened != null) return; game.opened = now; game.next = now; game.update(now); };
    // Guests come and go with the clock.
    game.update = (now) => {
      if (game.ended || game.opened == null) return;
      for (const g of game.queue.slice()) {
        if (now - g.came < patience) continue;
        game.queue.splice(game.queue.indexOf(g), 1); game.left++; game.hearts--;
        game.last = { line: "너무 오래 기다렸어… 갈래!", price: null, gone: true, guest: g.id, want: g.want };
      }
      if (game.hearts <= 0) { game.ended = true; return; }
      if (!game.queue.length) game.next = Math.min(game.next, now + 1500);
      if (game.queue.length < 3 && now >= game.next) { game.queue.push({ id: game.guests++, want: want(), came: now }); game.next = now + every * (0.75 + random() * 0.5); }
    };
    game.shift = (dt) => {
      for (const o of game.ovens) if (o) { if (o.lit != null) o.lit += dt; if (o.dough != null) o.dough += dt; }
      for (const g of game.queue) g.came += dt;
      game.next += dt; if (game.opened != null) game.opened += dt;
    };
    game.use = (tool, i, now) => {
      const o = game.ovens[i];
      if (game.ended || lost(o)) return "";
      const st = game.stage(o, now);
      if (st === "burnt") {
        // A burnt oven is cleared with a spare, or gone for good.
        if (game.spares > 0) { game.spares--; game.ovens[i] = fresh(); return "cleared"; }
        game.ovens[i] = null;
        if (game.ovens.every(lost)) game.ended = true;
        return "gone";
      }
      if (tool === "butter") { if (o.butter || o.dough != null) return ""; o.butter = true; return "butter"; }
      if (tool === "fire") { if (o.lit != null) return ""; o.lit = now; return "fire"; }
      // Dough in a cold or still-heating oven bakes flat.
      if (tool === "dough") { if (o.dough != null) return ""; o.dough = now; o.flat = !(o.lit != null && now - o.lit >= heat); return "dough"; }
      if (tool === "sugar") { if (o.sugar || o.dough == null) return ""; o.sugar = true; return "sugar"; }
      if (tool === "chip" || tool === "cream") { if (o[tool] || o.dough == null || o.lit == null) return ""; o[tool] = st === "ready" ? "ontime" : st === "raw" ? "early" : "late"; return tool; }
      if (tool === "serve") {
        if (o.dough == null) return "";
        if (!game.queue.length) return "nobody";
        const kind = game.kind(o), guest = game.queue.find((g) => g.want === kind) || game.queue[0];
        const r = game.judge(o, st, guest.want, now - guest.came);
        game.queue.splice(game.queue.indexOf(guest), 1);
        game.money += r.price; game.tips += r.tip; game.served++; if (r.perfect) game.perfect++;
        game.last = { ...r, guest: guest.id, want: guest.want, oven: i };
        game.ovens[i] = fresh();
        if (game.money >= goal) game.ended = game.won = true;
        return "served";
      }
      return "";
    };
    game.kind = (o) => o.chip && o.cream ? "both" : o.chip ? "chip" : o.cream ? "cream" : "plain";
    // The price: 1,000 for a golden cookie made right, less for each slip; the worst slip is what the guest says.
    game.judge = (o, st, order, waited) => {
      if (o.lit == null) return { price: 0, tip: 0, perfect: false, line: "이건 그냥 반죽이잖아!" };
      const slips = [];
      if (st === "raw") slips.push([700, "덜 익었잖아!"]);
      if (st === "over") slips.push([400, "좀 딱딱한데?"]);
      if (!o.butter) slips.push([200, "바닥이 눌어붙었어."]);
      if (o.flat) slips.push([200, "납작하네… 예열은 했어?"]);
      if (!o.sugar) slips.push([300, "하나도 안 달아!"]);
      for (const [k, name] of [["chip", "초코칩"], ["cream", "크림"]]) {
        const wanted = order === k || order === "both";
        if (wanted && !o[k]) slips.push([250, name + "이 없잖아!"]);
        else if (!wanted && o[k]) slips.push([150, name + "은 안 시켰는데?"]);
        else if (o[k] === "early") slips.push([100, name + "이 녹아 버렸어."]);
        else if (o[k] === "late") slips.push([150, name + "을 너무 늦게 올렸네."]);
      }
      const price = Math.max(0, 1000 - slips.reduce((n, [loss]) => n + loss, 0));
      const tip = price >= 800 && waited < patience * 0.45 ? 200 : 0;
      slips.sort((a, b) => b[0] - a[0]);
      return { price: price + tip, tip, perfect: !slips.length, line: slips.length ? slips[0][1] : tip ? "빨리 나왔네! 아주 맛있어~!" : "아주 맛있어~!" };
    };
    return game;
  }
  // 디저트 핀볼: hold the launcher, then keep the ball up with the two flippers. Bumpers (100) and the slingshots above
  // the flippers (10) score; rolling over all three top lanes gives 500 and raises the multiplier (up to ×5, back to ×1
  // with each lost ball). A flipper press shifts the lit lanes. A ball lost within the ball-save time comes back, once.
  // step(ms) runs the physics in fixed 1/400 s steps, so it plays the same at any frame rate.
  function newPinballGame(random = Math.random, difficulty = "normal") {
    const [gravity, balls, len, save] = ({ easy: [560, 5, 50, 10000], normal: [680, 3, 46, 5000], hard: [800, 3, 42, 0] })[difficulty] || [680, 3, 46, 5000];
    const W = 320, H = 520, R = 7, LANE = 286, cx = 149;
    // The table's rim: the left wall, an elliptic roof, the outer right wall.
    const rim = [[12, 470], [12, 90]];
    for (let k = 1; k < 24; k++) { const a = Math.PI + Math.PI * k / 24; rim.push([160 + 148 * Math.cos(a), 90 + 80 * Math.sin(a)]); }
    rim.push([308, 90], [308, 510]);
    const walls = [];
    for (let k = 1; k < rim.length; k++) walls.push([...rim[k - 1], ...rim[k]]);
    walls.push([LANE, 510, LANE, 150], [LANE, 490, 308, 490], // the launch lane and the plunger
      [12, 392, 90, 447], [LANE, 392, 208, 447], // the inlane guides down to the flippers
      [40, 330, 40, 372], [40, 372, 78, 398], [258, 330, 258, 372], [258, 372, 220, 398], // the slingshots' backs
      [130, 50, 130, 84], [170, 50, 170, 84], [90, 54, 90, 84], [210, 54, 210, 84]); // the top lane posts
    const slings = [[40, 330, 78, 398], [258, 330, 220, 398]].map((s) => ({ s, flash: 0 }));
    const gate = [LANE, 150, LANE, 96];
    const flipper = (side) => ({ side, x: side < 0 ? cx - 56 : cx + 56, y: 455, len, rest: side < 0 ? 0.5 : Math.PI - 0.5, up: side < 0 ? -0.45 : Math.PI + 0.45, a: 0, w: 0, held: false });
    const flippers = [flipper(-1), flipper(1)];
    flippers.forEach((f) => { f.a = f.rest; });
    const bumpers = [[110, 170, 16], [190, 170, 16], [150, 236, 18]].map(([x, y, r]) => ({ x, y, r, flash: 0 }));
    const lanes = [110, 150, 190].map((x) => ({ x, y: 70, lit: false }));
    const game = { W, H, R, LANE, cx, rim, walls, slings, gate, flippers, bumpers, lanes, gravity, save, balls, score: 0, mult: 1, top: 1, ball: null, charge: 0, pulling: false,
      launched: 0, saved: false, clock: 0, popups: [], note: null, ended: false, won: false };
    // A new ball (or a saved one, which keeps its ball save used up) waits on the plunger.
    const toLane = (saved = false) => { game.ball = { x: 297, y: 490 - R - 0.5, vx: 0, vy: 0, lane: true }; game.charge = 0; game.pulling = false; game.launched = 0; game.saved = saved; };
    toLane();
    const add = (n, x, y) => { const v = n * game.mult; game.score += v; game.popups.push({ text: "+" + v, x, y, t: 0 }); };
    game.press = (side, down) => {
      const f = flippers[side < 0 ? 0 : 1];
      if (down && !f.held && !game.ended) { const lit = lanes.map((l) => l.lit); lanes.forEach((l, k) => { l.lit = lit[(k + (side < 0 ? 1 : 2)) % 3]; }); }
      f.held = down;
    };
    game.pull = (down) => {
      const b = game.ball;
      if (down) { if (b.lane && b.y > 460 && !game.ended) game.pulling = true; return; }
      if (!game.pulling) return;
      game.pulling = false;
      // Even a tap clears the lane; holding longer shoots harder.
      if (b.lane && b.y > 460) { b.vy = -(Math.sqrt(2 * gravity * 440) + 420 * game.charge); if (!game.launched) game.launched = game.clock; }
      game.charge = 0;
    };
    // Push the ball out of a segment of half-thickness t; e is the bounce, (sx, sy) the surface's own velocity.
    const hitSegment = (b, x1, y1, x2, y2, t, e, sx = 0, sy = 0) => {
      const dx = x2 - x1, dy = y2 - y1, l2 = dx * dx + dy * dy;
      const k = Math.max(0, Math.min(1, ((b.x - x1) * dx + (b.y - y1) * dy) / l2));
      const px = x1 + k * dx, py = y1 + k * dy;
      let nx = b.x - px, ny = b.y - py; const d = Math.hypot(nx, ny);
      if (d >= R + t || d === 0) return null;
      nx /= d; ny /= d;
      b.x = px + nx * (R + t); b.y = py + ny * (R + t);
      const vn = (b.vx - sx) * nx + (b.vy - sy) * ny;
      if (vn < 0) { b.vx -= (1 + e) * vn * nx; b.vy -= (1 + e) * vn * ny; }
      return { nx, ny, px, py };
    };
    const tick = (dt) => {
      const b = game.ball;
      game.clock += dt * 1000;
      if (game.pulling) game.charge = Math.min(1, game.charge + dt);
      for (const f of flippers) {
        const target = f.held ? f.up : f.rest, speed = (f.held ? 20 : 11) * dt, before = f.a;
        f.a = Math.abs(target - f.a) <= speed ? target : f.a + Math.sign(target - f.a) * speed;
        f.w = (f.a - before) / dt;
      }
      b.vy += gravity * dt;
      const v = Math.hypot(b.vx, b.vy);
      if (v > 1100) { b.vx *= 1100 / v; b.vy *= 1100 / v; }
      b.x += b.vx * dt; b.y += b.vy * dt;
      b.lane = b.x > LANE;
      for (const s of walls) hitSegment(b, ...s, 3, 0.45);
      if (!b.lane) hitSegment(b, ...gate, 3, 0.45);
      for (const sl of slings) {
        const h = hitSegment(b, ...sl.s, 3, 0.5);
        if (h && b.vx * h.nx + b.vy * h.ny < 260) { b.vx += h.nx * 260; b.vy += h.ny * 260; sl.flash = 0.18; add(10, h.px, h.py); }
      }
      for (const f of flippers) {
        const tx = f.x + Math.cos(f.a) * f.len, ty = f.y + Math.sin(f.a) * f.len;
        // The flipper's surface moves with it: w × r at the closest point.
        const dx = tx - f.x, dy = ty - f.y, k = Math.max(0, Math.min(1, ((b.x - f.x) * dx + (b.y - f.y) * dy) / (dx * dx + dy * dy)));
        const rx = dx * k, ry = dy * k;
        hitSegment(b, f.x, f.y, tx, ty, 5.5, 0.3, -f.w * ry, f.w * rx);
      }
      for (const p of bumpers) {
        let nx = b.x - p.x, ny = b.y - p.y; const d = Math.hypot(nx, ny);
        if (d >= p.r + R || d === 0) continue;
        nx /= d; ny /= d; b.x = p.x + nx * (p.r + R); b.y = p.y + ny * (p.r + R);
        const vn = b.vx * nx + b.vy * ny, out = Math.max(380, -vn * 0.9);
        b.vx += (out - vn) * nx; b.vy += (out - vn) * ny;
        p.flash = 0.2; add(100, p.x, p.y - p.r);
      }
      for (const l of lanes) {
        if (l.lit || Math.hypot(b.x - l.x, b.y - l.y) > 10) continue;
        l.lit = true; add(50, l.x, l.y - 8);
        if (lanes.every((x) => x.lit)) { add(500, cx, 110); game.mult = Math.min(5, game.mult + 1); game.top = Math.max(game.top, game.mult); game.note = { text: "×" + game.mult + " 배수!", t: 0 }; lanes.forEach((x) => { x.lit = false; }); }
      }
      if (b.y > H + R) {
        if (!game.saved && game.launched && game.clock - game.launched < save) { game.note = { text: "볼 세이브!", t: 0 }; toLane(true); return; }
        game.balls--; game.mult = 1;
        if (game.balls <= 0) { game.ended = true; b.y = H + 40; b.vx = b.vy = 0; return; }
        game.note = { text: "남은 공 " + game.balls, t: 0 }; toLane();
      }
    };
    game.step = (ms) => {
      if (game.ended) return;
      const n = Math.max(1, Math.round(Math.min(ms, 50) / 2.5));
      for (let k = 0; k < n && !game.ended; k++) tick(Math.min(ms, 50) / 1000 / n);
      const s = Math.min(ms, 50) / 1000;
      bumpers.forEach((p) => { p.flash = Math.max(0, p.flash - s); }); slings.forEach((p) => { p.flash = Math.max(0, p.flash - s); });
      game.popups = game.popups.filter((p) => (p.t += s) < 0.8);
      if (game.note && (game.note.t += s) > 1.6) game.note = null;
    };
    return game;
  }
  /* 쿠키 가게 drawings: sticker-outlined SVG, solid fills. Static markup only; the game state is set as data-*
   * attributes on the wrapping element and the CSS shows, hides and recolours the parts. */
  const SHOP_COOKIE_SVG = (kind) => '<svg viewBox="0 0 40 36" aria-hidden="true">'
    + '<ellipse cx="20" cy="31" rx="14" ry="2.5" fill="#6B4528" opacity=".18"/>'
    + '<path d="M5 21c0-7 7-11 15-11s15 4 15 11-7 9-15 9-15-2-15-9Z" fill="#E7A552" stroke="#6B3A14" stroke-width="2.4" stroke-linejoin="round"/>'
    + '<path d="M10 20q3-2 6 0M24 18q3-2 6 1M17 25q3-1 6 0" fill="none" stroke="#B5722F" stroke-width="1.5" stroke-linecap="round"/>'
    + (kind === 'chip' || kind === 'both' ? '<g fill="#3E2616"><ellipse cx="12" cy="24" rx="2.2" ry="1.7"/><ellipse cx="27" cy="23" rx="2.2" ry="1.7"/><ellipse cx="20" cy="27" rx="2" ry="1.5"/><ellipse cx="30" cy="18" rx="1.8" ry="1.4"/><ellipse cx="9" cy="17" rx="1.8" ry="1.4"/></g>' : '')
    + (kind === 'cream' || kind === 'both' ? '<path d="M12 17c0-4 3-6 5-7 0-3 2-5 3-7 1 2 3 4 3 7 2 1 5 3 5 7-3 2-13 2-16 0Z" fill="#fff" stroke="#C99F7E" stroke-width="2" stroke-linejoin="round"/><path d="M15 14q5 2 10 0" fill="none" stroke="#E8D3BE" stroke-width="1.4" stroke-linecap="round"/>' : '')
    + '<path d="M9 15q3-3 7-4" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity=".55"/></svg>';
  // One oven: control panel (knob, dial, lamp), the glass door with the tray, the cookie, steam and smoke.
  const SHOP_OVEN_SVG = (zones) => '<svg viewBox="0 0 100 124" aria-hidden="true">'
    + '<rect class="ov-foot" x="14" y="114" width="14" height="8" rx="3"/><rect class="ov-foot" x="72" y="114" width="14" height="8" rx="3"/>'
    + '<rect class="ov-body" x="4" y="6" width="92" height="110" rx="14"/>'
    + '<path class="ov-top" d="M4 34V20A14 14 0 0 1 18 6h64a14 14 0 0 1 14 14v14Z"/>'
    + '<g class="ov-knob"><circle cx="18" cy="20" r="7.5"/><path d="M18 20v-6"/></g>'
    + '<g class="ov-dial"><circle class="dial-face" cx="50" cy="22" r="11"/>' + zones + '<path class="needle" d="M50 22v-9"/><circle class="hub" cx="50" cy="22" r="2.2"/></g>'
    + '<circle class="ov-lamp" cx="82" cy="20" r="5"/>'
    + '<rect class="ov-door" x="11" y="40" width="78" height="70" rx="10"/>'
    + '<rect class="ov-glass" x="17" y="46" width="66" height="44" rx="7"/>'
    + '<g class="ov-fire"><path d="M28 88c-3-4 0-6 2-9 1 3 4 4 2 9Z"/><path d="M40 88c-3-4 0-7 2-10 1 3 4 5 2 10Z"/><path d="M52 88c-3-4 0-7 2-10 1 3 4 5 2 10Z"/><path d="M64 88c-3-4 0-6 2-9 1 3 4 4 2 9Z"/></g>'
    + '<path class="ov-coil" d="M21 84l4-3 4 3 4-3 4 3 4-3 4 3 4-3 4 3 4-3 4 3 4-3 4 3 4-3 4 3"/>'
    + '<rect class="ov-tray" x="23" y="75" width="54" height="4.5" rx="2"/>'
    + '<g class="ov-butter"><rect x="41" y="68" width="18" height="7.5" rx="2"/><path d="M44 70.5h7"/></g><ellipse class="ov-melt" cx="50" cy="74.6" rx="20" ry="2.3"/>'
    + '<g class="ov-cookie"><ellipse class="ck-ball" cx="50" cy="67" rx="14" ry="9"/>'
    + '<path class="ck-disc" d="M28 70c0-5 10-8 22-8s22 3 22 8-10 6-22 6-22-1-22-6Z"/><path class="ck-crack" d="M35 68q4-2 7 0M53 66q3-2 7 1M44 72q3-1 6 0"/>'
    + '<g class="ck-sugar"><circle cx="38" cy="65" r="1"/><circle cx="46" cy="63" r="1"/><circle cx="57" cy="64" r="1"/><circle cx="63" cy="68" r="1"/><circle cx="41" cy="71" r="1"/></g>'
    + '<g class="ck-chip"><ellipse cx="38" cy="68" rx="2.6" ry="1.9"/><ellipse cx="49" cy="65" rx="2.6" ry="1.9"/><ellipse cx="61" cy="68" rx="2.6" ry="1.9"/><ellipse cx="54" cy="72" rx="2.3" ry="1.6"/><ellipse cx="43" cy="72.5" rx="2.2" ry="1.5"/></g>'
    + '<g class="ck-cream"><path d="M41 66c0-4 4-5 6-6 0-3 2-5 3-7 1 2 3 4 3 7 2 1 6 2 6 6-4 2-14 2-18 0Z"/><path d="M44 63q6 2 12 0"/></g></g>'
    + '<g class="ov-steam"><path d="M38 60c-3-3 3-6 0-10"/><path d="M50 57c-3-3 3-6 0-10"/><path d="M62 60c-3-3 3-6 0-10"/></g>'
    + '<g class="ov-smoke"><circle cx="40" cy="58" r="6"/><circle cx="52" cy="53" r="8"/><circle cx="63" cy="59" r="5.5"/></g>'
    + '<path class="ov-shine" d="M22 52q3-3 8-3"/>'
    + '<rect class="ov-handle" x="24" y="97" width="52" height="6" rx="3"/></svg>';
  // The tools on the shelf.
  const SHOP_TOOL_SVG = {
    butter: '<path d="M8 22 22 14l14 6v8L22 36 8 30Z" fill="#FFE07A" stroke="#7A5A10" stroke-width="2.4" stroke-linejoin="round"/><path d="M8 22l14 6 14-8M22 28v8" fill="none" stroke="#7A5A10" stroke-width="2.4" stroke-linejoin="round"/><path d="M12 22l10-5" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity=".7"/>',
    fire: '<path d="M22 38c-8 0-12-5-12-11 0-7 6-10 7-17 3 3 4 6 4 9 2-2 3-5 3-8 5 4 10 9 10 16 0 6-4 11-12 11Z" fill="#FF8A3D" stroke="#8A3410" stroke-width="2.4" stroke-linejoin="round"/><path d="M22 37c-4 0-6-2-6-5 0-4 4-5 5-9 3 3 7 5 7 9 0 3-2 5-6 5Z" fill="#FFD84D"/>',
    dough: '<path d="M6 24h32l-3 12c-1 2-2 3-4 3H13c-2 0-3-1-4-3Z" fill="#9CC9F5" stroke="#2C4F78" stroke-width="2.4" stroke-linejoin="round"/><path d="M10 24c0-6 5-10 12-10s12 4 12 10Z" fill="#F6DFAE" stroke="#9A7440" stroke-width="2.4" stroke-linejoin="round"/><path d="M15 19q3-2 6-2" stroke="#fff" stroke-width="2" stroke-linecap="round" fill="none"/><path d="M4 24h36" stroke="#2C4F78" stroke-width="2.4" stroke-linecap="round"/>',
    sugar: '<rect x="11" y="13" width="22" height="25" rx="5" fill="#fff" stroke="#6B4528" stroke-width="2.4"/><rect x="13" y="7" width="18" height="7" rx="2" fill="#F7A8C4" stroke="#6B4528" stroke-width="2.4"/><g fill="#C8B9A8"><rect x="16" y="24" width="4" height="4" rx="1"/><rect x="23" y="27" width="4" height="4" rx="1"/><rect x="18" y="31" width="4" height="4" rx="1"/></g><path d="M15 18v6" stroke="#E9E0D5" stroke-width="2" stroke-linecap="round"/>',
    chip: '<path d="M10 12h24l-2 26H12Z" fill="#C2803F" stroke="#4A2A12" stroke-width="2.4" stroke-linejoin="round"/><path d="M10 12l3-5h18l3 5" fill="#E9B26B" stroke="#4A2A12" stroke-width="2.4" stroke-linejoin="round"/><g fill="#3E2616"><path d="M17 22l3-4 3 4Z"/><path d="M22 30l3-4 3 4Z"/><path d="M14 32l3-4 3 4Z"/></g>',
    cream: '<path d="M14 6h16l-4 22h-8Z" fill="#FFF6EC" stroke="#9A7A62" stroke-width="2.4" stroke-linejoin="round"/><path d="M18 28h8l-2 6h-4Z" fill="#C9D0D8" stroke="#5C646E" stroke-width="2.4" stroke-linejoin="round"/><path d="M15 38c2-3 5-3 7-3s5 0 7 3" fill="#fff" stroke="#C99F7E" stroke-width="2.2" stroke-linecap="round"/><path d="M18 10l2 12" stroke="#fff" stroke-width="2" stroke-linecap="round"/>',
    serve: '<ellipse cx="22" cy="27" rx="18" ry="8" fill="#fff" stroke="#6B4528" stroke-width="2.4"/><ellipse cx="22" cy="26" rx="11" ry="4.5" fill="none" stroke="#9CC9F5" stroke-width="2"/><path d="M8 25q2-3 6-4" stroke="#E5EEF6" stroke-width="2" stroke-linecap="round" fill="none"/>',
  };
  // A guest drawn when there are no SD sprites: hair and clothes vary by guest; the face follows the mood.
  const SHOP_GUEST_SVG = '<svg viewBox="0 0 60 72" aria-hidden="true">'
    + '<path class="g-body" d="M9 72c0-15 9-22 21-22s21 7 21 22Z"/><path class="g-collar" d="M23 51l7 7 7-7"/>'
    + '<path class="g-back" d="M12 34c0-14 8-21 18-21s18 7 18 21c0 8-3 12-3 12H15s-3-4-3-12Z"/>'
    + '<circle class="g-head" cx="30" cy="31" r="16"/>'
    + '<path class="g-hair" d="M13 31c0-12 8-18 17-18s17 6 17 18c-3-5-7-8-11-8-1 3-4 5-7 5 1-2 1-4 0-5-6 1-12 3-16 8Z"/>'
    + '<g class="g-eyes"><ellipse cx="24" cy="33" rx="2" ry="2.6"/><ellipse cx="36" cy="33" rx="2" ry="2.6"/></g>'
    + '<path class="g-brow" d="M20 27l6 2M40 27l-6 2"/>'
    + '<circle class="g-cheek" cx="20" cy="38" r="2.6"/><circle class="g-cheek" cx="40" cy="38" r="2.6"/>'
    + '<path class="g-mouth m-happy" d="M26 39q4 4 8 0"/><path class="g-mouth m-flat" d="M27 40h6"/><path class="g-mouth m-angry" d="M26 41q4-3 8 0"/></svg>';
  const SHOP_GUEST_LOOKS = [['#6B4528', '#F7A8C4'], ['#2D2A3A', '#9CC9F5'], ['#E9B26B', '#8FDDBA'], ['#B5523A', '#FFE07A'], ['#8C6CF0', '#FFD3E0'], ['#3E5A8A', '#FFC27A']];
  // 비스킷 벽돌깨기: bounce the gumball off the spatula into rows of biscuits. Where it meets the spatula sets the angle.
  // Chocolate biscuits (the top row from 보통 on) take two hits. A broken biscuit may drop a treat: a long spatula for
  // a while, or a heart. Clear the tray for the next stage, a little faster; lose the ball with no hearts left and it is
  // over. step(ms) runs in fixed 1/400 s steps, so it plays the same at any frame rate.
  function newBrickGame(random = Math.random, difficulty = "normal") {
    const [width, speed, lives, choco] = ({ easy: [72, 250, 5, 0], normal: [58, 290, 3, 1], hard: [48, 330, 3, 2] })[difficulty] || [58, 290, 3, 1];
    const W = 320, H = 420, R = 6, PY = 392, COLS = 8, BW = 34, BH = 15, GAP = 3, LEFT = (W - COLS * BW - (COLS - 1) * GAP) / 2, TOP = 46;
    const game = { W, H, R, PY, BW, BH, stage: 1, speed, lives, score: 0, bricks: [], items: [], popups: [], note: null,
      paddle: { x: W / 2, w: width, target: null, dir: 0, long: 0 }, ball: null, ended: false, won: false, broken: 0 };
    const lay = () => {
      const rows = Math.min(8, 4 + game.stage);
      game.bricks = [];
      for (let r = 0; r < rows; r++) for (let c = 0; c < COLS; c++) {
        // Later stages leave a gap pattern so the trays differ.
        if (game.stage > 1 && (r + c * (game.stage % 3 + 1)) % 7 === 0) continue;
        const hp = r < choco + (game.stage > 2 ? 1 : 0) ? 2 : 1;
        game.bricks.push({ x: LEFT + c * (BW + GAP), y: TOP + r * (BH + GAP), row: r, hp, max: hp });
      }
    };
    const serve = () => { game.ball = { x: game.paddle.x, y: PY - R - 1, vx: 0, vy: 0, stuck: true }; };
    lay(); serve();
    const add = (n, x, y) => { game.score += n; game.popups.push({ text: "+" + n, x, y, t: 0 }); };
    game.launch = () => {
      const b = game.ball;
      if (!b.stuck || game.ended) return;
      const a = (random() - 0.5) * 0.8;
      b.stuck = false; b.vx = Math.sin(a) * game.speed; b.vy = -Math.cos(a) * game.speed;
    };
    game.move = (dir) => { game.paddle.dir = dir; game.paddle.target = null; };
    game.aim = (x) => { game.paddle.target = x; };
    const tick = (dt) => {
      const p = game.paddle, b = game.ball, half = (p.long > 0 ? p.w * 1.5 : p.w) / 2;
      if (p.target != null) p.x += Math.max(-700 * dt, Math.min(700 * dt, p.target - p.x));
      else p.x += p.dir * 420 * dt;
      p.x = Math.max(half + 4, Math.min(W - half - 4, p.x));
      if (b.stuck) { b.x = p.x; return; }
      b.x += b.vx * dt; b.y += b.vy * dt;
      if (b.x < R + 4) { b.x = R + 4; b.vx = Math.abs(b.vx); }
      if (b.x > W - R - 4) { b.x = W - R - 4; b.vx = -Math.abs(b.vx); }
      if (b.y < R + 4) { b.y = R + 4; b.vy = Math.abs(b.vy); }
      // The spatula: the farther from its middle, the steeper the bounce.
      if (b.vy > 0 && b.y + R >= PY && b.y - R <= PY + 10 && Math.abs(b.x - p.x) <= half + R) {
        const off = Math.max(-1, Math.min(1, (b.x - p.x) / half)), a = off * 1.05, v = Math.min(game.speed * 1.6, Math.hypot(b.vx, b.vy) * 1.004);
        b.vx = Math.sin(a) * v; b.vy = -Math.cos(a) * v; b.y = PY - R;
      }
      // Biscuits: bounce off the side that was hit least deep.
      for (const k of game.bricks) {
        if (k.hp <= 0) continue;
        const cx = Math.max(k.x, Math.min(b.x, k.x + BW)), cy = Math.max(k.y, Math.min(b.y, k.y + BH));
        if ((b.x - cx) ** 2 + (b.y - cy) ** 2 > R * R) continue;
        const ox = Math.min(b.x + R - k.x, k.x + BW - (b.x - R)), oy = Math.min(b.y + R - k.y, k.y + BH - (b.y - R));
        if (ox < oy) b.vx = b.x < k.x + BW / 2 ? -Math.abs(b.vx) : Math.abs(b.vx);
        else b.vy = b.y < k.y + BH / 2 ? -Math.abs(b.vy) : Math.abs(b.vy);
        k.hp--; k.hit = 0.15;
        if (k.hp > 0) { add(5, k.x + BW / 2, k.y); break; }
        game.broken++; add(10 * game.stage + (k.max > 1 ? 20 : 0), k.x + BW / 2, k.y);
        if (random() < 0.09) game.items.push({ kind: random() < 0.7 ? "long" : "heart", x: k.x + BW / 2, y: k.y + BH / 2 });
        break;
      }
      game.bricks = game.bricks.filter((k) => k.hp > 0);
      if (!game.bricks.length) {
        add(100 * game.stage, W / 2, 200); game.stage++; game.speed *= 1.08; game.items = [];
        game.note = { text: "스테이지 " + game.stage + "!", t: 0 }; lay(); serve(); return;
      }
      if (b.y > H + R) {
        game.lives--; p.long = 0; game.items = [];
        if (game.lives <= 0) { game.ended = true; return; }
        game.note = { text: "남은 하트 " + game.lives, t: 0 }; serve();
      }
    };
    game.step = (ms) => {
      if (game.ended) return;
      const s = Math.min(ms, 50) / 1000, n = Math.max(1, Math.round(s / 0.0025));
      for (let k = 0; k < n && !game.ended; k++) tick(s / n);
      const p = game.paddle, half = (p.long > 0 ? p.w * 1.5 : p.w) / 2;
      p.long = Math.max(0, p.long - s);
      // Treats fall; the spatula catches them.
      game.items = game.items.filter((it) => {
        it.y += 110 * s;
        if (it.y >= PY - 6 && it.y <= PY + 12 && Math.abs(it.x - p.x) <= half + 8) {
          if (it.kind === "long") { p.long = 12; game.note = { text: "길쭉 뒤집개!", t: 0 }; } else { game.lives = Math.min(9, game.lives + 1); game.note = { text: "하트 +1", t: 0 }; }
          return false;
        }
        return it.y < H + 10;
      });
      game.bricks.forEach((k) => { if (k.hit) k.hit = Math.max(0, k.hit - s); });
      game.popups = game.popups.filter((q) => (q.t += s) < 0.8);
      if (game.note && (game.note.t += s) > 1.6) game.note = null;
    };
    return game;
  }
  // 스네이크: eat, grow, never touch a wall or yourself.
  function newSnakeGame(random = Math.random, difficulty = "normal") {
    const [n, speed] = ({ easy: [12, 170], normal: [15, 125], hard: [18, 90] })[difficulty] || [15, 125];
    const mid = Math.floor(n / 2) * n + Math.floor(n / 2);
    const game = { cols: n, rows: n, speed, body: [mid, mid - 1, mid - 2], dir: "right", queue: [], food: -1, score: 0, ended: false, won: false };
    const placeFood = () => {
      const taken = new Set(game.body), free = [];
      for (let i = 0; i < n * n; i++) if (!taken.has(i)) free.push(i);
      if (!free.length) { game.ended = game.won = true; game.food = -1; return; }
      game.food = free[Math.floor(random() * free.length)];
    };
    const OPPOSITE = { up: "down", down: "up", left: "right", right: "left" };
    game.turn = (dir) => {
      const last = game.queue.length ? game.queue[game.queue.length - 1] : game.dir;
      if (!OPPOSITE[dir] || dir === last || dir === OPPOSITE[last] || game.queue.length >= 2) return false;
      game.queue.push(dir); return true;
    };
    game.step = () => {
      if (game.ended) return;
      if (game.queue.length) game.dir = game.queue.shift();
      const head = game.body[0], x = head % n, y = Math.floor(head / n);
      const [nx, ny] = game.dir === "up" ? [x, y - 1] : game.dir === "down" ? [x, y + 1] : game.dir === "left" ? [x - 1, y] : [x + 1, y];
      if (nx < 0 || ny < 0 || nx >= n || ny >= n) { game.ended = true; return; }
      const next = ny * n + nx, eats = next === game.food;
      // Moving into the cell the tail leaves this step is allowed.
      const blocking = eats ? game.body : game.body.slice(0, -1);
      if (blocking.includes(next)) { game.ended = true; return; }
      game.body.unshift(next);
      if (eats) { game.score++; placeFood(); } else game.body.pop();
    };
    placeFood();
    return game;
  }
  // 딸기 우유 · 레시피: the ingredients light up in order; press them back. Each round adds one more.
  function newRecipeGame(random = Math.random, difficulty = "normal") {
    const [pads, speed] = ({ easy: [4, 700], normal: [4, 520], hard: [6, 420] })[difficulty] || [4, 520];
    const game = { pads, speed, sequence: [], at: 0, round: 0, ended: false };
    game.next = () => { game.sequence.push(Math.floor(random() * pads)); game.at = 0; };
    game.press = (i) => {
      if (game.ended) return "ended";
      if (game.sequence[game.at] !== i) { game.ended = true; return "fail"; }
      game.at++;
      if (game.at < game.sequence.length) return "ok";
      game.round++; game.next(); return "round";
    };
    game.next();
    return game;
  }
  // 민트 초코 · 초코칩 터뜨리기: press a group of two or more touching chips of one colour; the rest fall and close up.
  function newPopGame(random = Math.random, difficulty = "normal") {
    const [cols, rows, colours] = ({ easy: [8, 6, 3], normal: [10, 8, 4], hard: [12, 9, 5] })[difficulty] || [10, 8, 4];
    const cells = Array.from({ length: cols * rows }, () => 1 + Math.floor(random() * colours));
    const game = { cols, rows, colours, cells, score: 0, ended: false, won: false };
    game.group = (i) => {
      const v = cells[i]; if (!v) return [];
      const seen = new Set([i]), stack = [i];
      while (stack.length) {
        const j = stack.pop(), x = j % cols, y = Math.floor(j / cols);
        for (const [nx, ny] of [[x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]]) {
          const k = ny * cols + nx;
          if (nx >= 0 && nx < cols && ny >= 0 && ny < rows && !seen.has(k) && cells[k] === v) { seen.add(k); stack.push(k); }
        }
      }
      return [...seen];
    };
    game.canMove = () => cells.some((v, i) => v && ((i % cols < cols - 1 && cells[i + 1] === v) || (i + cols < cells.length && cells[i + cols] === v)));
    game.pop = (i) => {
      if (game.ended) return 0;
      const g = game.group(i); if (g.length < 2) return 0;
      g.forEach((j) => cells[j] = 0);
      game.score += (g.length - 1) * (g.length - 1);
      // Gravity in each column, then empty columns close to the left.
      const columns = [];
      for (let x = 0; x < cols; x++) { const col = []; for (let y = rows - 1; y >= 0; y--) if (cells[y * cols + x]) col.push(cells[y * cols + x]); if (col.length) columns.push(col); }
      cells.fill(0);
      columns.forEach((col, x) => col.forEach((v, k) => { cells[(rows - 1 - k) * cols + x] = v; }));
      if (!cells.some(Boolean)) { game.won = true; game.score += 100; }
      if (!game.canMove()) game.ended = true;
      return g.length;
    };
    return game;
  }
  // 라벤더 · 꽃밭 퍼즐: slide the pieces into the empty spot until they read in order. Shuffled by legal moves,
  // so every board can be solved.
  function newSlideGame(random = Math.random, difficulty = "normal") {
    const n = ({ easy: 3, normal: 4, hard: 5 })[difficulty] || 4;
    const cells = Array.from({ length: n * n }, (_, i) => (i + 1) % (n * n));
    const game = { cols: n, rows: n, cells, moves: 0, ended: false, won: false };
    const blank = () => cells.indexOf(0);
    const near = (i, j) => Math.abs(i % n - j % n) + Math.abs(Math.floor(i / n) - Math.floor(j / n)) === 1;
    game.solved = () => cells.every((v, i) => v === (i + 1) % (n * n));
    let last = -1;
    // A fixed number of random legal moves, then a few stepped ones if that happened to land back on the solution.
    for (let k = 0; k < n * n * 30 + n * n * 4 && (k < n * n * 30 || game.solved()); k++) {
      const b = blank(), options = cells.map((_, i) => i).filter((i) => near(i, b) && i !== last);
      const pick = k < n * n * 30 ? options[Math.floor(random() * options.length)] : options[k % options.length];
      [cells[b], cells[pick]] = [cells[pick], cells[b]]; last = b;
    }
    game.slide = (i) => {
      if (game.ended) return false;
      const b = blank(); if (!near(i, b)) return false;
      [cells[b], cells[i]] = [cells[i], cells[b]]; game.moves++;
      if (game.solved()) game.ended = game.won = true;
      return true;
    };
    return game;
  }
  // 밤하늘 · 별 밝히기: pressing a star switches it and its four neighbours; light every star. Made by pressing
  // from all-lit, so it can always be solved.
  function newLightsGame(random = Math.random, difficulty = "normal") {
    const [n, presses] = ({ easy: [4, 4], normal: [5, 7], hard: [6, 12] })[difficulty] || [5, 7];
    const cells = Array(n * n).fill(true);
    const game = { cols: n, rows: n, cells, moves: 0, ended: false, won: false };
    const flip = (i) => { const x = i % n, y = Math.floor(i / n); for (const [a, b] of [[x, y], [x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]]) if (a >= 0 && a < n && b >= 0 && b < n) cells[b * n + a] = !cells[b * n + a]; };
    // Distinct cells by a partial shuffle: a fixed number of draws, whatever the random source.
    const order = cells.map((_, i) => i);
    for (let k = 0; k < presses; k++) { const at = k + Math.floor(random() * (order.length - k)); [order[k], order[at]] = [order[at], order[k]]; flip(order[k]); }
    if (cells.every(Boolean)) flip(0);
    game.press = (i) => { if (game.ended) return; flip(i); game.moves++; if (cells.every(Boolean)) game.ended = game.won = true; };
    return game;
  }
  function writingLoad(h) {
    if (!h) return false;
    // A story fetch/entry is not generation. The Forge screen also covers image generation after text is ready.
    const forge = h.shadowRoot?.querySelector?.('.forge-center');
    const visible = forge && !forge.closest('[hidden]') && forge.getClientRects().length > 0;
    const text = visible ? forge.textContent || '' : '';
    if (/(?:실패|오류|취소|failed|error|cancelled)/i.test(text)) return false;
    const working = /(?:생성\s*중|작성\s*중|그리는\s*중|generating|rendering|writing\b)/i.test(text);
    if (visible && /(?:완료|완성|completed|finished)/i.test(text) && !working) return false;
    // Fetching an existing chapter also uses _planState=loading. Only an explicit
    // generation-in-progress screen may offer games; labels/buttons are not evidence.
    return !!visible && working;
  }
  // Best records per game and level, kept in this browser only (a convenience; losing them loses nothing).
  const GAME_BEST_KEY = "gfx-games-best";
  function gameBest(key) { try { return (JSON.parse(localStorage.getItem(GAME_BEST_KEY) || "{}") || {})[key]; } catch { return undefined; } }
  function saveGameBest(key, value, lower) {
    let all = {};
    try { all = JSON.parse(localStorage.getItem(GAME_BEST_KEY) || "{}") || {}; } catch {}
    const old = all[key];
    if (old != null && (lower ? value >= old : value <= old)) return false;
    all[key] = value;
    try { localStorage.setItem(GAME_BEST_KEY, JSON.stringify(all)); } catch {}
    return true;
  }
  const clock = (ms) => { const s = Math.max(0, Math.round(ms / 1000)); return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"); };
  function makeLoadingGames(overlay) {
    const panelLife = resources();
    let suspended = false;
    const { setTimeout, clearTimeout, setInterval, clearInterval, requestAnimationFrame, cancelAnimationFrame } = panelLife;
    const on = (target, type, fn, opts = {}) => listen(panelLife, target, type, fn, opts);
    const panel = el('section', 'gfx-load-games');
    panel.setAttribute('aria-label', '로딩 미니게임');
    const nav = el('div', 'gfx-game-nav'), content = el('div', 'gfx-game-content');
    const button = (label, fn, cls = '') => { const b = el('button', cls, label); b.type = 'button'; on(b, 'click', fn); return b; };
    // One picture per character of this world, for the memory cards.
    // The 말랑 extension shares its SD sprites when it is on; without it the cards are fruit.
    const faces = () => { try { return [...new Set(window.__GFX_SD_FACES?.() || [])].filter(safeFace); } catch { return []; } };
    const GAMES = {
      mines: { name: '지뢰찾기', icon: '💣', level: 'easy', levels: [['easy', '쉬움', '8×8 · 10개'], ['normal', '보통', '10×10 · 18개'], ['hard', '어려움', '12×12 · 30개']], make: (lv) => newMineGame(Math.random, lv) },
      fruits: { name: '사과 상자', icon: '🍎', level: 'normal', levels: [['easy', '쉬움', '3분 · 1~5'], ['normal', '보통', '2분 · 1~9'], ['hard', '어려움', '1분 30초']], make: (lv) => newFruitGame(Math.random, lv) },
      merge: { name: '2048', icon: '🔢', level: 'normal', levels: [['easy', '쉬움', '5×5'], ['normal', '보통', '4×4'], ['hard', '어려움', '3×3 · 256']], make: (lv) => new2048Game(Math.random, lv) },
      memory: { name: '짝 맞추기', icon: '🃏', level: 'easy', levels: [['easy', '쉬움', '6쌍'], ['normal', '보통', '8쌍'], ['hard', '어려움', '12쌍']], make: (lv) => newMemoryGame(Math.random, lv, faces()) },
      shop: { name: '쿠키 가게', icon: '🍪', level: 'normal', levels: [['easy', '쉬움', '목표 6,000원 · 손님 느긋 · ♥5'], ['normal', '보통', '목표 10,000원 · ♥4'], ['hard', '어려움', '목표 15,000원 · 손님 급함 · ♥3']], make: (lv) => newShopGame(Math.random, lv) },
      pinball: { name: '디저트 핀볼', tab: '핀볼', icon: '🎱', level: 'normal', levels: [['easy', '쉬움', '공 5개 · 볼 세이브 10초 · 넓은 플리퍼'], ['normal', '보통', '공 3개 · 볼 세이브 5초'], ['hard', '어려움', '공 3개 · 세이브 없음 · 짧은 플리퍼']], make: (lv) => newPinballGame(Math.random, lv) },
      bricks: { name: '비스킷 벽돌깨기', tab: '벽돌깨기', icon: '🧁', level: 'normal', levels: [['easy', '쉬움', '하트 5개 · 넓은 뒤집개 · 느리게'], ['normal', '보통', '하트 3개 · 초코 비스킷 한 줄'], ['hard', '어려움', '하트 3개 · 좁은 뒤집개 · 빠르게']], make: (lv) => newBrickGame(Math.random, lv) },
      snake: { name: '스네이크', icon: '🐍', level: 'normal', levels: [['easy', '쉬움', '12×12 · 느리게'], ['normal', '보통', '15×15'], ['hard', '어려움', '18×18 · 빠르게']], make: (lv) => newSnakeGame(Math.random, lv) },
      recipe: { name: '딸기 우유 레시피', tab: '딸기 우유', icon: '🥛', level: 'normal', levels: [['easy', '쉬움', '재료 4 · 천천히'], ['normal', '보통', '재료 4'], ['hard', '어려움', '재료 6 · 빠르게']], make: (lv) => newRecipeGame(Math.random, lv) },
      pop: { name: '초코칩 터뜨리기', tab: '초코칩', icon: '🍫', level: 'normal', levels: [['easy', '쉬움', '8×6 · 3색'], ['normal', '보통', '10×8 · 4색'], ['hard', '어려움', '12×9 · 5색']], make: (lv) => newPopGame(Math.random, lv) },
      slide: { name: '꽃밭 퍼즐', icon: '🌸', level: 'easy', levels: [['easy', '쉬움', '3×3'], ['normal', '보통', '4×4'], ['hard', '어려움', '5×5']], make: (lv) => newSlideGame(Math.random, lv) },
      lights: { name: '별 밝히기', icon: '🌟', level: 'normal', levels: [['easy', '쉬움', '4×4'], ['normal', '보통', '5×5'], ['hard', '어려움', '6×6']], make: (lv) => newLightsGame(Math.random, lv) },
    };
    const fresh = (which) => ({ game: GAMES[which].make(GAMES[which].level), level: GAMES[which].level, started: 0, stopped: 0, hints: 3, recorded: false, hideResult: false });
    const states = {};
    let mode = '', flagMode = false, anchor = null, pointer = null, moved = false, end = null, paintNow = null;
    // Timers of the game on screen (the cookie oven, the recipe playback, the pinball frame); cleared when it changes or
    // closes. A game that runs on the clock pauses then (st.pause).
    let live = 0, frame = 0, timers = [];
    const stopTimers = () => { clearInterval(live); live = 0; cancelAnimationFrame(frame); frame = 0; timers.forEach(clearTimeout); timers = []; if (mode) states[mode]?.pause?.(); };
    const tabs = Object.entries(GAMES).map(([key, g]) => {
      const b = button('', () => show(key), 'gfx-game-tab');
      const icon = el('i', '', g.icon); icon.setAttribute('aria-hidden', 'true');
      b.append(icon, el('span', '', g.tab || g.name)); b.dataset.game = key; b.setAttribute('aria-label', g.name); b.setAttribute('aria-pressed', 'false');
      return b;
    });
    const close = button('게임 접기', () => { stopTimers(); mode = ''; paintNow = null; overlay.removeAttribute('data-game'); content.replaceChildren(); tabs.forEach((b) => b.setAttribute('aria-pressed', 'false')); }, 'gfx-game-util');
    const enlarge = button('크게 보기', () => { const big = overlay.toggleAttribute('data-game-large'); enlarge.textContent = big ? '기본 크기' : '크게 보기'; enlarge.setAttribute('aria-pressed', String(big)); }, 'gfx-game-util');
    const utils = el('div', 'gfx-game-utils');
    utils.append(enlarge, close);
    nav.append(...tabs, utils); panel.append(nav, content);
    // The 말랑 colour preset picks the box game's fruit and the minesweeper palette (custom colours: a dark ground
    // reads as 밤하늘, anything else as 크림).
    const GAME_THEMES = { cream: ['사과 상자', '🍎'], berry: ['딸기 상자', '🍓'], mint: ['청사과 상자', '🍏'], lavender: ['포도 상자', '🍇'], night: ['별 상자', '⭐'] };
    const themeNow = () => {
      try {
        // 말랑 marks its preset on the game element; a picked palette is judged by its ground colour.
        const preset = overlay.getRootNode?.()?.host?.getAttribute('data-gfx-preset') || '';
        if (GAME_THEMES[preset]) return preset;
        const ink = getComputedStyle(overlay).getPropertyValue('--gfx-ink').trim();
        const hex = /^#([0-9a-f]{6})$/i.exec(ink), rgb = /^rgba?\((\d+)\D+(\d+)\D+(\d+)/i.exec(ink);
        const [r, g, b] = hex ? [parseInt(hex[1].slice(0, 2), 16), parseInt(hex[1].slice(2, 4), 16), parseInt(hex[1].slice(4), 16)] : rgb ? rgb.slice(1).map(Number) : [255, 255, 255];
        if ((0.299 * r + 0.587 * g + 0.114 * b) / 255 < 0.4) return 'night';
      } catch {}
      return 'cream';
    };
    const retheme = () => {
      const t = themeNow(), [name, icon] = GAME_THEMES[t], tab = tabs.find((b) => b.dataset.game === 'fruits');
      panel.dataset.theme = t; GAMES.fruits.name = name; GAMES.fruits.icon = icon;
      tab.setAttribute('aria-label', name); tab.querySelector('i').textContent = icon; tab.querySelector('span').textContent = name;
    };
    retheme();
    panel.retheme = retheme;
    for (const event of ['pointerdown', 'pointerup', 'click', 'dblclick', 'keydown', 'keyup']) on(panel, event, (e) => e.stopPropagation());
    // The clock: time-attack countdown and elapsed time. Stops by itself once the panel has been gone a while.
    let goneSince = 0;
    const paintTick = () => {
      if (!panel.isConnected) { goneSince ||= performance.now(); if (performance.now() - goneSince > 60000) clearInterval(tick); return; }
      goneSince = 0;
      if (paintNow && !document.hidden) paintNow(true);
    };
    let tick = setInterval(paintTick, 250);
    function show(next) {
      if (!suspended) stopTimers(); suspended = false; mode = next; anchor = null; pointer = null; overlay.setAttribute('data-game', mode); retheme();
      tabs.forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.game === mode)));
      const g = GAMES[mode], st = states[mode] ||= fresh(mode), game = st.game;
      content.replaceChildren();
      content.dataset.kind = mode;
      const head = el('div', 'gfx-game-head'), title = el('b', 'gfx-game-title'), stats = el('div', 'gfx-game-stats');
      const titleIcon = el('i', '', g.icon); titleIcon.setAttribute('aria-hidden', 'true');
      title.append(titleIcon, el('span', '', g.name));
      const tools = el('div', 'gfx-game-tools'), levels = el('div', 'gfx-game-levels');
      levels.setAttribute('role', 'radiogroup'); levels.setAttribute('aria-label', '난이도 (바꾸면 새 판)');
      for (const [value, label, detail] of g.levels) {
        const b = button(label, () => { if (st.level === value) return; g.level = value; states[mode] = fresh(mode); show(mode); });
        // One short word per level; the board size or time is in its tooltip and accessible name.
        b.title = detail; b.setAttribute('role', 'radio'); b.setAttribute('aria-checked', String(st.level === value)); b.setAttribute('aria-label', label + ' ' + detail);
        levels.append(b);
      }
      const renew = () => { states[mode] = fresh(mode); show(mode); };
      tools.append(levels, button('새 판', renew, 'gfx-game-new'));
      const info = el('div', 'gfx-game-info'), stage = el('div', 'gfx-game-stage'), board = el('div', 'gfx-game-board'), result = el('div', 'gfx-game-result');
      info.setAttribute('aria-live', 'polite'); result.hidden = true;
      on(result, 'click', (e) => { if (e.target === result) { st.hideResult = true; result.hidden = true; } });
      stage.append(board, result);
      // Title, level, new game (and the game's own tool) and the counters share one compact row.
      head.append(title, tools, stats);
      content.append(head, info, stage);
      const best = () => gameBest(mode + '-' + st.level);
      const begin = () => { if (!st.started) st.started = performance.now(); };
      const elapsed = () => st.started ? (st.stopped || performance.now()) - st.started : 0;
      const finish = (lower, value) => {
        if (st.stopped) return;
        st.stopped = performance.now();
        if (value != null && !st.recorded) { st.recorded = true; st.newBest = saveGameBest(mode + '-' + st.level, value, lower); }
      };
      const chips = (list) => stats.replaceChildren(...list.filter(Boolean).map(([text, alert]) => { const s = el('span', '', text); if (alert) s.dataset.alert = ''; return s; }));
      const showResult = (headline, line) => {
        if (st.hideResult) { result.hidden = true; return; }
        if (!result.hidden && result.dataset.headline === headline) return;
        const card = el('div'), again = button('다시 하기', renew, 'gfx-game-again');
        card.append(el('b', '', headline), el('span', '', line));
        if (st.newBest) card.append(el('em', '', '최고 기록!'));
        card.append(again);
        result.dataset.headline = headline; result.replaceChildren(card); result.hidden = false;
      };
      board.style.setProperty('--cols', String(game.cols));
      // The board's shape, for its size: the fruit box is wide, the memory cards are 3:4.
      board.style.setProperty('--fit', String(['fruits', 'pop'].includes(mode) ? game.cols / game.rows : mode === 'memory' ? game.cols * 3 / (game.rows * 4) : mode === 'shop' ? 0.95 : 1));
      board.dataset.kind = mode;
      let paint = () => {};

      if (mode === 'mines') {
        const flags = button('깃발 모드', () => { flagMode = !flagMode; flags.setAttribute('aria-pressed', String(flagMode)); }, 'gfx-game-flag');
        flags.setAttribute('aria-pressed', String(flagMode)); tools.append(flags);
        let held = null, heldFired = false;
        const buttons = game.cells.map((_, i) => {
          const b = button('', () => {
            if (heldFired) { heldFired = false; return; }
            const c = game.cells[i];
            if (c.open) game.chord(i);
            else if (flagMode) game.flag(i);
            else { begin(); game.reveal(i); }
            paint();
          });
          b.dataset.cell = String(i); board.append(b);
          on(b, 'contextmenu', (e) => { e.preventDefault(); game.flag(i); paint(); });
          // Touch: press and hold to place a flag.
          on(b, 'pointerdown', (e) => { if (e.pointerType !== 'touch') return; clearTimeout(held); heldFired = false; held = setTimeout(() => { if (!game.cells[i].open) { game.flag(i); heldFired = true; navigator.vibrate?.(15); paint(); } }, 430); });
          for (const t of ['pointerup', 'pointercancel', 'pointerleave']) on(b, t, () => clearTimeout(held));
          return b;
        });
        paint = (clockOnly) => {
          const flags = game.cells.filter((c) => c.flag).length, b0 = best();
          chips([['💣 ' + Math.max(0, game.mines - flags)], ['⏱ ' + clock(elapsed())], b0 != null && ['🏆 ' + clock(b0 * 1000)]]);
          if (clockOnly) return;
          if (game.ended) finish(true, game.won ? Math.round(elapsed() / 1000) : null);
          info.textContent = game.ended ? (game.won ? '성공! 지뢰를 모두 피했어요.' : '펑! 지뢰를 밟았어요.') : !game.started ? '첫 칸은 언제나 안전해요 · 우클릭/길게 눌러 깃발' : '숫자를 누르면 깃발 수가 맞을 때 주변이 한 번에 열려요';
          buttons.forEach((b, i) => {
            const c = game.cells[i], showMine = c.mine && game.ended && !c.flag;
            b.textContent = c.flag ? '깃발' : c.open && !c.mine ? (c.count || '') : '';
            b.dataset.open = String(c.open); b.dataset.flag = String(c.flag); b.dataset.n = c.open && !c.mine ? String(c.count) : '';
            b.dataset.mine = String(showMine); b.dataset.boom = String(i === game.boom); b.dataset.wrong = String(game.ended && !game.won && c.flag && !c.mine);
            b.disabled = game.ended;
            b.setAttribute('aria-label', (i + 1) + '번 칸 ' + (c.flag ? '깃발' : c.open ? (c.mine ? '지뢰' : '주변 지뢰 ' + c.count) : '닫힘'));
          });
          if (game.ended) showResult(game.won ? '클리어!' : '게임 오버', game.won ? '기록 ' + clock(elapsed()) : '새 판으로 다시 도전해 보세요');
        };
      }

      if (mode === 'fruits') {
        let hintIds = [], hintTimer = 0;
        const hint = button('힌트', () => {
          if (game.ended || st.hints <= 0) return;
          const m = game.findMove(); if (!m) return;
          st.hints--; hintIds = game.select(m.a, m.b).ids; clearTimeout(hintTimer);
          hintTimer = setTimeout(() => { hintIds = []; paint(); }, 1600); paint();
        }, 'gfx-game-hint');
        tools.append(hint);
        const buttons = game.cells.map((_, i) => {
          const b = button('', () => {
            // Keyboard and assistive-technology activation uses the same two-corner selection.
            if (pointer !== null || game.ended) return;
            begin();
            if (anchor === null) anchor = i; else { game.select(anchor, i, true); anchor = null; }
            paint();
          });
          b.dataset.cell = String(i); board.append(b);
          return b;
        });
        // The dragged rectangle, drawn as one thick box round the cells with the running sum on its corner:
        // tinting each apple alone was hard to see.
        // No running sum on it: adding the apples up is the game.
        const frame = el('div', 'gfx-fruit-frame');
        frame.setAttribute('aria-hidden', 'true'); frame.hidden = true; board.append(frame);
        const placeFrame = (selected) => {
          if (!selected || game.ended) { frame.hidden = true; return; }
          const first = buttons[Math.min(...selected.ids)], last = buttons[Math.max(...selected.ids)];
          frame.style.left = first.offsetLeft + 'px'; frame.style.top = first.offsetTop + 'px';
          frame.style.width = (last.offsetLeft + last.offsetWidth - first.offsetLeft) + 'px';
          frame.style.height = (last.offsetTop + last.offsetHeight - first.offsetTop) + 'px';
          frame.dataset.state = selected.sum === 10 ? 'ok' : selected.sum > 10 ? 'over' : '';
          frame.hidden = false;
        };
        const left = () => game.time * 1000 - elapsed();
        paint = (clockOnly, selection = null) => {
          if (!game.ended && st.started && left() <= 0) { game.ended = true; anchor = null; }
          const b0 = best(), remain = st.started ? left() : game.time * 1000;
          chips([[g.icon + ' ' + game.score + '점'], ['⏱ ' + clock(remain), st.started && !game.ended && remain < 15000], b0 != null && ['🏆 ' + b0 + '점']]);
          hint.textContent = '힌트 ' + st.hints; hint.disabled = game.ended || st.hints <= 0;
          if (clockOnly && (!game.ended || st.endPainted)) return;
          // Only after a move, not on every drag step: the search is the costly part.
          if (!game.ended && st.started && !selection && !game.findMove()) game.ended = true;
          st.endPainted = game.ended;
          if (game.ended) finish(false, game.score);
          const selected = selection || (anchor !== null ? game.select(anchor, anchor) : null);
          info.replaceChildren(document.createTextNode('점수 ' + game.score + ' · '));
          if (game.ended) info.append(left() <= 0 ? '시간 종료!' : '더 지울 수 있는 사과가 없어요');
          else if (selected) info.append('합이 10이면 손을 떼세요');
          else info.append(st.started ? '합이 10이 되게 사각형으로 묶으세요' : '합이 10이 되게 드래그하세요 · 첫 선택부터 시간이 흘러요');
          buttons.forEach((b, i) => {
            const v = game.cells[i];
            b.replaceChildren(); if (v) b.append(el('span', '', String(v)));
            b.dataset.empty = String(!v); b.dataset.selected = String(!!selected?.ids.includes(i)); b.dataset.hint = String(hintIds.includes(i));
            b.dataset.ok = String(!!selected && selected.sum === 10);
            b.disabled = game.ended;
            b.setAttribute('aria-label', (i + 1) + '번 사과 ' + v);
          });
          placeFrame(selected);
          if (game.ended) showResult(left() <= 0 ? '시간 종료!' : '상자 정리 끝!', '사과 ' + game.score + '개를 지웠어요');
        };
        // Measured from the first and last cell, not the board box: the board's padding put a drag one row off.
        const cellAt = (e) => {
          const r0 = buttons[0].getBoundingClientRect(), r1 = buttons.at(-1).getBoundingClientRect();
          if (e.clientX < r0.left || e.clientX >= r1.right || e.clientY < r0.top || e.clientY >= r1.bottom) return null;
          const x = Math.floor((e.clientX - r0.left) / (r1.right - r0.left) * game.cols), y = Math.floor((e.clientY - r0.top) / (r1.bottom - r0.top) * game.rows);
          return Math.min(game.rows - 1, Math.max(0, y)) * game.cols + Math.min(game.cols - 1, Math.max(0, x));
        };
        on(board, 'pointerdown', (e) => { if (e.button !== 0 || pointer !== null || game.ended) return; const i = cellAt(e); if (i === null) return; e.preventDefault(); begin(); pointer = e.pointerId; moved = false; end = i; if (anchor === null) anchor = i; board.setPointerCapture(e.pointerId); paint(false, game.select(anchor, i)); });
        on(board, 'pointermove', (e) => { if (pointer !== e.pointerId) return; const i = cellAt(e); if (i !== null) { moved ||= i !== end; end = i; paint(false, game.select(anchor, end)); } });
        on(board, 'pointerup', (e) => { if (pointer !== e.pointerId) return; e.preventDefault(); if (moved || end !== anchor) { game.select(anchor, end, true); anchor = null; } pointer = null; board.releasePointerCapture(e.pointerId); paint(); });
        on(board, 'pointercancel', () => { pointer = null; anchor = null; paint(); });
        // Pointer input is handled above; prevent its synthetic click from selecting twice.
        on(board, 'click', (e) => { if (e.detail) { e.preventDefault(); e.stopImmediatePropagation(); } }, { capture: true });
      }

      if (mode === 'merge') {
        board.tabIndex = 0; board.setAttribute('role', 'application'); board.setAttribute('aria-label', '2048 판 · 방향키나 스와이프로 밀기');
        const tiles = game.cells.map((_, i) => { const t = el('div'); t.dataset.cell = String(i); board.append(t); return t; });
        const pad = el('div', 'gfx-game-pad');
        const push = (dir) => { if (game.ended) return; begin(); if (game.move(dir)) paint(); board.focus({ preventScroll: true }); };
        for (const [dir, label, arrow] of [['up', '위로', '▲'], ['left', '왼쪽으로', '◀'], ['down', '아래로', '▼'], ['right', '오른쪽으로', '▶']]) { const b = button(arrow, () => push(dir)); b.setAttribute('aria-label', label); b.dataset.dir = dir; pad.append(b); }
        stage.append(pad);
        const KEYS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right', w: 'up', s: 'down', a: 'left', d: 'right', W: 'up', S: 'down', A: 'left', D: 'right' };
        on(board, 'keydown', (e) => { const dir = KEYS[e.key]; if (!dir) return; e.preventDefault(); push(dir); });
        let from = null;
        on(board, 'pointerdown', (e) => { from = [e.clientX, e.clientY, e.pointerId]; board.setPointerCapture?.(e.pointerId); });
        on(board, 'pointerup', (e) => {
          if (!from || from[2] !== e.pointerId) return;
          const dx = e.clientX - from[0], dy = e.clientY - from[1]; from = null;
          if (Math.max(Math.abs(dx), Math.abs(dy)) < 24) { board.focus({ preventScroll: true }); return; }
          push(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up'));
        });
        on(board, 'pointercancel', () => { from = null; });
        let shownWin = false;
        paint = (clockOnly) => {
          const b0 = best(), top = Math.max(...game.cells);
          chips([['⭐ ' + game.score], ['🔝 ' + top], b0 != null && ['🏆 ' + b0]]);
          if (clockOnly) return;
          if (game.ended) finish(false, game.score);
          info.textContent = game.ended ? '더 움직일 수 없어요.' : game.won ? game.goal + ' 달성! 계속 더 높이 올라가 보세요.' : '같은 숫자끼리 밀어서 합치세요 · 목표 ' + game.goal + ' · 방향키·스와이프';
          tiles.forEach((t, i) => {
            const v = game.cells[i];
            t.textContent = v || ''; t.dataset.v = String(v); t.dataset.d = String(String(v).length);
            t.toggleAttribute('data-new', i === game.fresh); t.toggleAttribute('data-merged', game.merged.includes(i));
          });
          if (game.ended) showResult('게임 끝', '점수 ' + game.score + ' · 최고 타일 ' + top);
          else if (game.won && !shownWin && !st.shownWin) { shownWin = st.shownWin = true; info.textContent = '🎉 ' + game.goal + ' 달성! 계속할 수 있어요.'; }
        };
      }

      if (mode === 'memory') {
        let busy = 0;
        const buttons = game.cells.map((c, i) => {
          const b = button('', () => {
            if (busy) return;
            begin();
            const r = game.flip(i);
            if (r === 'miss') { busy = setTimeout(() => { busy = 0; game.hide(); paint(); }, 800); }
            paint();
          });
          b.dataset.cell = String(i); board.append(b);
          const face = el('span', 'face');
          if (/^(blob:|https?:|\/|data:)/.test(c.face)) { const img = typeof heroNode === 'function' ? heroNode(c.face) : Object.assign(el('img'), { src: c.face, alt: '' }); face.append(img); }
          else face.append(el('i', '', c.face));
          b.append(face, el('span', 'back'));
          return b;
        });
        paint = (clockOnly) => {
          const b0 = best(), found = game.cells.filter((c) => c.done).length / 2;
          chips([['🃏 ' + found + '/' + game.pairs], ['🔁 ' + game.moves + '번'], ['⏱ ' + clock(elapsed())], b0 != null && ['🏆 ' + b0 + '번']]);
          if (clockOnly) return;
          if (game.ended) finish(true, game.moves);
          info.textContent = game.ended ? '모두 찾았어요!' : '같은 그림 두 장을 찾아 뒤집으세요';
          buttons.forEach((b, i) => { const c = game.cells[i]; b.dataset.open = String(c.open); b.dataset.done = String(c.done); b.setAttribute('aria-label', (i + 1) + '번 카드 ' + (c.open ? '앞면' : '뒷면')); });
          if (game.ended) showResult('완성!', game.moves + '번 만에 ' + clock(elapsed()));
        };
      }
      if (mode === 'shop') {
        const NAME = Object.fromEntries(SHOP_TOOLS);
        const people = faces();
        let tool = 'butter';
        // The shop front: awning and sign, the window, the menu board, the guests and the counter.
        const front = el('div', 'gfx-shop-front');
        const awning = el('div', 'gfx-shop-awning'), sign = el('b', 'gfx-shop-sign', '말랑 쿠키');
        const win = el('div', 'gfx-shop-window'), menu = el('div', 'gfx-shop-menu');
        menu.append(el('b', '', 'MENU'), ...Object.entries(SHOP_ORDERS).map(([k, label]) => { const r = el('span'); r.innerHTML = SHOP_COOKIE_SVG(k); r.append(el('i', '', label)); return r; }));
        const guests = el('div', 'gfx-shop-guests'), counter = el('div', 'gfx-shop-counter'), say = el('span', 'gfx-shop-say'), till = el('span', 'gfx-shop-till');
        counter.append(say, till);
        front.append(awning, sign, win, menu, guests, counter);
        // Each guest keeps one node while they wait; one who leaves walks off.
        const seated = new Map();
        const guestNode = (g) => {
          const n = el('div', 'gfx-shop-guest'), fig = el('span', 'fig'), order = el('span', 'order'), wait = el('i', 'wait');
          if (people.length) { const img = el('img'); img.alt = ''; img.src = people[g.id % people.length]; fig.append(img); fig.dataset.sd = ''; }
          else { fig.innerHTML = SHOP_GUEST_SVG; const [hair, shirt] = SHOP_GUEST_LOOKS[g.id % SHOP_GUEST_LOOKS.length]; fig.style.setProperty('--hair', hair); fig.style.setProperty('--shirt', shirt); }
          order.innerHTML = SHOP_COOKIE_SVG(g.want); order.append(el('i', '', SHOP_ORDERS[g.want]));
          order.append(wait); n.append(order, fig); n.dataset.want = g.want;
          return { n, wait };
        };
        // The shelf: pick a tool, then press an oven (or keys 1–7).
        const shelf = el('div', 'gfx-shop-shelf');
        const tools7 = SHOP_TOOLS.map(([k, label], n) => {
          const b = button('', () => { tool = k; paint(); }, 'gfx-shop-tool');
          const icon = el('span', 'icon'); icon.innerHTML = '<svg viewBox="0 0 44 44" aria-hidden="true">' + SHOP_TOOL_SVG[k] + '</svg>';
          b.append(el('kbd', '', String(n + 1)), icon, el('span', 'label', label)); b.dataset.tool = k; b.title = label + ' · ' + (n + 1) + '번 키'; shelf.append(b);
          return b;
        });
        // The dial's coloured zones: raw, golden, too long; the rest of the half circle is burnt.
        const span = game.bake + game.ready + game.over, arc = (a, b, cls) => {
          const p = (t) => [50 + 8.5 * Math.cos(Math.PI + Math.PI * t), 22 + 8.5 * Math.sin(Math.PI + Math.PI * t)].map((v) => v.toFixed(2)).join(' ');
          return '<path class="' + cls + '" d="M' + p(a) + 'A8.5 8.5 0 0 1 ' + p(b) + '"/>';
        };
        const zones = arc(0, game.bake / span, 'z-raw') + arc(game.bake / span, (game.bake + game.ready) / span, 'z-ready') + arc((game.bake + game.ready) / span, 1, 'z-over');
        const kitchen = el('div', 'gfx-shop-ovens');
        const ovens = game.ovens.map((_, i) => {
          const b = button('', () => {
            if (game.ended) return;
            const now = performance.now();
            begin(); game.open(now); if (!live) go();
            const r = game.use(tool, i, now);
            if (r === 'served') { coin(i, game.last); if (game.last.perfect) sparkle(i); }
            if (r === 'nobody') say.textContent = '기다리는 손님이 없어요';
            if (r === '' && tool !== 'serve') { b.dataset.nope = ''; timers.push(setTimeout(() => delete b.dataset.nope, 300)); }
            paint(false, r === 'nobody');
          });
          b.className = 'gfx-shop-oven'; b.dataset.oven = String(i);
          b.innerHTML = SHOP_OVEN_SVG(zones);
          const tag = el('span', 'tag'); b.append(tag); kitchen.append(b);
          return { b, tag };
        });
        // +price over the oven that served, and a burst of stars for a perfect cookie.
        const coin = (i, last) => {
          const p = el('span', 'gfx-shop-coin', '+' + last.price.toLocaleString() + (last.tip ? ' (팁)' : ''));
          if (!last.price) p.dataset.zero = '';
          p.style.left = (12.5 + i * 25) + '%'; board.append(p); timers.push(setTimeout(() => p.remove(), 1100));
        };
        const sparkle = (i) => { const s = el('span', 'gfx-shop-sparkle'); s.style.left = (12.5 + i * 25) + '%'; board.append(s); timers.push(setTimeout(() => s.remove(), 900)); };
        board.append(front, shelf, kitchen);
        on(board, 'keydown', (e) => { const n = Number(e.key); if (n >= 1 && n <= SHOP_TOOLS.length) { tool = SHOP_TOOLS[n - 1][0]; e.preventDefault(); paint(); } });
        board.tabIndex = 0;
        const go = () => { clearInterval(live); live = setInterval(() => { if (!game.ended) paint(); }, 100); };
        // Leaving the shop for another game pauses it: the clocks move on by the time away.
        if (st.pausedAt) { const d = performance.now() - st.pausedAt; st.pausedAt = 0; if (st.started && !game.ended) { game.shift(d); st.started += d; } }
        st.pause = () => { if (st.started && !game.ended) st.pausedAt = performance.now(); };
        if (st.started && !game.ended) go();
        let lastSaid;
        paint = (clockOnly, keepSay) => {
          const now = performance.now(), b0 = best();
          if (!clockOnly) game.update(now);
          chips([['🪙 ' + game.money.toLocaleString() + ' / ' + game.goal.toLocaleString()], ['♥'.repeat(Math.max(0, game.hearts)) || '♡', game.hearts <= 1], ['예비 오븐 ' + game.spares, !game.spares], ['⏱ ' + clock(elapsed())], b0 != null && ['🏆 ' + clock(b0 * 1000)]]);
          if (clockOnly && (!game.ended || st.endPainted)) return;
          st.endPainted = game.ended;
          if (game.ended) finish(true, game.won ? Math.round(elapsed() / 1000) : null);
          // The counter: the last guest's word, and the till.
          if (game.last !== lastSaid && !keepSay) {
            lastSaid = game.last;
            say.textContent = game.last ? game.last.line + (game.last.price != null ? ' ' + game.last.price.toLocaleString() + '원' : '') : (st.started ? '어서 오세요!' : '오늘도 영업 시작!');
            say.dataset.mood = !game.last ? '' : game.last.gone || game.last.price < 500 ? 'bad' : game.last.perfect ? 'good' : '';
            if (game.last) { delete say.dataset.pop; void say.offsetWidth; say.dataset.pop = ''; }
          }
          till.textContent = game.money.toLocaleString() + '원';
          // The guests: newcomers step in, those served or tired of waiting step out.
          const here = new Set(game.queue.map((g) => g.id));
          for (const [id, s] of seated) if (!here.has(id)) {
            seated.delete(id); s.n.dataset.leave = game.last && game.last.guest === id && !game.last.gone ? (game.last.price >= 800 ? 'happy' : 'ok') : 'angry';
            timers.push(setTimeout(() => s.n.remove(), 700));
          }
          game.queue.forEach((g) => {
            let s = seated.get(g.id);
            if (!s) { s = guestNode(g); seated.set(g.id, s); guests.append(s.n); }
            const left = Math.max(0, 1 - (now - g.came) / game.patience);
            s.wait.style.setProperty('--w', left.toFixed(3));
            s.n.dataset.mood = left > 0.55 ? 'happy' : left > 0.25 ? 'ok' : 'angry';
            s.n.setAttribute('aria-label', '손님 · ' + SHOP_ORDERS[g.want] + ' 쿠키 주문');
          });
          info.textContent = game.ended ? (game.won ? '목표 달성! 오늘 장사 끝~' : game.hearts <= 0 ? '손님들이 화가 나서 다 가 버렸어요…' : '오븐이 모두 타 버렸어요…')
            : !st.started ? '버터 → 불 켜기 → (예열 램프가 초록이면) 반죽 → 설탕 · 김이 나면 주문대로 토핑 → 접시'
            : '도구: ' + NAME[tool] + ' · 오븐을 누르세요 (숫자키 1~7)';
          tools7.forEach((b) => { b.setAttribute('aria-pressed', String(b.dataset.tool === tool)); b.disabled = game.ended; });
          game.ovens.forEach((o, i) => {
            const v = ovens[i], stage = game.stage(o, now), d = v.b.dataset;
            d.stage = stage || 'cold';
            v.b.disabled = game.ended || o === null;
            if (o) {
              d.butter = String(o.butter); d.lit = String(o.lit != null); d.dough = String(o.dough != null); d.flat = String(o.flat); d.sugar = String(o.sugar);
              d.chip = String(!!o.chip); d.cream = String(!!o.cream);
              // An empty oven smokes once it has been hot a while.
              d.warn = String(o.dough == null ? stage === 'hot' && game.dial(o, now) > 0.7 : stage === 'over');
            }
            v.b.style.setProperty('--p', game.dial(o, now).toFixed(3));
            const words = { cold: o && o.butter ? '버터 OK' : '대기', heat: '예열 중…', hot: '예열 완료!', raw: '굽는 중', ready: '지금! 노릇노릇', over: '타기 직전!', burnt: '탔다! 눌러서 치우기', gone: '고장' };
            v.tag.textContent = words[d.stage];
            v.b.setAttribute('aria-label', '오븐 ' + (i + 1) + ' · ' + words[d.stage]);
          });
          if (game.ended) showResult(game.won ? '오늘의 목표 달성!' : '가게 문을 닫았어요', '🪙 ' + game.money.toLocaleString() + '원 (팁 ' + game.tips.toLocaleString() + ') · 쿠키 ' + game.served + '개 · 완벽 ' + game.perfect + '개');
        };
      }

      if (mode === 'pinball') {
        const { W, H, R, LANE } = game;
        board.style.setProperty('--fit', (W / (H + 70)).toFixed(3));
        const canvas = el('canvas', 'gfx-pin-table'), ctx = canvas.getContext('2d');
        canvas.setAttribute('role', 'img'); canvas.setAttribute('aria-label', '핀볼 테이블');
        const pad = el('div', 'gfx-pin-pad');
        const hold = (b, down, up) => {
          on(b, 'pointerdown', (e) => { e.preventDefault(); b.setPointerCapture?.(e.pointerId); b.dataset.held = ''; down(); board.focus({ preventScroll: true }); });
          for (const t of ['pointerup', 'pointercancel', 'lostpointercapture']) on(b, t, () => { if (b.dataset.held == null) return; delete b.dataset.held; up(); });
          return b;
        };
        const leftBtn = hold(button('◀ 왼쪽', () => {}, 'gfx-pin-flip'), () => game.press(-1, true), () => game.press(-1, false));
        const launchBtn = hold(button('발사 (꾹)', () => {}, 'gfx-pin-launch'), () => { begin(); game.pull(true); }, () => game.pull(false));
        const rightBtn = hold(button('오른쪽 ▶', () => {}, 'gfx-pin-flip'), () => game.press(1, true), () => game.press(1, false));
        pad.append(leftBtn, launchBtn, rightBtn);
        board.append(canvas, pad);
        board.tabIndex = 0; board.setAttribute('role', 'application'); board.setAttribute('aria-label', '핀볼 · 왼쪽·오른쪽 방향키(또는 Z·/)로 플리퍼, 스페이스로 발사');
        // Keys: ←/Z/A and →/'/'/D flip, Space/↓/Enter pulls the plunger. Touch: the left or right half of the table.
        const KEYS = { ArrowLeft: 'L', z: 'L', Z: 'L', a: 'L', A: 'L', Shift: 'L', ArrowRight: 'R', '/': 'R', d: 'R', D: 'R', m: 'R', M: 'R', ' ': 'P', ArrowDown: 'P', Enter: 'P' };
        const act = (k, down) => { if (k === 'L') game.press(-1, down); else if (k === 'R') game.press(1, down); else { if (down) begin(); game.pull(down); } };
        on(board, 'keydown', (e) => { const k = KEYS[e.key]; if (!k) return; e.preventDefault(); if (!e.repeat) act(k, true); });
        on(board, 'keyup', (e) => { const k = KEYS[e.key]; if (!k) return; e.preventDefault(); act(k, false); });
        on(board, 'blur', () => { game.press(-1, false); game.press(1, false); game.pull(false); });
        const touches = new Map();
        on(canvas, 'pointerdown', (e) => {
          e.preventDefault(); board.focus({ preventScroll: true }); canvas.setPointerCapture?.(e.pointerId);
          const r = canvas.getBoundingClientRect(), x = (e.clientX - r.left) / r.width * W;
          const k = game.ball.lane && x > LANE - 10 ? 'P' : x < W / 2 ? 'L' : 'R';
          touches.set(e.pointerId, k); act(k, true);
        });
        for (const t of ['pointerup', 'pointercancel']) on(canvas, t, (e) => { const k = touches.get(e.pointerId); if (!k) return; touches.delete(e.pointerId); act(k, false); });
        // Colours from the 말랑 theme; the table itself is drawn once into a layer and redrawn on resize.
        const css = getComputedStyle(board), col = (v, d) => css.getPropertyValue(v).trim() || d;
        const C = { line: col('--gfx-line', '#6B4528'), ink: col('--gfx-ink', '#FFF4D9'), card: col('--gfx-card', '#FFFDF5'), accent: col('--gfx-accent', '#F0763A'), pick: col('--gfx-pick', '#FFE17A') };
        const night = panel.dataset.theme === 'night';
        let layer = null, scale = 0;
        const path = (c, pts) => { c.beginPath(); pts.forEach(([x, y], k) => (k ? c.lineTo(x, y) : c.moveTo(x, y))); };
        const drawTable = (c) => {
          c.fillStyle = C.line; c.fillRect(0, 0, W, H);
          // The playfield: the rim closed along the bottom.
          path(c, [...game.rim, [308, H], [12, H]]); c.closePath(); c.fillStyle = night ? '#22253D' : C.ink; c.fill();
          // Sprinkles on the field, the same every time.
          let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
          const SPR = night ? ['#FFF6C2', '#8EC5FF', '#D3B5FF'] : ['#F7A8C4', '#8FDDBA', '#9CC9F5', '#FFD84D', '#C9B6FF'];
          c.save(); path(c, [...game.rim, [LANE, 510], [12, 510]]); c.closePath(); c.clip();
          for (let k = 0; k < 90; k++) { const x = 16 + rnd() * 268, y = 20 + rnd() * 480; c.save(); c.translate(x, y); c.rotate(rnd() * Math.PI); c.fillStyle = SPR[k % SPR.length]; c.globalAlpha = night ? 0.5 : 0.55; c.beginPath(); c.roundRect ? c.roundRect(-3.5, -1.2, 7, 2.4, 1.2) : c.rect(-3.5, -1.2, 7, 2.4); c.fill(); c.restore(); }
          c.restore();
          // The logo and the multiplier lamps' plates.
          c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = night ? '#3B4068' : 'rgba(107,69,40,.16)';
          c.font = '26px Jua, "Malgun Gothic", sans-serif'; c.fillText('말랑 핀볼', game.cx, 318);
          // Under the inlane guides is solid rim.
          c.fillStyle = C.line; for (const pts of [[[12, 392], [90, 447], [90, H], [12, H]], [[LANE, 392], [208, 447], [208, H], [LANE, H]]]) { path(c, pts); c.closePath(); c.fill(); }
          // The launch lane.
          c.fillStyle = night ? '#171A2E' : '#EBD9BC'; c.fillRect(LANE, 150, 308 - LANE, 340);
          // Walls, guides and posts: thick, round-capped strokes.
          c.lineCap = 'round'; c.lineJoin = 'round'; c.strokeStyle = C.line;
          c.lineWidth = 6; path(c, game.rim); c.stroke();
          for (const s of game.walls.slice(game.rim.length - 1)) { c.beginPath(); c.moveTo(s[0], s[1]); c.lineTo(s[2], s[3]); c.stroke(); }
          // The slingshot triangles.
          for (const [x1, y1, x2, y2] of game.slings.map((s) => s.s)) { path(c, [[x1, y1], [x1, y2 - 26], [x2, y2]]); c.closePath(); c.fillStyle = C.pick; c.fill(); c.lineWidth = 4; c.stroke(); }
          // Arrows up the lane.
          c.fillStyle = night ? '#3B4068' : '#D9BF97';
          for (const y of [250, 300, 350]) { path(c, [[297, y - 8], [303, y + 2], [291, y + 2]]); c.closePath(); c.fill(); }
        };
        const flipperPath = (f) => {
          const tx = f.x + Math.cos(f.a) * f.len, ty = f.y + Math.sin(f.a) * f.len, nx = -Math.sin(f.a), ny = Math.cos(f.a);
          ctx.beginPath(); ctx.moveTo(f.x + nx * 7.5, f.y + ny * 7.5); ctx.lineTo(tx + nx * 4, ty + ny * 4);
          ctx.arc(tx, ty, 4, f.a + Math.PI / 2, f.a - Math.PI / 2, true); ctx.lineTo(f.x - nx * 7.5, f.y - ny * 7.5);
          ctx.arc(f.x, f.y, 7.5, f.a - Math.PI / 2, f.a + Math.PI / 2, true); ctx.closePath();
        };
        const draw = () => {
          const w = Math.round(canvas.clientWidth * (window.devicePixelRatio || 1));
          if (!w) return;
          if (w !== scale) {
            scale = w; canvas.width = w; canvas.height = Math.round(w * H / W);
            layer = document.createElement('canvas'); layer.width = canvas.width; layer.height = canvas.height;
            const c = layer.getContext('2d'); c.setTransform(w / W, 0, 0, w / W, 0, 0); drawTable(c);
          }
          const k = w / W;
          ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(layer, 0, 0); ctx.setTransform(k, 0, 0, k, 0, 0);
          ctx.lineCap = 'round'; ctx.lineJoin = 'round';
          // The top lanes: a star each, gold once rolled over.
          for (const l of game.lanes) {
            ctx.beginPath(); for (let j = 0; j < 10; j++) { const a = -Math.PI / 2 + j * Math.PI / 5, r = j % 2 ? 3.6 : 8; ctx.lineTo(l.x + Math.cos(a) * r, l.y + Math.sin(a) * r); } ctx.closePath();
            ctx.fillStyle = l.lit ? '#FFD84D' : (night ? '#3B4068' : 'rgba(107,69,40,.2)'); ctx.fill(); if (l.lit) { ctx.strokeStyle = C.line; ctx.lineWidth = 2; ctx.stroke(); }
          }
          // The multiplier lamps.
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = '13px Jua, "Malgun Gothic", sans-serif';
          [2, 3, 4, 5].forEach((m, j) => {
            const x = game.cx - 54 + j * 36, on2 = game.mult >= m;
            ctx.beginPath(); ctx.arc(x, 290, 11, 0, Math.PI * 2); ctx.fillStyle = on2 ? C.accent : (night ? '#2E3254' : 'rgba(255,255,255,.7)'); ctx.fill();
            ctx.lineWidth = 2.5; ctx.strokeStyle = C.line; ctx.stroke(); ctx.fillStyle = on2 ? '#fff' : (night ? '#6A70A8' : '#B59C80'); ctx.fillText('×' + m, x, 291);
          });
          // The bumpers: donuts with icing and sprinkles; they swell when hit.
          const ICE = ['#F7A8C4', '#8FDDBA', '#FFD84D'];
          game.bumpers.forEach((p, j) => {
            const s = 1 + p.flash * 1.2, r = p.r * s;
            if (p.flash) { ctx.beginPath(); ctx.arc(p.x, p.y, r + 7 * (1 - p.flash * 5), 0, Math.PI * 2); ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = 3; ctx.stroke(); }
            ctx.beginPath(); ctx.arc(p.x, p.y + 2, r, 0, Math.PI * 2); ctx.fillStyle = 'rgba(0,0,0,.18)'; ctx.fill();
            ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, Math.PI * 2); ctx.fillStyle = '#E7A552'; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = C.line; ctx.stroke();
            ctx.beginPath(); for (let q = 0; q <= 16; q++) { const a = q / 16 * Math.PI * 2, rr = r * (0.82 + (q % 2) * 0.06); ctx.lineTo(p.x + Math.cos(a) * rr, p.y + Math.sin(a) * rr); }
            ctx.fillStyle = p.flash ? '#fff' : ICE[j % ICE.length]; ctx.fill();
            ctx.beginPath(); ctx.arc(p.x, p.y, r * 0.32, 0, Math.PI * 2); ctx.fillStyle = night ? '#22253D' : C.ink; ctx.fill(); ctx.lineWidth = 2.5; ctx.stroke();
            ['#fff', '#3E2616', '#9CC9F5', '#fff', '#3E2616'].forEach((c2, q) => { const a = q * 1.3 + j, rr = r * 0.6; ctx.save(); ctx.translate(p.x + Math.cos(a) * rr, p.y + Math.sin(a) * rr); ctx.rotate(a); ctx.fillStyle = c2; ctx.fillRect(-2.2, -0.9, 4.4, 1.8); ctx.restore(); });
          });
          // Slingshots flash white when they kick.
          for (const sl of game.slings) if (sl.flash) { const [x1, y1, x2, y2] = sl.s; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.strokeStyle = '#fff'; ctx.lineWidth = 5; ctx.stroke(); }
          // The flippers.
          for (const f of game.flippers) {
            ctx.save(); ctx.translate(0, 2.5); flipperPath(f); ctx.fillStyle = 'rgba(0,0,0,.2)'; ctx.fill(); ctx.restore();
            flipperPath(f); ctx.fillStyle = C.accent; ctx.fill(); ctx.lineWidth = 2.8; ctx.strokeStyle = C.line; ctx.stroke();
            ctx.beginPath(); ctx.arc(f.x, f.y, 2.6, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill();
          }
          // The plunger spring squeezes as it is pulled.
          const top = 490 + game.charge * 14;
          ctx.beginPath(); for (let j = 0; j <= 8; j++) ctx.lineTo(j % 2 ? 291 : 303, top + j * (512 - top) / 8); ctx.strokeStyle = night ? '#8EC5FF' : '#B59C80'; ctx.lineWidth = 2.5; ctx.stroke();
          ctx.fillStyle = C.accent; ctx.fillRect(289, top - 3, 16, 5);
          if (game.pulling) { ctx.fillStyle = '#FFD84D'; ctx.fillRect(LANE + 2, 500 - game.charge * 60, 3, game.charge * 60); }
          // The ball: a white gumball with a shine.
          const b = game.ball;
          if (b.y < H + R) {
            ctx.beginPath(); ctx.arc(b.x + 1.5, b.y + 2.5, R, 0, Math.PI * 2); ctx.fillStyle = 'rgba(0,0,0,.22)'; ctx.fill();
            ctx.beginPath(); ctx.arc(b.x, b.y, R, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill(); ctx.lineWidth = 2.4; ctx.strokeStyle = C.line; ctx.stroke();
            ctx.beginPath(); ctx.arc(b.x - 2.2, b.y - 2.4, 2, 0, Math.PI * 2); ctx.fillStyle = '#C9E6FF'; ctx.fill();
          }
          // Score popups and the table's announcements.
          ctx.font = '12px Jua, "Malgun Gothic", sans-serif'; ctx.lineWidth = 3;
          for (const p of game.popups) { const y = p.y - p.t * 30; ctx.globalAlpha = Math.max(0, 1 - p.t / 0.8); ctx.strokeStyle = C.line; ctx.strokeText(p.text, p.x, y); ctx.fillStyle = '#FFD84D'; ctx.fillText(p.text, p.x, y); }
          ctx.globalAlpha = 1;
          if (game.note) {
            const a = Math.min(1, (1.6 - game.note.t) * 3); ctx.globalAlpha = Math.max(0, a); ctx.font = '22px Jua, "Malgun Gothic", sans-serif'; ctx.lineWidth = 5;
            ctx.strokeStyle = C.line; ctx.strokeText(game.note.text, game.cx, 360); ctx.fillStyle = '#fff'; ctx.fillText(game.note.text, game.cx, 360); ctx.globalAlpha = 1;
          }
          if (!st.started && b.lane) {
            ctx.font = '14px Jua, "Malgun Gothic", sans-serif'; ctx.lineWidth = 4; ctx.strokeStyle = C.line; ctx.fillStyle = '#fff';
            ctx.strokeText('꾹 눌렀다 떼면 발사!', game.cx, 352); ctx.fillText('꾹 눌렀다 떼면 발사!', game.cx, 352);
          }
        };
        // The loop: physics by real time, drawing each frame; it stops once the table is off screen.
        let last = 0, shown = '';
        const loop = (t) => {
          frame = 0;
          if (!content.contains(board) || !board.isConnected) return;
          const ms = last ? Math.min(50, t - last) : 16; last = t;
          if (!game.ended) game.step(ms);
          draw();
          const sig = game.score + '/' + game.balls + '/' + game.ended + '/' + game.mult + '/' + game.ball.lane;
          if (sig !== shown) { shown = sig; paint(); }
          if (!game.ended) frame = requestAnimationFrame(loop);
        };
        frame = requestAnimationFrame(loop);
        paint = (clockOnly) => {
          const b0 = best();
          chips([['🎯 ' + game.score.toLocaleString()], ['● '.repeat(Math.max(0, game.balls)).trim() || '—', game.balls === 1], ['×' + game.mult], b0 != null && ['🏆 ' + b0.toLocaleString()]]);
          if (clockOnly) return;
          if (game.ended) finish(false, game.score);
          launchBtn.disabled = game.ended || !game.ball.lane; leftBtn.disabled = rightBtn.disabled = game.ended;
          info.textContent = game.ended ? '공을 모두 잃었어요!' : game.ball.lane ? '스페이스(또는 [발사])를 꾹 눌렀다 떼서 공을 쏘아요' : '←·Z 왼쪽 / →·D 오른쪽 플리퍼 · 위쪽 별 3개를 다 켜면 배수 업!';
          if (game.ended) { draw(); showResult('게임 오버', game.score.toLocaleString() + '점 · 최고 배수 ×' + game.top); }
        };
      }

      if (mode === 'bricks') {
        const { W, H, R, PY, BW, BH } = game;
        board.style.setProperty('--fit', (W / (H + 60)).toFixed(3));
        const canvas = el('canvas', 'gfx-pin-table'), ctx = canvas.getContext('2d');
        canvas.style.aspectRatio = W + ' / ' + H;
        canvas.setAttribute('role', 'img'); canvas.setAttribute('aria-label', '벽돌깨기 판');
        const pad = el('div', 'gfx-pin-pad');
        const hold = (b, down, up) => {
          on(b, 'pointerdown', (e) => { e.preventDefault(); b.setPointerCapture?.(e.pointerId); b.dataset.held = ''; down(); board.focus({ preventScroll: true }); });
          for (const t of ['pointerup', 'pointercancel', 'lostpointercapture']) on(b, t, () => { if (b.dataset.held == null) return; delete b.dataset.held; up(); });
          return b;
        };
        const leftBtn = hold(button('◀', () => {}, 'gfx-pin-flip'), () => game.move(-1), () => game.move(0));
        const launchBtn = hold(button('발사', () => {}, 'gfx-pin-launch'), () => { begin(); game.launch(); }, () => {});
        const rightBtn = hold(button('▶', () => {}, 'gfx-pin-flip'), () => game.move(1), () => game.move(0));
        leftBtn.setAttribute('aria-label', '왼쪽으로'); rightBtn.setAttribute('aria-label', '오른쪽으로');
        pad.append(leftBtn, launchBtn, rightBtn);
        board.append(canvas, pad);
        board.tabIndex = 0; board.setAttribute('role', 'application'); board.setAttribute('aria-label', '벽돌깨기 · 마우스나 방향키로 뒤집개를 움직이고 스페이스로 발사');
        // Keys move the spatula; the pointer over the table steers it, and a tap launches.
        const held = { L: false, R: false };
        const KEYS = { ArrowLeft: 'L', a: 'L', A: 'L', ArrowRight: 'R', d: 'R', D: 'R', ' ': 'P', ArrowUp: 'P', Enter: 'P' };
        const steer = () => game.move((held.R ? 1 : 0) - (held.L ? 1 : 0));
        on(board, 'keydown', (e) => { const k = KEYS[e.key]; if (!k) return; e.preventDefault(); if (k === 'P') { begin(); game.launch(); } else { held[k] = true; steer(); } });
        on(board, 'keyup', (e) => { const k = KEYS[e.key]; if (!k || k === 'P') return; e.preventDefault(); held[k] = false; steer(); });
        on(board, 'blur', () => { held.L = held.R = false; game.move(0); });
        const toX = (e) => { const r = canvas.getBoundingClientRect(); return (e.clientX - r.left) / r.width * W; };
        on(canvas, 'pointermove', (e) => game.aim(toX(e)));
        on(canvas, 'pointerdown', (e) => { e.preventDefault(); board.focus({ preventScroll: true }); canvas.setPointerCapture?.(e.pointerId); game.aim(toX(e)); begin(); game.launch(); });
        // Colours from the 말랑 theme; the gingham cloth is drawn once into a layer and redrawn on resize.
        const css = getComputedStyle(board), col = (v, d) => css.getPropertyValue(v).trim() || d;
        const C = { line: col('--gfx-line', '#6B4528'), ink: col('--gfx-ink', '#FFF4D9'), accent: col('--gfx-accent', '#F0763A'), pick: col('--gfx-pick', '#FFE17A') };
        const night = panel.dataset.theme === 'night';
        const ROW = ['#F7A8C4', '#FFC27A', '#FFE07A', '#8FDDBA', '#9CC9F5', '#C9B6FF', '#F7A8C4', '#FFC27A'];
        let layer = null, scale = 0;
        const rr = (c, x, y, w, h, r) => { c.beginPath(); c.roundRect ? c.roundRect(x, y, w, h, r) : c.rect(x, y, w, h); };
        const drawCloth = (c) => {
          c.fillStyle = night ? '#22253D' : C.ink; c.fillRect(0, 0, W, H);
          c.fillStyle = night ? 'rgba(140,150,230,.08)' : 'rgba(240,118,58,.08)';
          for (let x = 0; x < W; x += 40) c.fillRect(x, 0, 20, H);
          for (let y = 0; y < H; y += 40) c.fillRect(0, y, W, 20);
          c.strokeStyle = C.line; c.lineWidth = 8; c.strokeRect(0, 0, W, H);
        };
        const draw = () => {
          const w = Math.round(canvas.clientWidth * (window.devicePixelRatio || 1));
          if (!w) return;
          if (w !== scale) {
            scale = w; canvas.width = w; canvas.height = Math.round(w * H / W);
            layer = document.createElement('canvas'); layer.width = canvas.width; layer.height = canvas.height;
            const c = layer.getContext('2d'); c.setTransform(w / W, 0, 0, w / W, 0, 0); drawCloth(c);
          }
          const k = w / W;
          ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(layer, 0, 0); ctx.setTransform(k, 0, 0, k, 0, 0);
          ctx.lineJoin = 'round'; ctx.lineCap = 'round';
          // Biscuits: icing by row, sugar dots; chocolate ones crack after the first hit.
          for (const b of game.bricks) {
            const choc = b.max > 1, lift = b.hit ? -1.5 : 0;
            rr(ctx, b.x, b.y + 2, BW, BH, 5); ctx.fillStyle = 'rgba(0,0,0,.15)'; ctx.fill();
            rr(ctx, b.x, b.y + lift, BW, BH, 5); ctx.fillStyle = choc ? '#6B4528' : '#E7A552'; ctx.fill(); ctx.lineWidth = 2.2; ctx.strokeStyle = C.line; ctx.stroke();
            rr(ctx, b.x + 3, b.y + 2.5 + lift, BW - 6, BH - 6, 3.5); ctx.fillStyle = b.hit ? '#fff' : choc ? '#8A5A33' : ROW[b.row % ROW.length]; ctx.fill();
            ctx.fillStyle = choc ? '#C2803F' : 'rgba(255,255,255,.85)';
            for (const [dx, dy] of [[8, 5], [17, 8], [26, 5]]) { ctx.beginPath(); ctx.arc(b.x + dx, b.y + dy + lift, 1.1, 0, Math.PI * 2); ctx.fill(); }
            if (choc && b.hp < b.max) { ctx.beginPath(); ctx.moveTo(b.x + 10, b.y + 2 + lift); ctx.lineTo(b.x + 15, b.y + 8 + lift); ctx.lineTo(b.x + 12, b.y + 13 + lift); ctx.moveTo(b.x + 15, b.y + 8 + lift); ctx.lineTo(b.x + 22, b.y + 10 + lift); ctx.strokeStyle = '#2A180C'; ctx.lineWidth = 1.4; ctx.stroke(); }
          }
          // Falling treats.
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          for (const it of game.items) {
            ctx.beginPath(); ctx.arc(it.x, it.y, 8, 0, Math.PI * 2); ctx.fillStyle = it.kind === 'heart' ? '#F2557F' : C.pick; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = C.line; ctx.stroke();
            ctx.fillStyle = it.kind === 'heart' ? '#fff' : C.line; ctx.font = '11px Jua, "Malgun Gothic", sans-serif'; ctx.fillText(it.kind === 'heart' ? '♥' : '길', it.x, it.y + 0.5);
          }
          // The spatula: a wooden handle under a rounded blade.
          const p = game.paddle, half = (p.long > 0 ? p.w * 1.5 : p.w) / 2;
          rr(ctx, p.x - 5, PY + 9, 10, 14, 3); ctx.fillStyle = '#B07A47'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = C.line; ctx.stroke();
          rr(ctx, p.x - half, PY + 2, half * 2, 10, 5); ctx.fillStyle = 'rgba(0,0,0,.18)'; ctx.fill();
          rr(ctx, p.x - half, PY, half * 2, 10, 5); ctx.fillStyle = p.long > 0 && (p.long > 2 || Math.floor(p.long * 6) % 2) ? C.pick : C.accent; ctx.fill(); ctx.lineWidth = 2.5; ctx.stroke();
          ctx.beginPath(); ctx.moveTo(p.x - half + 6, PY + 3); ctx.lineTo(p.x + half * 0.3, PY + 3); ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 2; ctx.stroke();
          // The gumball.
          const b = game.ball;
          if (b.y < H + R) {
            ctx.beginPath(); ctx.arc(b.x + 1.5, b.y + 2, R, 0, Math.PI * 2); ctx.fillStyle = 'rgba(0,0,0,.2)'; ctx.fill();
            ctx.beginPath(); ctx.arc(b.x, b.y, R, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill(); ctx.lineWidth = 2.2; ctx.strokeStyle = C.line; ctx.stroke();
            ctx.beginPath(); ctx.arc(b.x - 1.8, b.y - 2, 1.7, 0, Math.PI * 2); ctx.fillStyle = '#C9E6FF'; ctx.fill();
          }
          // Score popups and announcements.
          ctx.font = '12px Jua, "Malgun Gothic", sans-serif'; ctx.lineWidth = 3;
          for (const q of game.popups) { const y = q.y - q.t * 26; ctx.globalAlpha = Math.max(0, 1 - q.t / 0.8); ctx.strokeStyle = C.line; ctx.strokeText(q.text, q.x, y); ctx.fillStyle = '#FFD84D'; ctx.fillText(q.text, q.x, y); }
          ctx.globalAlpha = 1;
          const say = (text, y, size) => { ctx.font = size + 'px Jua, "Malgun Gothic", sans-serif'; ctx.lineWidth = 5; ctx.strokeStyle = C.line; ctx.strokeText(text, W / 2, y); ctx.fillStyle = '#fff'; ctx.fillText(text, W / 2, y); };
          if (game.note) { ctx.globalAlpha = Math.max(0, Math.min(1, (1.6 - game.note.t) * 3)); say(game.note.text, 290, 22); ctx.globalAlpha = 1; }
          else if (b.stuck && !game.ended) say('스페이스나 탭으로 발사!', 330, 15);
        };
        let last = 0, shown = '';
        const loop = (t) => {
          frame = 0;
          if (!content.contains(board) || !board.isConnected) return;
          const ms = last ? Math.min(50, t - last) : 16; last = t;
          if (!game.ended) game.step(ms);
          draw();
          const sig = game.score + '/' + game.lives + '/' + game.stage + '/' + game.ended + '/' + game.ball.stuck;
          if (sig !== shown) { shown = sig; paint(); }
          if (!game.ended) frame = requestAnimationFrame(loop);
        };
        frame = requestAnimationFrame(loop);
        paint = (clockOnly) => {
          const b0 = best();
          chips([['🧁 ' + game.score.toLocaleString()], ['♥'.repeat(Math.max(0, Math.min(game.lives, 6))) + (game.lives > 6 ? '+' : '') || '♡', game.lives === 1], ['스테이지 ' + game.stage], b0 != null && ['🏆 ' + b0.toLocaleString()]]);
          if (clockOnly) return;
          if (game.ended) finish(false, game.score);
          launchBtn.disabled = game.ended || !game.ball.stuck; leftBtn.disabled = rightBtn.disabled = game.ended;
          info.textContent = game.ended ? '하트를 모두 잃었어요!' : game.ball.stuck ? '스페이스(또는 탭)로 발사 · 뒤집개 끝에 맞을수록 비스듬히 튀어요' : '마우스·←→로 뒤집개 이동 · 초코 비스킷은 두 번 · 떨어지는 간식을 받아요';
          if (game.ended) { draw(); showResult('게임 오버', game.score.toLocaleString() + '점 · 스테이지 ' + game.stage + ' · 비스킷 ' + game.broken + '개'); }
        };
      }

      if (mode === 'snake') {
        board.tabIndex = 0; board.setAttribute('role', 'application'); board.setAttribute('aria-label', '스네이크 · 방향키나 스와이프로 움직이기');
        const cells = Array.from({ length: game.cols * game.rows }, (_, i) => { const d = el('div'); d.dataset.cell = String(i); board.append(d); return d; });
        const shown = cells.map(() => '');
        const go = () => { clearInterval(live); live = setInterval(() => { game.step(); paint(); if (game.ended) { clearInterval(live); live = 0; } }, game.speed); };
        const push = (dir) => { if (game.ended) return; game.turn(dir); if (!st.started) { begin(); go(); } board.focus({ preventScroll: true }); };
        if (st.started && !game.ended) go();
        const pad = el('div', 'gfx-game-pad');
        for (const [dir, label, arrow] of [['up', '위로', '▲'], ['left', '왼쪽으로', '◀'], ['down', '아래로', '▼'], ['right', '오른쪽으로', '▶']]) { const b = button(arrow, () => push(dir)); b.setAttribute('aria-label', label); b.dataset.dir = dir; pad.append(b); }
        stage.append(pad);
        const KEYS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right', w: 'up', s: 'down', a: 'left', d: 'right', W: 'up', S: 'down', A: 'left', D: 'right' };
        on(board, 'keydown', (e) => { const dir = KEYS[e.key]; if (!dir) return; e.preventDefault(); push(dir); });
        let from = null;
        on(board, 'pointerdown', (e) => { from = [e.clientX, e.clientY, e.pointerId]; board.setPointerCapture?.(e.pointerId); });
        on(board, 'pointerup', (e) => {
          if (!from || from[2] !== e.pointerId) return;
          const dx = e.clientX - from[0], dy = e.clientY - from[1]; from = null;
          if (Math.max(Math.abs(dx), Math.abs(dy)) < 20) { board.focus({ preventScroll: true }); return; }
          push(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up'));
        });
        on(board, 'pointercancel', () => { from = null; });
        paint = (clockOnly) => {
          const b0 = best();
          chips([['🐍 ' + game.body.length], ['⭐ ' + game.score], b0 != null && ['🏆 ' + b0]]);
          if (clockOnly) return;
          if (game.ended) finish(false, game.score);
          info.textContent = game.ended ? (game.won ? '판을 꽉 채웠어요!' : '쿵! 다시 해 볼까요?') : !st.started ? '방향키·WASD·스와이프로 시작해요' : '먹을 걸 먹으면 길어져요 · 벽과 몸에 부딪히면 끝';
          // Only the cells that changed are touched each step.
          const next = cells.map(() => '');
          game.body.forEach((i, k) => { next[i] = k ? 'body' : 'head'; });
          if (game.food >= 0) next[game.food] = 'food';
          next.forEach((s, i) => { if (shown[i] !== s) { shown[i] = s; if (s) cells[i].dataset.s = s; else delete cells[i].dataset.s; } });
          cells[game.body[0]].dataset.dir = game.dir;
          if (game.ended) showResult(game.won ? '완벽해요!' : '게임 끝', '먹은 개수 ' + game.score + ' · 길이 ' + game.body.length);
        };
      }

      if (mode === 'recipe') {
        const NAMES = ['딸기', '우유', '설탕', '얼음', '연유', '생크림'];
        board.style.setProperty('--cols', String(game.pads > 4 ? 3 : 2));
        board.style.setProperty('--fit', game.pads > 4 ? '1.5' : '1');
        let playing = false;
        const pads = Array.from({ length: game.pads }, (_, i) => {
          const b = button(NAMES[i], () => {
            if (playing || game.ended) return;
            begin(); flash(i, 180);
            const r = game.press(i);
            if (r === 'round') setTimeout(play, 650);
            paint();
          });
          b.dataset.cell = String(i); b.dataset.pad = String(i); board.append(b); return b;
        });
        const flash = (i, ms) => { pads[i].dataset.lit = ''; setTimeout(() => delete pads[i].dataset.lit, ms); };
        const play = () => {
          if (game.ended || !content.contains(board)) return;
          playing = true; paint();
          game.sequence.forEach((p, k) => { const t = setTimeout(() => flash(p, game.speed * 0.7), 300 + k * game.speed); timers.push(t); });
          timers.push(setTimeout(() => { playing = false; paint(); }, 300 + game.sequence.length * game.speed));
        };
        const startBtn = button('시작', () => { if (playing || st.started) return; begin(); play(); }, 'gfx-game-hint');
        tools.append(startBtn);
        // Reopening a suspended sequence must replay it instead of leaving an unknowable round.
        if (st.started && !game.ended) { game.at = 0; setTimeout(play, 0); }
        paint = (clockOnly) => {
          const b0 = best();
          chips([['🥛 ' + game.round + '단계'], b0 != null && ['🏆 ' + b0 + '단계']]);
          if (clockOnly) return;
          startBtn.disabled = !!st.started;
          if (game.ended) finish(false, game.round);
          info.textContent = game.ended ? '레시피가 틀렸어요!' : !st.started ? '[시작]을 누르고 재료 순서를 기억하세요' : playing ? '잘 보세요…' : '같은 순서로 넣으세요 (' + game.at + '/' + game.sequence.length + ')';
          pads.forEach((b) => { b.disabled = game.ended || playing || !st.started; });
          if (game.ended) showResult('레시피 실패!', game.round + '단계까지 성공했어요');
        };
      }

      if (mode === 'pop') {
        const cells = game.cells.map((_, i) => {
          const b = button('', () => { if (game.ended) return; begin(); game.pop(i); hover = -1; paint(); });
          b.dataset.cell = String(i); board.append(b);
          on(b, 'pointerenter', () => { hover = i; paint(); }); on(b, 'pointerleave', () => { if (hover === i) { hover = -1; paint(); } });
          return b;
        });
        let hover = -1;
        paint = (clockOnly) => {
          const b0 = best(), left = game.cells.filter(Boolean).length;
          chips([['🍫 ' + game.score + '점'], ['남은 칩 ' + left], b0 != null && ['🏆 ' + b0 + '점']]);
          if (clockOnly) return;
          if (game.ended) finish(false, game.score);
          const group = hover >= 0 ? game.group(hover) : [];
          info.textContent = game.ended ? (game.won ? '모두 터뜨렸어요! +100' : '더 터뜨릴 덩어리가 없어요') : group.length > 1 ? group.length + '개 덩어리 · ' + (group.length - 1) * (group.length - 1) + '점' : '같은 색이 2개 이상 붙어 있으면 눌러 터뜨려요';
          cells.forEach((b, i) => { const v = game.cells[i]; b.dataset.v = String(v); b.dataset.group = String(group.length > 1 && group.includes(i)); b.disabled = game.ended || !v; b.setAttribute('aria-label', (i + 1) + '번 칩 ' + (v || '빈 칸')); });
          if (game.ended) showResult(game.won ? '깨끗하게 비웠어요!' : '게임 끝', game.score + '점');
        };
      }

      if (mode === 'slide') {
        const cells = game.cells.map((_, i) => { const b = button('', () => { begin(); if (game.slide(i)) paint(); }); b.dataset.cell = String(i); board.append(b); return b; });
        paint = (clockOnly) => {
          const b0 = best();
          chips([['🔁 ' + game.moves + '번'], ['⏱ ' + clock(elapsed())], b0 != null && ['🏆 ' + b0 + '번']]);
          if (clockOnly) return;
          if (game.ended) finish(true, game.moves);
          info.textContent = game.ended ? '꽃밭 완성!' : '빈칸 옆 조각을 눌러 1부터 순서대로 맞추세요';
          cells.forEach((b, i) => { const v = game.cells[i]; b.textContent = v ? String(v) : ''; b.dataset.blank = String(!v); b.dataset.home = String(!!v && v === i + 1); b.disabled = game.ended || !v; b.setAttribute('aria-label', v ? v + '번 조각' : '빈칸'); });
          if (game.ended) showResult('꽃밭 완성!', game.moves + '번 · ' + clock(elapsed()));
        };
      }

      if (mode === 'lights') {
        const cells = game.cells.map((_, i) => { const b = button('', () => { begin(); game.press(i); paint(); }); b.dataset.cell = String(i); board.append(b); return b; });
        paint = (clockOnly) => {
          const b0 = best(), lit = game.cells.filter(Boolean).length;
          chips([['⭐ ' + lit + '/' + game.cells.length], ['🔁 ' + game.moves + '번'], b0 != null && ['🏆 ' + b0 + '번']]);
          if (clockOnly) return;
          if (game.ended) finish(true, game.moves);
          info.textContent = game.ended ? '밤하늘이 가득 찼어요!' : '누른 별과 상하좌우가 켜졌다 꺼져요 · 모든 별을 밝히세요';
          cells.forEach((b, i) => { b.dataset.on = String(game.cells[i]); b.disabled = game.ended; b.setAttribute('aria-label', (i + 1) + '번 별 ' + (game.cells[i] ? '켜짐' : '꺼짐')); });
          if (game.ended) showResult('모든 별 반짝!', game.moves + '번 만에');
        };
      }
      paintNow = (clockOnly) => { if (!content.contains(board)) return; paint(clockOnly); };
      paint();
      // Games played with the keyboard take focus, so arrow and number keys work straight away.
      if (['merge', 'snake', 'shop', 'pinball', 'bricks'].includes(mode)) board.focus({ preventScroll: true });
    }
    panel.pause = () => {
      if (suspended) return;
      stopTimers(); panelLife.clearTimers(); suspended = true;
      if (mode === 'memory') states[mode].game.hide();
    };
    panel.resume = () => { clearInterval(tick); tick = setInterval(paintTick, 250); if (mode) show(mode); };
    panel.dispose = () => { stopTimers(); panelLife.dispose(); };
    return panel;
  }


  const CSS = "/* Buttons: the 말랑 capsule that presses down. */\n.gfx-load-games button { font:inherit; color:var(--gfx-text, #5A3A24); background:var(--gfx-card, #FFFDF5); border:2.5px solid var(--gfx-line, #6B4528); border-radius:999px; padding:.42em .95em; cursor:pointer;\n  box-shadow:0 3px 0 var(--gfx-line, #6B4528); transition:translate .1s ease, box-shadow .1s ease, background .15s ease; }\n.gfx-load-games button:not(.gfx-game-board > *, .gfx-shop-oven):hover:not(:disabled) { background:color-mix(in srgb,var(--gfx-pick, #FFE17A) 45%,var(--gfx-card, #FFFDF5)); }\n.gfx-load-games button:active:not(:disabled) { translate:0 2px; box-shadow:0 1px 0 var(--gfx-line, #6B4528); }\n.gfx-load-games button:disabled { cursor:default; }\n.gfx-load-games button[aria-pressed=\"true\"] { background:var(--gfx-pick, #FFE17A); }\n.gfx-load-games button:focus-visible, .gfx-game-board:focus-visible { outline:3px solid var(--gfx-accent, #F0763A); outline-offset:2px; }\n/* The game shelf: one card per game. */\n.gfx-game-nav { display:flex; flex-wrap:wrap; justify-content:center; align-items:center; gap:8px; margin-bottom:10px; padding:8px; border:3px solid var(--gfx-line, #6B4528); border-radius:22px;\n  background:color-mix(in srgb,var(--gfx-card, #FFFDF5) 94%,transparent); box-shadow:0 4px 0 var(--gfx-line, #6B4528); }\n.gfx-game-tab { display:flex; flex-direction:column; align-items:center; gap:1px; border-radius:16px !important; padding:.4em .75em !important; min-width:5.4em; }\n.gfx-game-tab i { font-style:normal; font-size:1.7em; line-height:1.15; }\n.gfx-game-tab span { font-size:.9em; white-space:nowrap; }\n.gfx-game-tab[aria-pressed=\"true\"] { background:var(--gfx-accent, #F0763A) !important; color:#fff !important; }\n.gfx-game-utils { display:flex; flex-wrap:wrap; justify-content:center; gap:6px; }\n.gfx-game-util { font-size:.82em !important; padding:.35em .8em !important; box-shadow:0 2px 0 var(--gfx-line, #6B4528) !important; }\n/* The game card. */\n.gfx-game-content:empty { display:none; }\n.gfx-game-content { background:var(--gfx-card, #FFFDF5); border:3px solid var(--gfx-line, #6B4528); border-radius:22px; padding:12px 14px 14px; box-shadow:0 5px 0 var(--gfx-line, #6B4528); }\n.gfx-game-head { display:flex; align-items:center; justify-content:space-between; gap:6px 10px; flex-wrap:wrap; margin-bottom:6px; }\n.gfx-game-title { display:flex; align-items:center; gap:.3em; font-size:1.12em; font-weight:normal; white-space:nowrap; }\n.gfx-game-title i { font-style:normal; }\n.gfx-game-stats { display:flex; gap:6px; flex-wrap:wrap; justify-content:flex-end; }\n.gfx-game-stats { font-size:.86em; }\n.gfx-game-stats span { padding:.1em .6em; border-radius:999px; background:var(--gfx-ink, #FFF4D9); border:2px solid color-mix(in srgb,var(--gfx-line, #6B4528) 35%,transparent); font-variant-numeric:tabular-nums; white-space:nowrap; }\n.gfx-game-stats span[data-alert] { background:#FFD9D4; color:#A1281C; border-color:#E0786B; animation:gfx-game-blink .8s ease-in-out infinite; }\n@keyframes gfx-game-blink { 50% { opacity:.55; } }\n/* Level, new game and the game tool: one small row inside the header. */\n.gfx-game-tools { flex:1 1 auto; display:flex; flex-wrap:wrap; align-items:center; justify-content:center; gap:5px; font-size:.82em; }\n.gfx-game-tools > button { padding:.2em .75em; border-width:2px; box-shadow:0 2px 0 var(--gfx-line, #6B4528); }\n.gfx-game-levels { display:inline-flex; gap:2px; padding:2px; border:2px solid var(--gfx-line, #6B4528); border-radius:999px; background:var(--gfx-ink, #FFF4D9); }\n.gfx-game-levels button { line-height:1.2; padding:.16em .7em; border:0; background:transparent; box-shadow:none; }\n.gfx-game-levels button:active:not(:disabled) { translate:none; box-shadow:none; }\n.gfx-game-levels button[aria-checked=\"true\"] { background:var(--gfx-accent, #F0763A); color:#fff; }\n.gfx-game-new { background:var(--gfx-pick, #FFE17A) !important; }\n.gfx-game-flag[aria-pressed=\"true\"] { background:#FFD9D4 !important; }\n.gfx-game-info { min-height:1.5em; text-align:center; margin-bottom:8px; font-size:.95em; }\n.gfx-game-info b { font-weight:normal; padding:0 .4em; border-radius:999px; background:var(--gfx-ink, #FFF4D9); }\n.gfx-game-info b[data-ok] { background:#C9F0D6; color:#1C7A43; }\n.gfx-game-info b[data-over] { background:#FFD9D4; color:#A1281C; }\n/* The board: square cells sized from the board's own width. */\n.gfx-game-stage { position:relative; }\n.gfx-game-board { display:grid; grid-template-columns:repeat(var(--cols),minmax(0,1fr)); gap:4px; width:min(100%, max(170px, var(--room) * var(--fit, 1))); margin:auto; padding:6px; box-sizing:border-box;\n  border-radius:16px; background:color-mix(in srgb,var(--gfx-line, #6B4528) 16%,var(--gfx-ink, #FFF4D9)); touch-action:none; user-select:none; -webkit-user-select:none; container-type:inline-size; }\n.gfx-game-board > * { position:relative; aspect-ratio:1; min-width:0; min-height:0; padding:0 !important; display:grid; place-items:center; border-radius:9px !important; box-sizing:border-box;\n  font-size:calc(100cqw / var(--cols) * .46); line-height:1; }\n/* 지뢰찾기 */\n.gfx-game-board[data-kind=\"mines\"] > button { background:var(--gfx-pick, #FFE17A); border-width:2px; box-shadow:0 2px 0 var(--gfx-line, #6B4528); }\n.gfx-game-board[data-kind=\"mines\"] > button[data-open=\"true\"] { background:var(--gfx-card, #FFFDF5); border-color:color-mix(in srgb,var(--gfx-line, #6B4528) 25%,transparent); box-shadow:none; translate:none; }\n.gfx-game-board > button[data-mine=\"true\"]::before { content:\"\"; width:52%; aspect-ratio:1; border-radius:50%; background:#262626;\n  box-shadow:0 0 0 .12em #1f1f1f, 0 -.28em 0 -.16em #1f1f1f, 0 .28em 0 -.16em #1f1f1f, .28em 0 0 -.16em #1f1f1f, -.28em 0 0 -.16em #1f1f1f; }\n.gfx-game-board > button[data-boom=\"true\"] { background:#FF6B5E !important; animation:gfx-game-shake .35s ease; }\n.gfx-game-board > button[data-wrong=\"true\"] { opacity:.45; }\n@keyframes gfx-game-shake { 25% { translate:-3px 0; } 75% { translate:3px 0; } }\n.gfx-game-board button[data-flag=\"true\"] { font-size:0 !important; background:var(--gfx-card, #FFFDF5); }\n.gfx-game-board button[data-flag=\"true\"]::before { content:\"\"; position:absolute; left:34%; top:18%; height:62%; border-left:3px solid #432e23; }\n.gfx-game-board button[data-flag=\"true\"]::after { content:\"\"; position:absolute; left:calc(34% + 3px); top:18%; width:42%; height:36%; background:#e13f35; clip-path:polygon(0 0,100% 25%,0 100%); }\n/* 사과 상자 */\n.gfx-game-board[data-kind=\"fruits\"] { gap:2px; position:relative; }\n.gfx-game-board > .gfx-fruit-frame { position:absolute; z-index:2; aspect-ratio:auto; display:block; pointer-events:none; box-sizing:border-box; border-radius:14px !important;\n  border:4px solid var(--gfx-accent, #F0763A); background:color-mix(in srgb,var(--gfx-accent, #F0763A) 22%,transparent); box-shadow:0 0 0 2px #fff, 0 0 14px color-mix(in srgb,var(--gfx-accent, #F0763A) 70%,transparent);\n  transition:left .06s linear, top .06s linear, width .06s linear, height .06s linear; }\n.gfx-game-board > .gfx-fruit-frame[hidden] { display:none; }\n\n.gfx-game-board > .gfx-fruit-frame[data-state=\"ok\"] { border-color:#2FA95E; background:color-mix(in srgb,#2FA95E 26%,transparent); box-shadow:0 0 0 2px #fff, 0 0 16px #2FA95EAA; }\n\n.gfx-game-board > .gfx-fruit-frame[data-state=\"over\"] { border-color:#E0483C; background:color-mix(in srgb,#E0483C 16%,transparent); box-shadow:0 0 0 2px #fff; }\n\n/* A sticker-outlined apple (stem, leaf, shine) drawn once as an SVG; the number sits on its belly. */\n.gfx-game-board[data-kind=\"fruits\"] > button, .gfx-game-board[data-kind=\"fruits\"] > button:active:not(:disabled) { background:transparent; border:0; box-shadow:none; translate:none; border-radius:28% !important; transition:background .12s ease; }\n.gfx-game-board[data-kind=\"fruits\"] > button::before { content:\"\"; position:absolute; inset:2%; background:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='26' ry='4' fill='%236B4528' opacity='.18'/%3E%3Cpath d='M50 31C40 22 16 22 13 47 10 72 29 92 42 91c3-.3 5-1.4 8-1.4s5 1.1 8 1.4c13 1 32-19 29-44C84 22 60 22 50 31Z' fill='%23EF4B3F' stroke='%236B2318' stroke-width='3.5' stroke-linejoin='round'/%3E%3Cpath d='M27 40c-4 6-5 13-3 19' fill='none' stroke='%23fff' stroke-width='5' stroke-linecap='round' opacity='.55'/%3E%3Ccircle cx='31' cy='34' r='3' fill='%23fff' opacity='.6'/%3E%3Cpath d='M50 31c0-7 1-13 4-18' fill='none' stroke='%236B4528' stroke-width='4.5' stroke-linecap='round'/%3E%3Cpath d='M54 18c6-9 19-10 26-5-5 9-17 11-26 5Z' fill='%237ED36A' stroke='%233E7A33' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M57 17c6-2 12-3 18-3' fill='none' stroke='%233E7A33' stroke-width='1.8' stroke-linecap='round' opacity='.7'/%3E%3C/svg%3E\") center / contain no-repeat; transition:scale .14s cubic-bezier(.3,1.6,.5,1), filter .12s ease; }\n.gfx-game-board[data-kind=\"fruits\"] > button span { position:relative; z-index:1; margin-top:22%; color:#fff; font-size:calc(100cqw / var(--cols) * .36); letter-spacing:0;\n  -webkit-text-stroke:.16em #6B2318; paint-order:stroke fill; }\n.gfx-game-board[data-kind=\"fruits\"] > button[data-empty=\"true\"]::before { display:none; }\n.gfx-game-board[data-kind=\"fruits\"] > button[data-selected=\"true\"]::before { scale:1.1; filter:brightness(1.08); }\n.gfx-game-board[data-kind=\"fruits\"] > button[data-hint=\"true\"] { background:color-mix(in srgb,#FFD84D 55%,transparent); }\n.gfx-game-board[data-kind=\"fruits\"] > button[data-hint=\"true\"]::before { animation:gfx-game-hint .5s ease-in-out infinite alternate; }\n@keyframes gfx-game-hint { to { scale:1.12; } }\n/* 2048 */\n.gfx-game-board[data-kind=\"merge\"] { gap:6px; padding:8px; }\n.gfx-game-board[data-kind=\"merge\"] > div { background:color-mix(in srgb,var(--gfx-card, #FFFDF5) 60%,transparent); color:#5A3A24; font-size:calc(100cqw / var(--cols) * .36); }\n.gfx-game-board[data-kind=\"merge\"] > div[data-d=\"3\"] { font-size:calc(100cqw / var(--cols) * .3); } .gfx-game-board[data-kind=\"merge\"] > div[data-d=\"4\"] { font-size:calc(100cqw / var(--cols) * .24); }\n.gfx-game-board[data-kind=\"merge\"] > div[data-d=\"5\"] { font-size:calc(100cqw / var(--cols) * .2); }\n.gfx-game-board[data-kind=\"merge\"] > div:not([data-v=\"0\"]) { border:2px solid var(--gfx-line, #6B4528); box-shadow:0 3px 0 var(--gfx-line, #6B4528); }\n.gfx-game-board > div[data-v=\"2\"] { background:#FFF6DF; } .gfx-game-board > div[data-v=\"4\"] { background:#FFE7AE; } .gfx-game-board > div[data-v=\"8\"] { background:#FFC27A; color:#fff; }\n.gfx-game-board > div[data-v=\"16\"] { background:#FF9F68; color:#fff; } .gfx-game-board > div[data-v=\"32\"] { background:#FF7F6E; color:#fff; } .gfx-game-board > div[data-v=\"64\"] { background:#F25C5C; color:#fff; }\n.gfx-game-board > div[data-v=\"128\"] { background:#FFD84D; color:#fff; } .gfx-game-board > div[data-v=\"256\"] { background:#FFC933; color:#fff; } .gfx-game-board > div[data-v=\"512\"] { background:#FFB81C; color:#fff; }\n.gfx-game-board > div[data-v=\"1024\"] { background:#8FD16B; color:#fff; } .gfx-game-board > div[data-v=\"2048\"] { background:#4FC1A0; color:#fff; }\n.gfx-game-board[data-kind=\"merge\"] > div:not([data-v=\"0\"]):is([data-v^=\"4096\"],[data-v^=\"8192\"],[data-v^=\"16384\"],[data-v^=\"32768\"],[data-v^=\"65536\"]) { background:#8C6CF0; color:#fff; }\n.gfx-game-board[data-kind=\"merge\"] > div:is([data-v=\"8\"],[data-v=\"16\"],[data-v=\"32\"],[data-v=\"64\"],[data-v=\"128\"],[data-v=\"256\"],[data-v=\"512\"],[data-v=\"1024\"],[data-v=\"2048\"]) { text-shadow:0 .05em 0 #0003; }\n.gfx-game-board > div[data-new] { animation:gfx-tile-in .18s ease both; }\n.gfx-game-board > div[data-merged] { animation:gfx-tile-pop .2s ease both; }\n@keyframes gfx-tile-in { from { scale:.3; opacity:0; } }\n@keyframes gfx-tile-pop { 50% { scale:1.14; } }\n.gfx-game-pad { position:absolute; right:0; bottom:0; display:grid; grid-template-columns:repeat(3,2.4em); grid-template-areas:\". up .\" \"left down right\"; gap:4px; }\n.gfx-game-pad button { padding:.25em 0 !important; border-radius:12px !important; }\n.gfx-game-pad [data-dir=\"up\"] { grid-area:up; } .gfx-game-pad [data-dir=\"left\"] { grid-area:left; } .gfx-game-pad [data-dir=\"down\"] { grid-area:down; } .gfx-game-pad [data-dir=\"right\"] { grid-area:right; }\n@media (pointer:coarse) { .gfx-game-pad { display:none; } }\n/* 짝 맞추기 */\n.gfx-game-board[data-kind=\"memory\"] { gap:6px; }\n.gfx-game-board[data-kind=\"memory\"] > button { aspect-ratio:3 / 4; border-radius:12px !important; overflow:hidden; background:var(--gfx-card, #FFFDF5); border-width:2.5px; box-shadow:0 3px 0 var(--gfx-line, #6B4528); }\n.gfx-game-board[data-kind=\"memory\"] > button > span { position:absolute; inset:0; display:grid; place-items:center; transition:opacity .18s ease, scale .22s cubic-bezier(.3,1.5,.5,1); }\n.gfx-game-board[data-kind=\"memory\"] > button > .back { background:var(--gfx-accent, #F0763A); box-shadow:inset 0 0 0 .3em color-mix(in srgb,#fff 35%,var(--gfx-accent, #F0763A)); }\n.gfx-game-board[data-kind=\"memory\"] > button > .face { opacity:0; scale:.6; padding:6%; box-sizing:border-box; }\n.gfx-game-board[data-kind=\"memory\"] > button > .face img { width:100%; height:100%; object-fit:contain; object-position:50% 100%; }\n.gfx-game-board[data-kind=\"memory\"] > button > .face i { font-style:normal; font-size:calc(100cqw / var(--cols) * .5); }\n.gfx-game-board[data-kind=\"memory\"] > button[data-open=\"true\"] > .face { opacity:1; scale:1; }\n.gfx-game-board[data-kind=\"memory\"] > button[data-open=\"true\"] > .back { opacity:0; scale:.6; }\n.gfx-game-board[data-kind=\"memory\"] > button[data-done=\"true\"] { background:color-mix(in srgb,#C9F0D6 70%,var(--gfx-card, #FFFDF5)); border-color:#2FA95E; box-shadow:0 3px 0 #2FA95E; }\n/* Theme pieces: the box game's fruit and the minesweeper board follow the chosen 말랑 colour preset. */\n.gfx-load-games[data-theme=\"berry\"] .gfx-game-board[data-kind=\"fruits\"] > button::before { background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='26' ry='4' fill='%233A2A20' opacity='.18'/%3E%3Cpath d='M50 93C31 86 12 64 14 43 16 28 31 25 50 30 69 25 84 28 86 43 88 64 69 86 50 93Z' fill='%23F0456A' stroke='%237A1E33' stroke-width='3.5' stroke-linejoin='round'/%3E%3Cellipse cx='28' cy='48' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='42' cy='44' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='58' cy='44' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='72' cy='48' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='24' cy='62' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='38' cy='60' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='52' cy='62' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='66' cy='60' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='78' cy='62' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='34' cy='74' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='48' cy='76' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='62' cy='74' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='44' cy='86' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='56' cy='86' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cpath d='M27 46c-3 5-3 11-1 16' fill='none' stroke='%23fff' stroke-width='4.5' stroke-linecap='round' opacity='.55'/%3E%3Cpath d='M50 34 40 38 30 33 38 27 32 19 44 22 50 13 56 22 68 19 62 27 70 33 60 38Z' fill='%236CC25E' stroke='%232F6E2A' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M50 22c0-5 1-9 3-12' fill='none' stroke='%232F6E2A' stroke-width='4' stroke-linecap='round'/%3E%3C/svg%3E\"); }\n.gfx-load-games[data-theme=\"berry\"] .gfx-game-board[data-kind=\"fruits\"] > button span { -webkit-text-stroke-color:#7A1E33; }\n.gfx-load-games[data-theme=\"mint\"] .gfx-game-board[data-kind=\"fruits\"] > button::before { background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='26' ry='4' fill='%233A2A20' opacity='.18'/%3E%3Cpath d='M50 31C40 22 16 22 13 47 10 72 29 92 42 91c3-.3 5-1.4 8-1.4s5 1.1 8 1.4c13 1 32-19 29-44C84 22 60 22 50 31Z' fill='%238ACF4E' stroke='%232F5E1C' stroke-width='3.5' stroke-linejoin='round'/%3E%3Cpath d='M27 40c-4 6-5 13-3 19' fill='none' stroke='%23fff' stroke-width='5' stroke-linecap='round' opacity='.6'/%3E%3Ccircle cx='31' cy='34' r='3' fill='%23fff' opacity='.65'/%3E%3Cpath d='M50 31c0-7 1-13 4-18' fill='none' stroke='%236B4528' stroke-width='4.5' stroke-linecap='round'/%3E%3Cpath d='M54 18c6-9 19-10 26-5-5 9-17 11-26 5Z' fill='%233FA56B' stroke='%231F5E3A' stroke-width='3' stroke-linejoin='round'/%3E%3Ccircle cx='70' cy='70' r='3.2' fill='%235A3A24' opacity='.85'/%3E%3Ccircle cx='30' cy='72' r='2.6' fill='%235A3A24' opacity='.85'/%3E%3Ccircle cx='62' cy='50' r='2.4' fill='%235A3A24' opacity='.85'/%3E%3C/svg%3E\"); }\n.gfx-load-games[data-theme=\"mint\"] .gfx-game-board[data-kind=\"fruits\"] > button span { -webkit-text-stroke-color:#2F5E1C; }\n.gfx-load-games[data-theme=\"lavender\"] .gfx-game-board[data-kind=\"fruits\"] > button::before { background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='26' ry='4' fill='%233A2A20' opacity='.18'/%3E%3Cpath d='M52 24c0-6 2-11 6-15' fill='none' stroke='%236B4528' stroke-width='4.5' stroke-linecap='round'/%3E%3Cpath d='M56 16c8-8 20-6 25 0-7 8-18 8-25 0Z' fill='%237ED36A' stroke='%233E7A33' stroke-width='3' stroke-linejoin='round'/%3E%3Ccircle cx='30' cy='34' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='26' cy='30' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='50' cy='32' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='46' cy='28' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='70' cy='34' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='66' cy='30' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='22' cy='52' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='18' cy='48' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='40' cy='50' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='36' cy='46' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='60' cy='50' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='56' cy='46' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='78' cy='52' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='74' cy='48' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='31' cy='68' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='27' cy='64' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='50' cy='67' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='46' cy='63' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='69' cy='68' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='65' cy='64' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='40' cy='84' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='36' cy='80' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='60' cy='84' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='56' cy='80' r='2.6' fill='%23fff' opacity='.7'/%3E%3C/svg%3E\"); }\n.gfx-load-games[data-theme=\"lavender\"] .gfx-game-board[data-kind=\"fruits\"] > button span { -webkit-text-stroke-color:#3D2470; }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"fruits\"] > button::before { background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='24' ry='4' fill='%23000' opacity='.25'/%3E%3Cpath d='M45.8 17.4Q50 10 54.2 17.4L61.6 30.2Q64.1 34.6 69.1 35.6L83.5 38.7Q91.8 40.4 86.1 46.7L76.2 57.6Q72.8 61.4 73.4 66.5L75 81.1Q75.9 89.6 68.1 86.1L54.7 80.1Q50 78 45.3 80.1L31.9 86.1Q24.1 89.6 25 81.1L26.6 66.5Q27.2 61.4 23.8 57.6L13.9 46.7Q8.2 40.4 16.5 38.7L30.9 35.6Q35.9 34.6 38.4 30.2Z' fill='%23FFCF3D' stroke='%238A5A00' stroke-width='3.5' stroke-linejoin='round'/%3E%3Cpath d='M38 40c-3 3-4 7-4 11' fill='none' stroke='%23fff' stroke-width='4' stroke-linecap='round' opacity='.75'/%3E%3Ccircle cx='85' cy='15' r='4' fill='%23FFF6C2'/%3E%3Ccircle cx='13' cy='76' r='3' fill='%23FFF6C2'/%3E%3C/svg%3E\"); }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"fruits\"] > button span { -webkit-text-stroke-color:#7A4E00; }\n.gfx-load-games[data-theme=\"lavender\"] .gfx-game-board[data-kind=\"fruits\"] > button span { margin-top:30%; }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"fruits\"] > button span { margin-top:14%; }\n.gfx-load-games[data-theme=\"berry\"] .gfx-game-board[data-kind=\"fruits\"] > button span { margin-top:26%; }\n/* Minesweeper palettes: covered tile (two stops), opened tile, its rim, the board, the flag and the eight numbers. */\n.gfx-load-games { --mc1:#FFF3C4; --mc2:#FFD86B; --mo:#FFFDF5; --mol:#E8D9BE; --mb:#E8D9BE; --mflag:#E13F35;\n  --n1:#2F6FD6; --n2:#2E8B43; --n3:#D23B3B; --n4:#6A3FB5; --n5:#A0522D; --n6:#13817F; --n7:#333; --n8:#777; }\n.gfx-load-games[data-theme=\"berry\"] { --mc1:#FFE1EA; --mc2:#FFAEC6; --mo:#FFF8FA; --mol:#F6CFDC; --mb:#F3C6D4; --mflag:#D91E4F; }\n.gfx-load-games[data-theme=\"mint\"] { --mc1:#DDF8EA; --mc2:#8FDDBA; --mo:#F6FFFA; --mol:#C4E9D7; --mb:#BFE4D2; --mflag:#6B4528; }\n.gfx-load-games[data-theme=\"lavender\"] { --mc1:#EFE8FF; --mc2:#C3AEFF; --mo:#FCFBFF; --mol:#DCD0F7; --mb:#D5C8F5; --mflag:#E0483C; }\n.gfx-load-games[data-theme=\"night\"] { --mc1:#5C6299; --mc2:#3E4374; --mo:#22253D; --mol:#3B4068; --mb:#171A2E; --mflag:#FFD166;\n  --n1:#8EC5FF; --n2:#8EE6A8; --n3:#FF9B9B; --n4:#D3B5FF; --n5:#FFC48A; --n6:#7FE0DA; --n7:#F0F0F0; --n8:#BBBBBB; }\n.gfx-game-board[data-kind=\"mines\"] { background:var(--mb); }\n/* Solid tiles; the lighter shade is a top edge, not a gradient. */\n.gfx-game-board[data-kind=\"mines\"] > button { background:var(--mc2); box-shadow:inset 0 3px 0 var(--mc1), 0 2px 0 var(--gfx-line, #6B4528); }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"mines\"] > button:not([data-open=\"true\"]) {\n  background:var(--mc2); box-shadow:inset 0 3px 0 var(--mc1), 0 2px 0 #14162A; border-color:#14162A; box-shadow:0 2px 0 #14162A; }\n.gfx-game-board[data-kind=\"mines\"] > button[data-open=\"true\"] { background:var(--mo); border-color:var(--mol); }\n.gfx-game-board > button[data-n=\"1\"] { color:var(--n1); } .gfx-game-board > button[data-n=\"2\"] { color:var(--n2); } .gfx-game-board > button[data-n=\"3\"] { color:var(--n3); }\n.gfx-game-board > button[data-n=\"4\"] { color:var(--n4); } .gfx-game-board > button[data-n=\"5\"] { color:var(--n5); } .gfx-game-board > button[data-n=\"6\"] { color:var(--n6); }\n.gfx-game-board > button[data-n=\"7\"] { color:var(--n7); } .gfx-game-board > button[data-n=\"8\"] { color:var(--n8); }\n.gfx-game-board[data-kind=\"mines\"] button[data-flag=\"true\"]::after { background:var(--mflag); }\n/* 밤하늘: a gold star instead of the flag, a glowing orb instead of the bomb. */\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"mines\"] button[data-flag=\"true\"] { background:var(--mc2); }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"mines\"] button[data-flag=\"true\"]::before { display:none; }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"mines\"] button[data-flag=\"true\"]::after { left:18%; top:16%; width:64%; height:64%;\n  clip-path:none; -webkit-mask:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cpath d='M45.6 12.3Q50 4 54.4 12.3L62 26.8Q64.7 31.8 70.3 32.7L86.4 35.5Q95.7 37.2 89.1 43.9L77.7 55.7Q73.8 59.7 74.6 65.3L76.9 81.5Q78.2 90.8 69.7 86.7L55.1 79.5Q50 77 44.9 79.5L30.3 86.7Q21.8 90.8 23.1 81.5L25.4 65.3Q26.2 59.7 22.3 55.7L10.9 43.9Q4.3 37.2 13.6 35.5L29.7 32.7Q35.3 31.8 38 26.8Z'/%3E%3C/svg%3E\") center / contain no-repeat; mask:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cpath d='M45.6 12.3Q50 4 54.4 12.3L62 26.8Q64.7 31.8 70.3 32.7L86.4 35.5Q95.7 37.2 89.1 43.9L77.7 55.7Q73.8 59.7 74.6 65.3L76.9 81.5Q78.2 90.8 69.7 86.7L55.1 79.5Q50 77 44.9 79.5L30.3 86.7Q21.8 90.8 23.1 81.5L25.4 65.3Q26.2 59.7 22.3 55.7L10.9 43.9Q4.3 37.2 13.6 35.5L29.7 32.7Q35.3 31.8 38 26.8Z'/%3E%3C/svg%3E\") center / contain no-repeat; filter:drop-shadow(0 0 3px #FFD166); }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board > button[data-mine=\"true\"]::before { background:#8C6CF0;\n  box-shadow:0 0 .35em #9C82FF, 0 0 0 .1em #2A1F66; }\n/* 민트 초코: the mine is a chocolate chip. */\n.gfx-load-games[data-theme=\"mint\"] .gfx-game-board > button[data-mine=\"true\"]::before { width:56%; border-radius:52% 48% 46% 54% / 60% 58% 42% 40%;\n  background:#5A3A24; box-shadow:0 .08em 0 #2A180C; }\n/* The result card over the board; a tap beside it shows the board again. */\n.gfx-game-result { position:absolute; inset:0; display:grid; place-items:center; z-index:2; border-radius:16px; background:color-mix(in srgb,var(--gfx-ink, #FFF4D9) 45%,transparent); cursor:pointer; }\n.gfx-game-result[hidden] { display:none; }\n.gfx-game-result > div { display:grid; justify-items:center; gap:.35em; padding:1em 1.6em; background:var(--gfx-card, #FFFDF5); border:3px solid var(--gfx-line, #6B4528); border-radius:22px; box-shadow:0 5px 0 var(--gfx-line, #6B4528); cursor:default; animation:gfx-game-pop .35s cubic-bezier(.3,1.6,.5,1) both; }\n.gfx-game-result b { font-size:1.6em; font-weight:normal; color:var(--gfx-accent, #F0763A); }\n.gfx-game-result em { font-style:normal; padding:.1em .8em; border-radius:999px; background:#FFD84D; color:#5A3A10; }\n.gfx-game-again { background:var(--gfx-accent, #F0763A) !important; color:#fff !important; margin-top:.2em; }\n@keyframes gfx-game-pop { from { scale:.6; opacity:0; } }\n@media (prefers-reduced-motion: reduce) { .gfx-load-games *, .gfx-load-games *::before { animation:none !important; transition:none !important; } }\n/* Placement: a column of game cards on the right of the generation screen, the game beside it. */\n:host { position:absolute; inset:12px 12px 12px auto; width:min(880px,96%); z-index:5; display:block; pointer-events:none; container-type:size; }\n:host([data-game-large]) { width:calc(100% - 24px); }\n.gfx-load-games { height:100%; display:flex; flex-direction:row-reverse; align-items:flex-start; gap:10px; --room:calc(100cqh - 150px);\n  color:var(--gfx-text, #5A3A24); font:clamp(12px,1.5vw,16px)/1.35 var(--body, \"Jua\"), \"Malgun Gothic\", sans-serif; }\n.gfx-load-games > * { pointer-events:auto; }\n.gfx-game-nav { flex:0 0 112px; flex-direction:column; flex-wrap:nowrap; align-items:stretch; max-height:100%; overflow:auto; margin:0; box-sizing:border-box; }\n.gfx-game-utils { flex-direction:column; }\n.gfx-game-content { flex:1; min-width:0; max-height:100%; overflow:auto; box-sizing:border-box; }\n.gfx-game-board[data-kind=\"memory\"] > button > .face img { filter:drop-shadow(0 0 1.5px #fff) drop-shadow(0 0 1px #fff); }\n@media (max-width:600px) { :host { inset:8px 8px 8px auto; } .gfx-load-games { gap:5px; } .gfx-game-nav { flex-basis:78px; padding:5px; } .gfx-game-tab i { font-size:1.3em !important; } }\n/* Theme games */\n/* 딸기 우유 레시피: one rounded pad per ingredient; it lights up in the order to repeat. */\n.gfx-game-board[data-kind=\"recipe\"] { gap:10px; padding:10px; }\n.gfx-game-board[data-kind=\"recipe\"] > button { aspect-ratio:1; border-radius:26px !important; border:3px solid var(--gfx-line, #6B4528); box-shadow:0 5px 0 var(--gfx-line, #6B4528);\n  font-size:calc(100cqw / var(--cols) * .17); color:#6A2E45; transition:scale .12s ease, filter .12s ease, box-shadow .12s ease; }\n.gfx-game-board[data-kind=\"recipe\"] > button:disabled { opacity:1; }\n.gfx-game-board[data-kind=\"recipe\"] > button[data-pad=\"0\"] { background:#F2557F; color:#fff; } .gfx-game-board[data-kind=\"recipe\"] > button[data-pad=\"1\"] { background:#FFFFFF; }\n.gfx-game-board[data-kind=\"recipe\"] > button[data-pad=\"2\"] { background:#FFE7A3; } .gfx-game-board[data-kind=\"recipe\"] > button[data-pad=\"3\"] { background:#BFE6FF; }\n.gfx-game-board[data-kind=\"recipe\"] > button[data-pad=\"4\"] { background:#FFF3D6; } .gfx-game-board[data-kind=\"recipe\"] > button[data-pad=\"5\"] { background:#FFD3E0; }\n.gfx-game-board[data-kind=\"recipe\"] > button[data-lit] { scale:1.08; filter:brightness(1.12); box-shadow:0 0 0 6px #fff, 0 0 0 9px #F2557F, 0 5px 0 var(--gfx-line, #6B4528); }\n/* 초코칩 터뜨리기: mint, chocolate and friends; the group under the pointer lifts. */\n.gfx-game-board[data-kind=\"pop\"] { gap:3px; }\n.gfx-game-board[data-kind=\"pop\"] > button { border:2px solid #0003; box-shadow:none; border-radius:30% !important; transition:scale .12s ease; }\n.gfx-game-board[data-kind=\"pop\"] > button[data-v=\"0\"] { visibility:hidden; }\n.gfx-game-board[data-kind=\"pop\"] > button[data-v=\"1\"] { background:#8FDDBA; } .gfx-game-board[data-kind=\"pop\"] > button[data-v=\"2\"] { background:#6B4528; }\n.gfx-game-board[data-kind=\"pop\"] > button[data-v=\"3\"] { background:#FFF3D6; } .gfx-game-board[data-kind=\"pop\"] > button[data-v=\"4\"] { background:#F7A8C4; }\n.gfx-game-board[data-kind=\"pop\"] > button[data-v=\"5\"] { background:#9CC9F5; }\n.gfx-game-board[data-kind=\"pop\"] > button[data-v=\"1\"]::after { content:\"\"; width:18%; aspect-ratio:1; border-radius:50%; background:#3E2616; box-shadow:.5em .35em 0 -.05em #3E2616; translate:-.2em -.15em; }\n.gfx-game-board[data-kind=\"pop\"] > button[data-group=\"true\"] { scale:1.1; z-index:1; outline:3px solid #fff; outline-offset:-1px; }\n/* 꽃밭 퍼즐: lavender tiles; a tile in its place turns deeper. */\n.gfx-game-board[data-kind=\"slide\"] { gap:6px; padding:8px; }\n.gfx-game-board[data-kind=\"slide\"] > button { background:#C9B6FF; color:#fff; border:2.5px solid #4F3F85; box-shadow:0 3px 0 #4F3F85; border-radius:16px !important;\n  font-size:calc(100cqw / var(--cols) * .36); -webkit-text-stroke:.12em #4F3F85; paint-order:stroke fill; }\n.gfx-game-board[data-kind=\"slide\"] > button::after { content:\"\"; position:absolute; right:12%; top:12%; width:14%; aspect-ratio:1; border-radius:50%; background:#fff; opacity:.7;\n  box-shadow:-.32em 0 0 -.02em #FFE7A3, 0 .32em 0 -.02em #fff; }\n.gfx-game-board[data-kind=\"slide\"] > button[data-home=\"true\"] { background:#9A7BEA; }\n.gfx-game-board[data-kind=\"slide\"] > button[data-blank=\"true\"] { visibility:hidden; }\n/* 별 밝히기: dim stars that light up gold. */\n.gfx-game-board[data-kind=\"lights\"] { background:#171A2E; gap:6px; padding:8px; }\n.gfx-game-board[data-kind=\"lights\"] > button { background:#262A45; border:2px solid #3B4068; box-shadow:none; border-radius:14px !important; }\n.gfx-game-board[data-kind=\"lights\"] > button::before { content:\"\"; width:72%; aspect-ratio:1; background:#4A4F80; -webkit-mask:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cpath d='M45.6 12.3Q50 4 54.4 12.3L62 26.8Q64.7 31.8 70.3 32.7L86.4 35.5Q95.7 37.2 89.1 43.9L77.7 55.7Q73.8 59.7 74.6 65.3L76.9 81.5Q78.2 90.8 69.7 86.7L55.1 79.5Q50 77 44.9 79.5L30.3 86.7Q21.8 90.8 23.1 81.5L25.4 65.3Q26.2 59.7 22.3 55.7L10.9 43.9Q4.3 37.2 13.6 35.5L29.7 32.7Q35.3 31.8 38 26.8Z'/%3E%3C/svg%3E\") center / contain no-repeat; mask:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cpath d='M45.6 12.3Q50 4 54.4 12.3L62 26.8Q64.7 31.8 70.3 32.7L86.4 35.5Q95.7 37.2 89.1 43.9L77.7 55.7Q73.8 59.7 74.6 65.3L76.9 81.5Q78.2 90.8 69.7 86.7L55.1 79.5Q50 77 44.9 79.5L30.3 86.7Q21.8 90.8 23.1 81.5L25.4 65.3Q26.2 59.7 22.3 55.7L10.9 43.9Q4.3 37.2 13.6 35.5L29.7 32.7Q35.3 31.8 38 26.8Z'/%3E%3C/svg%3E\") center / contain no-repeat;\n  transition:background .2s ease, scale .2s cubic-bezier(.3,1.6,.5,1), filter .2s ease; scale:.85; }\n.gfx-game-board[data-kind=\"lights\"] > button[data-on=\"true\"]::before { background:#FFD166; scale:1; filter:drop-shadow(0 0 4px #FFD166); }\n.gfx-game-board > button:hover:not(:disabled) { filter:brightness(1.05); }\n/* Nine games: a two-column shelf of compact cards. */\n.gfx-game-nav { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); align-content:start; flex:0 0 164px; gap:6px; padding:7px; }\n.gfx-game-tab { min-width:0 !important; padding:.3em .2em !important; gap:0; border-radius:14px !important; }\n.gfx-game-tab i { font-size:1.35em; }\n.gfx-game-tab span { font-size:.76em; white-space:normal; line-height:1.15; text-align:center; word-break:keep-all; }\n.gfx-game-utils { grid-column:1 / -1; flex-direction:row; flex-wrap:wrap; }\n.gfx-game-utils > button { flex:1; }\n@media (max-width:600px) { .gfx-game-nav { flex-basis:120px; padding:4px; gap:4px; } .gfx-game-tab span { font-size:.68em; } .gfx-game-tab i { font-size:1.1em !important; } }\n.gfx-game-utils > .gfx-game-util { white-space:nowrap; font-size:.74em !important; padding:.3em .4em !important; }\n/* 스네이크's food: the theme's piece. */\n.gfx-load-games { --gfx-piece:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='26' ry='4' fill='%236B4528' opacity='.18'/%3E%3Cpath d='M50 31C40 22 16 22 13 47 10 72 29 92 42 91c3-.3 5-1.4 8-1.4s5 1.1 8 1.4c13 1 32-19 29-44C84 22 60 22 50 31Z' fill='%23EF4B3F' stroke='%236B2318' stroke-width='3.5' stroke-linejoin='round'/%3E%3Cpath d='M27 40c-4 6-5 13-3 19' fill='none' stroke='%23fff' stroke-width='5' stroke-linecap='round' opacity='.55'/%3E%3Ccircle cx='31' cy='34' r='3' fill='%23fff' opacity='.6'/%3E%3Cpath d='M50 31c0-7 1-13 4-18' fill='none' stroke='%236B4528' stroke-width='4.5' stroke-linecap='round'/%3E%3Cpath d='M54 18c6-9 19-10 26-5-5 9-17 11-26 5Z' fill='%237ED36A' stroke='%233E7A33' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M57 17c6-2 12-3 18-3' fill='none' stroke='%233E7A33' stroke-width='1.8' stroke-linecap='round' opacity='.7'/%3E%3C/svg%3E\"); }\n.gfx-load-games[data-theme=\"berry\"] { --gfx-piece:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='26' ry='4' fill='%233A2A20' opacity='.18'/%3E%3Cpath d='M50 93C31 86 12 64 14 43 16 28 31 25 50 30 69 25 84 28 86 43 88 64 69 86 50 93Z' fill='%23F0456A' stroke='%237A1E33' stroke-width='3.5' stroke-linejoin='round'/%3E%3Cellipse cx='28' cy='48' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='42' cy='44' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='58' cy='44' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='72' cy='48' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='24' cy='62' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='38' cy='60' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='52' cy='62' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='66' cy='60' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='78' cy='62' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='34' cy='74' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='48' cy='76' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='62' cy='74' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='44' cy='86' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cellipse cx='56' cy='86' rx='1.6' ry='2.4' fill='%23FFE58A'/%3E%3Cpath d='M27 46c-3 5-3 11-1 16' fill='none' stroke='%23fff' stroke-width='4.5' stroke-linecap='round' opacity='.55'/%3E%3Cpath d='M50 34 40 38 30 33 38 27 32 19 44 22 50 13 56 22 68 19 62 27 70 33 60 38Z' fill='%236CC25E' stroke='%232F6E2A' stroke-width='3' stroke-linejoin='round'/%3E%3Cpath d='M50 22c0-5 1-9 3-12' fill='none' stroke='%232F6E2A' stroke-width='4' stroke-linecap='round'/%3E%3C/svg%3E\"); }\n.gfx-load-games[data-theme=\"mint\"] { --gfx-piece:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='26' ry='4' fill='%233A2A20' opacity='.18'/%3E%3Cpath d='M50 31C40 22 16 22 13 47 10 72 29 92 42 91c3-.3 5-1.4 8-1.4s5 1.1 8 1.4c13 1 32-19 29-44C84 22 60 22 50 31Z' fill='%238ACF4E' stroke='%232F5E1C' stroke-width='3.5' stroke-linejoin='round'/%3E%3Cpath d='M27 40c-4 6-5 13-3 19' fill='none' stroke='%23fff' stroke-width='5' stroke-linecap='round' opacity='.6'/%3E%3Ccircle cx='31' cy='34' r='3' fill='%23fff' opacity='.65'/%3E%3Cpath d='M50 31c0-7 1-13 4-18' fill='none' stroke='%236B4528' stroke-width='4.5' stroke-linecap='round'/%3E%3Cpath d='M54 18c6-9 19-10 26-5-5 9-17 11-26 5Z' fill='%233FA56B' stroke='%231F5E3A' stroke-width='3' stroke-linejoin='round'/%3E%3Ccircle cx='70' cy='70' r='3.2' fill='%235A3A24' opacity='.85'/%3E%3Ccircle cx='30' cy='72' r='2.6' fill='%235A3A24' opacity='.85'/%3E%3Ccircle cx='62' cy='50' r='2.4' fill='%235A3A24' opacity='.85'/%3E%3C/svg%3E\"); }\n.gfx-load-games[data-theme=\"lavender\"] { --gfx-piece:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='26' ry='4' fill='%233A2A20' opacity='.18'/%3E%3Cpath d='M52 24c0-6 2-11 6-15' fill='none' stroke='%236B4528' stroke-width='4.5' stroke-linecap='round'/%3E%3Cpath d='M56 16c8-8 20-6 25 0-7 8-18 8-25 0Z' fill='%237ED36A' stroke='%233E7A33' stroke-width='3' stroke-linejoin='round'/%3E%3Ccircle cx='30' cy='34' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='26' cy='30' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='50' cy='32' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='46' cy='28' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='70' cy='34' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='66' cy='30' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='22' cy='52' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='18' cy='48' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='40' cy='50' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='36' cy='46' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='60' cy='50' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='56' cy='46' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='78' cy='52' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='74' cy='48' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='31' cy='68' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='27' cy='64' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='50' cy='67' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='46' cy='63' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='69' cy='68' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='65' cy='64' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='40' cy='84' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='36' cy='80' r='2.6' fill='%23fff' opacity='.7'/%3E%3Ccircle cx='60' cy='84' r='11' fill='%239A6CE8' stroke='%233D2470' stroke-width='3'/%3E%3Ccircle cx='56' cy='80' r='2.6' fill='%23fff' opacity='.7'/%3E%3C/svg%3E\"); }\n.gfx-load-games[data-theme=\"night\"] { --gfx-piece:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cellipse cx='50' cy='93' rx='24' ry='4' fill='%23000' opacity='.25'/%3E%3Cpath d='M45.8 17.4Q50 10 54.2 17.4L61.6 30.2Q64.1 34.6 69.1 35.6L83.5 38.7Q91.8 40.4 86.1 46.7L76.2 57.6Q72.8 61.4 73.4 66.5L75 81.1Q75.9 89.6 68.1 86.1L54.7 80.1Q50 78 45.3 80.1L31.9 86.1Q24.1 89.6 25 81.1L26.6 66.5Q27.2 61.4 23.8 57.6L13.9 46.7Q8.2 40.4 16.5 38.7L30.9 35.6Q35.9 34.6 38.4 30.2Z' fill='%23FFCF3D' stroke='%238A5A00' stroke-width='3.5' stroke-linejoin='round'/%3E%3Cpath d='M38 40c-3 3-4 7-4 11' fill='none' stroke='%23fff' stroke-width='4' stroke-linecap='round' opacity='.75'/%3E%3Ccircle cx='85' cy='15' r='4' fill='%23FFF6C2'/%3E%3Ccircle cx='13' cy='76' r='3' fill='%23FFF6C2'/%3E%3C/svg%3E\"); }\n/* 스네이크: the theme's piece is the food. */\n.gfx-game-board[data-kind=\"snake\"] { gap:1px; padding:6px; background:var(--mb, #E8D9BE); }\n.gfx-game-board[data-kind=\"snake\"] > div { border-radius:30% !important; background:color-mix(in srgb,var(--gfx-card, #FFFDF5) 45%,transparent); }\n.gfx-game-board[data-kind=\"snake\"] > div[data-s=\"body\"] { background:var(--gfx-accent, #F0763A); border-radius:34% !important; }\n.gfx-game-board[data-kind=\"snake\"] > div[data-s=\"head\"] { background:color-mix(in srgb,var(--gfx-accent, #F0763A) 70%,var(--gfx-line, #6B4528)); border-radius:40% !important; }\n.gfx-game-board[data-kind=\"snake\"] > div[data-s=\"head\"]::after { content:\"\"; width:18%; aspect-ratio:1; border-radius:50%; background:#fff; box-shadow:.45em 0 0 #fff; translate:-.22em 0; font-size:inherit; }\n.gfx-game-board[data-kind=\"snake\"] > div[data-s=\"food\"]::before { content:\"\"; position:absolute; inset:-8%; background:var(--gfx-piece) center / contain no-repeat; }\n/* 쿠키 가게: the shop front (awning, sign, window, menu board, guests, counter), the tool shelf, the ovens. */\n.gfx-game-board[data-kind=\"shop\"] { position:relative; display:flex; flex-direction:column; gap:0; padding:0; overflow:hidden; background:#F3E3C8; border:3px solid var(--gfx-line, #6B4528); container-type:inline-size; }\n.gfx-game-board[data-kind=\"shop\"] > * { aspect-ratio:auto; place-items:normal; font-size:inherit; line-height:1.3; border-radius:0 !important; }\n.gfx-shop-front { position:relative; display:block !important; height:clamp(150px,50cqw,250px); overflow:hidden; background:repeating-linear-gradient(90deg,#FCE6CF 0 14px,#F8DDC2 14px 28px); }\n.gfx-load-games[data-theme=\"night\"] .gfx-shop-front { background:repeating-linear-gradient(90deg,#3B3F66 0 14px,#363A5E 14px 28px); }\n.gfx-shop-awning { position:absolute; inset:0 0 auto; height:24px; filter:drop-shadow(0 2.5px 0 var(--gfx-line, #6B4528)); z-index:1; }\n.gfx-shop-awning::before { content:\"\"; position:absolute; inset:0; background:repeating-linear-gradient(90deg,var(--gfx-accent, #F0763A) 0 24px,#fff 24px 48px);\n  -webkit-mask:radial-gradient(12px at 12px 12px,#000 98%,#0000) 0 100% / 24px 100% repeat-x, linear-gradient(#000 0 0) top / 100% 12px no-repeat;\n  mask:radial-gradient(12px at 12px 12px,#000 98%,#0000) 0 100% / 24px 100% repeat-x, linear-gradient(#000 0 0) top / 100% 12px no-repeat; }\n.gfx-shop-sign { position:absolute; left:50%; top:3px; translate:-50% 0; z-index:2; padding:.12em .9em; border-radius:10px; font-weight:normal; white-space:nowrap; font-size:max(11px,3.4cqw);\n  background:#8A5A33; color:#FFF4D9; border:3px solid var(--gfx-line, #6B4528); box-shadow:0 3px 0 var(--gfx-line, #6B4528), inset 0 -4px 0 #74482A; letter-spacing:.05em; }\n.gfx-shop-sign::before { content:\"🍪\"; margin-right:.25em; }\n.gfx-shop-window { position:absolute; left:3%; top:36px; width:22%; height:44%; box-sizing:border-box; border:4px solid #fff; outline:2.5px solid var(--gfx-line, #6B4528); border-radius:10px 10px 4px 4px; overflow:hidden;\n  background:linear-gradient(90deg,transparent calc(50% - 2px),#fff calc(50% - 2px) calc(50% + 2px),transparent 0), linear-gradient(transparent calc(50% - 2px),#fff calc(50% - 2px) calc(50% + 2px),transparent 0), #BFE6FF; }\n.gfx-shop-window::before { content:\"\"; position:absolute; left:14%; top:22%; width:16%; aspect-ratio:1; border-radius:50%; background:#fff; box-shadow:.7em .15em 0 .1em #fff, 1.3em .2em 0 -.05em #fff; }\n.gfx-shop-window::after { content:\"\"; position:absolute; inset:0 auto auto 0; width:100%; height:22%; background:repeating-linear-gradient(90deg,var(--gfx-accent, #F0763A) 0 8px,#FFD3C0 8px 16px); border-bottom:2px solid var(--gfx-line, #6B4528); border-radius:0 0 40% 40% / 0 0 100% 100%; }\n.gfx-load-games[data-theme=\"night\"] .gfx-shop-window { background-color:#171A2E; }\n.gfx-load-games[data-theme=\"night\"] .gfx-shop-window::before { background:#FFD166; box-shadow:0 0 6px #FFD166, 1.4em 1.2em 0 -.25em #FFF6C2; }\n.gfx-shop-menu { position:absolute; right:3%; top:36px; width:24%; box-sizing:border-box; display:grid !important; gap:1px; padding:4px 6px; font-size:max(8px,2.3cqw); color:#F5F1E6;\n  background:#3E4A3D; border:4px solid #A8743F; outline:2.5px solid var(--gfx-line, #6B4528); border-radius:8px; }\n.gfx-shop-menu b { font-weight:normal; text-align:center; color:#FFD84D; letter-spacing:.15em; }\n.gfx-shop-menu span { display:flex; align-items:center; gap:.3em; white-space:nowrap; }\n.gfx-shop-menu svg { width:1.7em; flex:none; }\n.gfx-shop-menu i { font-style:normal; }\n/* Guests: up to three behind the counter, an order bubble with a patience bar above each; the bubbles sit over the sign. */\n.gfx-shop-guests { position:absolute; z-index:3; left:26%; right:28%; top:40px; bottom:19%; display:flex !important; justify-content:center; align-items:flex-end; gap:2%; }\n.gfx-shop-guest { position:relative; width:32%; display:flex; flex-direction:column; align-items:center; gap:3px; animation:gfx-guest-in .45s cubic-bezier(.3,1.5,.5,1) both; }\n@keyframes gfx-guest-in { from { translate:0 40%; opacity:0; } }\n.gfx-shop-guest .order { position:relative; display:flex; align-items:center; gap:.2em; padding:.15em .4em .35em; border-radius:10px; background:#fff; border:2px solid var(--gfx-line, #6B4528);\n  font-size:max(8px,2.1cqw); white-space:nowrap; box-shadow:0 2px 0 var(--gfx-line, #6B4528); }\n.gfx-shop-guest .order::after { content:\"\"; position:absolute; left:50%; bottom:-6px; width:8px; height:8px; background:#fff; border-right:2px solid var(--gfx-line, #6B4528); border-bottom:2px solid var(--gfx-line, #6B4528); translate:-50% 0; rotate:45deg; }\n.gfx-shop-guest .order svg { width:2em; }\n.gfx-shop-guest .order i { font-style:normal; }\n.gfx-shop-guest .wait { position:absolute; left:6px; right:6px; bottom:2px; height:3px; border-radius:999px; background:#0001; overflow:hidden; }\n.gfx-shop-guest .wait::after { content:\"\"; position:absolute; inset:0 auto 0 0; width:calc(var(--w, 1) * 100%); background:#4CC27A; border-radius:999px; }\n.gfx-shop-guest[data-mood=\"ok\"] .wait::after { background:#FFC933; }\n.gfx-shop-guest[data-mood=\"angry\"] .wait::after { background:#E0483C; }\n.gfx-shop-guest .fig { position:relative; width:100%; aspect-ratio:60 / 72; display:block; }\n.gfx-shop-guest .fig > * { position:absolute; inset:0; width:100%; height:100%; }\n.gfx-shop-guest .fig img { object-fit:contain; object-position:50% 0; filter:drop-shadow(0 0 1.5px #fff) drop-shadow(0 0 1px #fff); }\n/* An SD sprite is a whole figure: show its upper body, as large as the drawn guests; the counter hides the cut. */\n.gfx-shop-guest .fig[data-sd] { overflow:hidden; }\n.gfx-shop-guest .fig[data-sd] > img { inset:4% auto auto 50%; width:auto; height:165%; max-width:none; translate:-50% 0; object-fit:fill; }\n.gfx-shop-guest .fig[data-sd]::after { z-index:1; }\n.gfx-shop-guest[data-mood=\"happy\"] .fig { animation:gfx-guest-bob 1.6s ease-in-out infinite; }\n@keyframes gfx-guest-bob { 50% { translate:0 -3%; } }\n.gfx-shop-guest[data-mood=\"angry\"] .fig { animation:gfx-guest-fume .5s ease-in-out infinite; }\n@keyframes gfx-guest-fume { 25% { translate:-2% 0; } 75% { translate:2% 0; } }\n.gfx-shop-guest[data-mood=\"angry\"] .fig::after { content:\"💢\"; position:absolute; right:-4%; top:2%; font-size:max(10px,3cqw); }\n.gfx-shop-guest[data-leave] { animation:gfx-guest-out .7s ease-in both; }\n.gfx-shop-guest[data-leave=\"happy\"] { animation-name:gfx-guest-yay; }\n@keyframes gfx-guest-out { 30% { translate:0 -6%; } to { translate:0 60%; opacity:0; } }\n@keyframes gfx-guest-yay { 25% { translate:0 -14%; } 50% { translate:0 0; } to { translate:0 -10%; opacity:0; } }\n.gfx-shop-guest[data-leave=\"happy\"] .fig::after { content:\"♥\"; position:absolute; right:0; top:0; color:#F2557F; font-size:max(12px,3.4cqw); }\n.gfx-shop-fig-svg, .gfx-shop-guest .fig svg { overflow:visible; }\n.gfx-shop-guest .g-body { fill:var(--shirt, #F7A8C4); stroke:var(--gfx-line, #6B4528); stroke-width:2.5; }\n.gfx-shop-guest .g-collar { fill:none; stroke:var(--gfx-line, #6B4528); stroke-width:2.2; }\n.gfx-shop-guest .g-back, .gfx-shop-guest .g-hair { fill:var(--hair, #6B4528); stroke:var(--gfx-line, #6B4528); stroke-width:2.5; stroke-linejoin:round; }\n.gfx-shop-guest .g-head { fill:#FFE3C8; stroke:var(--gfx-line, #6B4528); stroke-width:2.5; }\n.gfx-shop-guest .g-eyes { fill:#3A2618; }\n.gfx-shop-guest .g-cheek { fill:#FF9FA8; opacity:.65; }\n.gfx-shop-guest .g-mouth { fill:none; stroke:#3A2618; stroke-width:2; stroke-linecap:round; display:none; }\n.gfx-shop-guest .g-brow { fill:none; stroke:#3A2618; stroke-width:2; stroke-linecap:round; display:none; }\n.gfx-shop-guest:not([data-mood]) .m-happy, .gfx-shop-guest[data-mood=\"happy\"] .m-happy, .gfx-shop-guest[data-mood=\"ok\"] .m-flat, .gfx-shop-guest[data-mood=\"angry\"] .m-angry, .gfx-shop-guest[data-mood=\"angry\"] .g-brow { display:inline; }\n/* The counter: wood planks, the guest's word and the till. */\n.gfx-shop-counter { position:absolute; inset:auto 0 0; height:24%; display:flex !important; align-items:center; gap:8px; padding:0 3%; box-sizing:border-box; z-index:4;\n  background:repeating-linear-gradient(90deg,#B07A47 0 46px,#9E6C3D 46px 48px); border-top:3px solid var(--gfx-line, #6B4528); box-shadow:inset 0 6px 0 #C99260; }\n.gfx-shop-say { position:relative; flex:1; min-width:0; padding:.25em .8em; border-radius:12px; background:#fff; border:2.5px solid var(--gfx-line, #6B4528); box-shadow:0 2px 0 var(--gfx-line, #6B4528);\n  font-size:max(10px,2.7cqw); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }\n.gfx-shop-say[data-mood=\"good\"] { background:#DDF6E6; } .gfx-shop-say[data-mood=\"bad\"] { background:#FFE1DC; }\n.gfx-shop-say[data-pop] { animation:gfx-game-pop .3s cubic-bezier(.3,1.6,.5,1); }\n.gfx-shop-till { flex:none; padding:.2em .6em; border-radius:8px; background:#3E2616; color:#9CF5B8; border:2.5px solid var(--gfx-line, #6B4528); box-shadow:inset 0 0 0 2px #5A3A24, 0 2px 0 var(--gfx-line, #6B4528);\n  font-size:max(10px,2.6cqw); font-variant-numeric:tabular-nums; letter-spacing:.04em; }\n.gfx-shop-till::before { content:\"🪙 \"; }\n/* The shelf: a wooden plank with the seven tools. */\n.gfx-shop-shelf { display:grid !important; grid-template-columns:repeat(7,minmax(0,1fr)); gap:4px; padding:6px 6px 9px; background:#8A5A33; border-top:3px solid var(--gfx-line, #6B4528); border-bottom:3px solid var(--gfx-line, #6B4528);\n  box-shadow:inset 0 -5px 0 #74482A; }\n.gfx-game-board[data-kind=\"shop\"] .gfx-shop-tool { position:relative; display:flex; flex-direction:column; align-items:center; gap:0; padding:3px 0 2px !important; border-radius:12px !important; border-width:2px;\n  background:#FFF7E8; box-shadow:0 3px 0 var(--gfx-line, #6B4528); font-size:max(9px,2.3cqw); min-width:0; transition:translate .1s ease, background .15s ease; }\n.gfx-shop-tool .icon { display:block; width:min(2.6em,80%); }\n.gfx-shop-tool .icon svg { display:block; width:100%; }\n.gfx-shop-tool .label { white-space:nowrap; }\n.gfx-shop-tool kbd { position:absolute; left:2px; top:1px; font:inherit; font-size:.75em; line-height:1; color:#B59C80; }\n.gfx-game-board[data-kind=\"shop\"] .gfx-shop-tool[aria-pressed=\"true\"] { background:var(--gfx-pick, #FFE17A); translate:0 -3px; box-shadow:0 5px 0 var(--gfx-line, #6B4528), 0 0 0 2px #fff inset; }\n.gfx-game-board[data-kind=\"shop\"] .gfx-shop-tool[aria-pressed=\"true\"] .label { color:var(--gfx-accent, #F0763A); }\n/* The kitchen: a tiled wall and four ovens. */\n.gfx-game-board[data-kind=\"shop\"] > .gfx-shop-ovens { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:3%; padding:10px 3% 10px;\n  background:conic-gradient(#FFFDF8 25%,#EFE3D2 0 50%,#FFFDF8 0 75%,#EFE3D2 0) 0 0 / 22px 22px; }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"shop\"] > .gfx-shop-ovens { background:conic-gradient(#2A2E4D 25%,#232742 0 50%,#2A2E4D 0 75%,#232742 0) 0 0 / 22px 22px; }\n.gfx-game-board[data-kind=\"shop\"] .gfx-shop-oven { position:relative; display:block; padding:0 !important; background:none; border:0; box-shadow:none; border-radius:0 !important; color:inherit; min-width:0; }\n.gfx-game-board[data-kind=\"shop\"] .gfx-shop-oven:active:not(:disabled) { translate:0 2px; box-shadow:none; }\n.gfx-game-board[data-kind=\"shop\"] .gfx-shop-oven:hover:not(:disabled) svg { filter:brightness(1.06); }\n.gfx-shop-oven svg { display:block; width:100%; overflow:visible; }\n.gfx-shop-oven .tag { display:block; margin:3px auto 0; width:fit-content; max-width:100%; box-sizing:border-box; padding:.05em .55em; border-radius:999px; background:#fff; border:2px solid var(--gfx-line, #6B4528);\n  font-size:max(9px,2.2cqw); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }\n.gfx-shop-oven[data-stage=\"hot\"] .tag { background:#C9F0D6; color:#1C7A43; }\n.gfx-shop-oven[data-stage=\"ready\"] .tag { background:#FFD84D; animation:gfx-game-blink .6s ease-in-out infinite; }\n.gfx-shop-oven[data-stage=\"over\"] .tag { background:#FFB38A; color:#7A2A0C; }\n.gfx-shop-oven[data-stage=\"burnt\"] .tag { background:#E0483C; color:#fff; }\n.gfx-shop-oven[data-stage=\"ready\"] svg { filter:drop-shadow(0 0 5px #FFD84D) drop-shadow(0 0 2px #FFD84D); }\n.gfx-shop-oven[data-stage=\"burnt\"] svg { animation:gfx-game-shake .5s ease infinite; }\n.gfx-shop-oven[data-stage=\"gone\"] { opacity:.3; filter:grayscale(1); }\n.gfx-shop-oven[data-nope] svg { animation:gfx-game-shake .25s ease; }\n/* Oven parts. */\n.gfx-shop-oven svg * { stroke-linecap:round; stroke-linejoin:round; }\n.gfx-shop-oven .ov-foot { fill:var(--gfx-line, #6B4528); }\n.gfx-shop-oven .ov-body { fill:#FBEBD3; stroke:var(--gfx-line, #6B4528); stroke-width:3; }\n.gfx-shop-oven .ov-top { fill:var(--gfx-accent, #F0763A); stroke:var(--gfx-line, #6B4528); stroke-width:3; }\n.gfx-shop-oven .ov-knob circle { fill:#fff; stroke:var(--gfx-line, #6B4528); stroke-width:2.5; }\n.gfx-shop-oven .ov-knob path { stroke:var(--gfx-line, #6B4528); stroke-width:2.5; }\n.gfx-shop-oven .ov-knob { transform-origin:18px 20px; transition:rotate .3s ease; }\n.gfx-shop-oven[data-lit=\"true\"]:not([data-stage=\"cold\"]) .ov-knob { rotate:135deg; }\n.gfx-shop-oven .dial-face { fill:#fff; stroke:var(--gfx-line, #6B4528); stroke-width:2.5; }\n.gfx-shop-oven .ov-dial path[class^=\"z-\"] { fill:none; stroke-width:3.2; stroke-linecap:butt; }\n.gfx-shop-oven .z-raw { stroke:#E5D6BF; } .gfx-shop-oven .z-ready { stroke:#FFC933; } .gfx-shop-oven .z-over { stroke:#F0763A; }\n.gfx-shop-oven .needle { stroke:#E0483C; stroke-width:2; transform-origin:50px 22px; rotate:calc(-90deg + var(--p, 0) * 180deg); transition:rotate .1s linear; }\n.gfx-shop-oven .hub { fill:var(--gfx-line, #6B4528); }\n.gfx-shop-oven .ov-lamp { fill:#D7CBBB; stroke:var(--gfx-line, #6B4528); stroke-width:2.2; }\n.gfx-shop-oven[data-stage=\"heat\"] .ov-lamp { fill:#FF8A3D; animation:gfx-game-blink .5s ease-in-out infinite; }\n.gfx-shop-oven:is([data-stage=\"hot\"],[data-stage=\"raw\"],[data-stage=\"ready\"]) .ov-lamp { fill:#4CD07D; }\n.gfx-shop-oven:is([data-stage=\"over\"],[data-stage=\"burnt\"]) .ov-lamp { fill:#E0483C; animation:gfx-game-blink .3s ease-in-out infinite; }\n.gfx-shop-oven .ov-door { fill:#6B4528; stroke:#3E2616; stroke-width:3; }\n.gfx-shop-oven .ov-glass { fill:#2B1D14; stroke:#3E2616; stroke-width:2; transition:fill .4s ease; }\n.gfx-shop-oven:not([data-stage=\"cold\"]) .ov-glass { fill:#6A2E14; animation:gfx-oven-warm 1.2s ease-in-out infinite alternate; }\n.gfx-shop-oven[data-stage=\"ready\"] .ov-glass { fill:#9A4A1C; }\n.gfx-shop-oven[data-stage=\"burnt\"] .ov-glass { fill:#1A1210; animation:none; }\n@keyframes gfx-oven-warm { to { fill:#7E3818; } }\n.gfx-shop-oven .ov-coil { fill:none; stroke:#7A6A5E; stroke-width:2; }\n.gfx-shop-oven:not([data-stage=\"cold\"]):not([data-stage=\"burnt\"]) .ov-coil { stroke:#FF7A2E; }\n.gfx-shop-oven .ov-fire { display:none; fill:#FFB347; }\n.gfx-shop-oven:not([data-stage=\"cold\"]):not([data-stage=\"burnt\"]) .ov-fire { display:inline; }\n.gfx-shop-oven .ov-fire path { transform-box:fill-box; transform-origin:50% 100%; animation:gfx-oven-flame .35s ease-in-out infinite alternate; }\n.gfx-shop-oven .ov-fire path:nth-child(2n) { animation-delay:-.17s; fill:#FFD84D; }\n@keyframes gfx-oven-flame { to { scale:1 .7; } }\n.gfx-shop-oven .ov-tray { fill:#C9D0D8; stroke:#5C646E; stroke-width:1.6; }\n.gfx-shop-oven .ov-butter rect { fill:#FFE07A; stroke:#7A5A10; stroke-width:1.6; }\n.gfx-shop-oven .ov-butter path { stroke:#fff; stroke-width:1.6; opacity:.7; }\n.gfx-shop-oven .ov-butter, .gfx-shop-oven .ov-melt, .gfx-shop-oven .ov-cookie { display:none; }\n.gfx-shop-oven[data-butter=\"true\"][data-dough=\"false\"][data-stage=\"cold\"] .ov-butter { display:inline; }\n.gfx-shop-oven[data-butter=\"true\"]:not([data-stage=\"cold\"]) .ov-melt { display:inline; fill:#FFD84D; opacity:.9; }\n.gfx-shop-oven[data-dough=\"true\"] .ov-cookie { display:inline; }\n.gfx-shop-oven .ck-ball { fill:#F6DFAE; stroke:#C9A26A; stroke-width:2; transform-box:fill-box; transform-origin:50% 100%; scale:calc(1 + var(--p, 0) * .6) calc(1 - var(--p, 0) * .5); }\n.gfx-shop-oven .ck-disc, .gfx-shop-oven .ck-crack { display:none; }\n.gfx-shop-oven:is([data-stage=\"ready\"],[data-stage=\"over\"],[data-stage=\"burnt\"]) .ck-ball { display:none; }\n.gfx-shop-oven:is([data-stage=\"ready\"],[data-stage=\"over\"],[data-stage=\"burnt\"]) :is(.ck-disc,.ck-crack) { display:inline; }\n.gfx-shop-oven .ck-disc { fill:#E2A04F; stroke:#8A4F1C; stroke-width:2; transform-box:fill-box; transform-origin:50% 100%; }\n.gfx-shop-oven .ck-crack { fill:none; stroke:#B5722F; stroke-width:1.4; }\n.gfx-shop-oven[data-stage=\"over\"] .ck-disc { fill:#A8682E; stroke:#5A3010; }\n.gfx-shop-oven[data-stage=\"burnt\"] .ck-disc { fill:#2E1C12; stroke:#140A06; } .gfx-shop-oven[data-stage=\"burnt\"] .ck-crack { stroke:#4A2E1C; }\n.gfx-shop-oven[data-flat=\"true\"] :is(.ck-disc,.ck-ball) { scale:1.08 .55; }\n.gfx-shop-oven .ck-sugar, .gfx-shop-oven .ck-chip, .gfx-shop-oven .ck-cream { display:none; }\n.gfx-shop-oven[data-sugar=\"true\"]:not([data-stage=\"burnt\"]) .ck-sugar { display:inline; fill:#fff; }\n.gfx-shop-oven[data-chip=\"true\"] .ck-chip { display:inline; fill:#3E2616; }\n.gfx-shop-oven[data-cream=\"true\"] .ck-cream { display:inline; }\n.gfx-shop-oven .ck-cream path:first-child { fill:#fff; stroke:#C99F7E; stroke-width:1.6; }\n.gfx-shop-oven .ck-cream path + path { fill:none; stroke:#E8D3BE; stroke-width:1.2; }\n.gfx-shop-oven .ov-steam { display:none; fill:none; stroke:#fff; stroke-width:2.2; opacity:.85; }\n.gfx-shop-oven[data-stage=\"ready\"] .ov-steam { display:inline; }\n.gfx-shop-oven .ov-steam path { animation:gfx-oven-steam 1s ease-in-out infinite; }\n.gfx-shop-oven .ov-steam path:nth-child(2) { animation-delay:-.33s; } .gfx-shop-oven .ov-steam path:nth-child(3) { animation-delay:-.66s; }\n@keyframes gfx-oven-steam { from { translate:0 4px; opacity:0; } 40% { opacity:1; } to { translate:0 -5px; opacity:0; } }\n.gfx-shop-oven .ov-smoke { display:none; fill:#9A938C; opacity:.8; }\n.gfx-shop-oven[data-warn=\"true\"] .ov-smoke, .gfx-shop-oven[data-stage=\"burnt\"] .ov-smoke { display:inline; }\n.gfx-shop-oven[data-stage=\"burnt\"] .ov-smoke { fill:#3A3330; }\n.gfx-shop-oven .ov-smoke circle { animation:gfx-oven-smoke 1.4s ease-in-out infinite; transform-box:fill-box; transform-origin:50% 50%; }\n.gfx-shop-oven .ov-smoke circle:nth-child(2) { animation-delay:-.5s; } .gfx-shop-oven .ov-smoke circle:nth-child(3) { animation-delay:-1s; }\n@keyframes gfx-oven-smoke { from { translate:0 6px; scale:.6; opacity:0; } 50% { opacity:1; } to { translate:0 -6px; scale:1.2; opacity:0; } }\n.gfx-shop-oven .ov-shine { fill:none; stroke:#fff; stroke-width:2.5; opacity:.25; }\n.gfx-shop-oven .ov-handle { fill:#C9D0D8; stroke:var(--gfx-line, #6B4528); stroke-width:2; }\n/* +price over the oven, a burst of stars for a perfect cookie. */\n.gfx-game-board[data-kind=\"shop\"] > .gfx-shop-coin { position:absolute; bottom:22%; translate:-50% 0; z-index:3; padding:.1em .6em; border-radius:999px !important; background:#FFD84D; color:#5A3A10; border:2.5px solid var(--gfx-line, #6B4528);\n  white-space:nowrap; font-size:max(11px,2.8cqw); pointer-events:none; animation:gfx-shop-coin 1.1s ease-out both; }\n.gfx-game-board[data-kind=\"shop\"] > .gfx-shop-coin[data-zero] { background:#FFE1DC; color:#A1281C; }\n@keyframes gfx-shop-coin { from { translate:-50% 20px; opacity:0; } 20% { translate:-50% 0; opacity:1; } 75% { opacity:1; } to { translate:-50% -40px; opacity:0; } }\n.gfx-game-board[data-kind=\"shop\"] > .gfx-shop-sparkle { position:absolute; bottom:30%; width:10%; aspect-ratio:1; translate:-50% 0; z-index:3; pointer-events:none; animation:gfx-shop-burst .9s ease-out both; }\n.gfx-game-board[data-kind=\"shop\"] > .gfx-shop-sparkle::before, .gfx-game-board[data-kind=\"shop\"] > .gfx-shop-sparkle::after { content:\"✦\"; position:absolute; inset:0; display:grid; place-items:center; color:#FFD84D; font-size:max(14px,4cqw);\n  text-shadow:-1.4em -.6em 0 #FFD84D, 1.3em -.8em 0 #fff, -1em .9em 0 #fff, 1.2em .7em 0 #FFD84D, 0 -1.5em 0 #F7A8C4; -webkit-text-stroke:1px var(--gfx-line, #6B4528); }\n@keyframes gfx-shop-burst { from { scale:.3; opacity:0; } 30% { opacity:1; } to { scale:1.4; opacity:0; } }\n/* 디저트 핀볼 and 비스킷 벽돌깨기: the table on a canvas, the flipper and launch buttons under it. */\n.gfx-game-board:is([data-kind=\"pinball\"],[data-kind=\"bricks\"]) { display:flex; flex-direction:column; gap:8px; padding:8px; background:var(--gfx-line, #6B4528); }\n.gfx-game-board:is([data-kind=\"pinball\"],[data-kind=\"bricks\"]) > * { aspect-ratio:auto; place-items:normal; font-size:inherit; line-height:1.3; }\n.gfx-game-board:is([data-kind=\"pinball\"],[data-kind=\"bricks\"]) > .gfx-pin-table { display:block; width:100%; aspect-ratio:320 / 520; border-radius:12px !important; touch-action:none; cursor:pointer; }\n.gfx-game-board:is([data-kind=\"pinball\"],[data-kind=\"bricks\"]) > .gfx-pin-pad { display:flex; gap:6px; border-radius:0 !important; }\n.gfx-pin-pad button { flex:1; padding:.45em 0 !important; border-radius:14px !important; font-size:.88em; white-space:nowrap; touch-action:none; }\n.gfx-pin-pad .gfx-pin-launch { background:var(--gfx-pick, #FFE17A); }\n.gfx-pin-pad button[data-held] { translate:0 2px; box-shadow:0 1px 0 var(--gfx-line, #6B4528); background:var(--gfx-accent, #F0763A); color:#fff; }\n/* The shop's paper, wood and tiles stay light in every theme, so its writing stays dark. */\n.gfx-game-board[data-kind=\"shop\"], .gfx-game-board[data-kind=\"shop\"] .gfx-shop-tool { color:#5A3A24; }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"shop\"] .gfx-shop-tool[aria-pressed=\"true\"] { background:#FFE17A; }\n.gfx-load-games[data-theme=\"night\"] .gfx-game-board[data-kind=\"shop\"] .gfx-shop-tool[aria-pressed=\"true\"] .label { color:#B5521C; }\n";
  let sheet = null;
  const styleSheet = () => { if (!sheet) { sheet = new CSSStyleSheet(); sheet.replaceSync(CSS); } return sheet; };


  const ADAPTER_CSS = "/* All styles are inside our ShadowRoots. No font, image or stylesheet downloads. */\n:host { font-family:system-ui,\"Malgun Gothic\",sans-serif; }\n:host(#gacha_minigames_me) { position:fixed; inset:0; z-index:2147483000; pointer-events:none; color:var(--gfx-text,#5A3A24); }\n* { box-sizing:border-box; }\n[hidden] { display:none !important; }\nbutton,input,summary { font:inherit; }\nbutton,summary { cursor:pointer; }\nbutton { color:inherit; background:var(--gfx-card,#FFFDF5); border:2px solid var(--gfx-line,#6B4528); border-radius:14px; padding:8px 12px; min-width:44px; min-height:44px; }\nbutton:focus-visible,summary:focus-visible,input:focus-visible { outline:3px solid var(--gfx-accent,#F0763A); outline-offset:2px; }\n#launcher { position:fixed; right:max(12px,env(safe-area-inset-right)); width:48px; height:48px; padding:0; font-size:24px; pointer-events:auto; touch-action:none; user-select:none; box-shadow:0 3px 0 var(--gfx-line,#6B4528); }\n#panel { position:fixed; right:12px; bottom:max(76px,env(safe-area-inset-bottom)); width:min(960px,calc(100vw - 24px)); height:min(740px,calc(100vh - 96px)); height:min(740px,calc(100dvh - 96px)); display:flex; flex-direction:column; gap:8px; padding:12px; pointer-events:auto; border:3px solid var(--gfx-line,#6B4528); border-radius:20px; background:var(--gfx-ink,#FFF4D9); box-shadow:0 8px 32px #0003; overflow:auto; }\nheader { display:flex; justify-content:space-between; align-items:center; gap:8px; flex:none; }\nheader strong { font-size:16px; }\n#settings { flex:none; }\nsummary { min-height:44px; padding:10px; border-radius:12px; background:var(--gfx-card,#FFFDF5); }\nlabel { min-height:44px; display:flex; align-items:center; gap:10px; cursor:pointer; }\ninput[type=checkbox] { width:24px; height:24px; accent-color:var(--gfx-accent,#F0763A); flex:none; }\n#detector-status { margin:8px 0; font-size:13px; }\n#arrival { display:flex; flex-wrap:wrap; align-items:center; gap:8px; padding:8px; background:var(--gfx-pick,#FFE17A); border-radius:12px; flex:none; }\n#arrival span { margin-right:auto; }\n#toast { position:fixed; right:12px; bottom:12px; padding:12px 20px; border:2px solid var(--gfx-line,#6B4528); border-radius:14px; background:var(--gfx-card,#FFFDF5); }\n#games { flex:1; min-height:180px; overflow:auto; }\n:host([data-anywhere-game]),:host([data-anywhere-game][data-game-large]) { position:relative; inset:auto; display:block; width:100%; height:100%; min-height:180px; pointer-events:auto; container-type:size; }\n.gfx-load-games { font-family:system-ui,\"Malgun Gothic\",sans-serif; font-size:15px; }\n.gfx-load-games button { min-width:44px; min-height:44px; }\n:host([data-anywhere-game]) .gfx-load-games { --room:max(220px,calc(100cqh - 180px)); height:100%; }\n:host([data-anywhere-game]) .gfx-game-content { min-width:0; }\n.gfx-game-stage { overflow:auto; padding:4px 4px 10px; }\n.gfx-game-board:is([data-kind=mines],[data-kind=fruits],[data-kind=pop],[data-kind=memory],[data-kind=slide],[data-kind=lights],[data-kind=merge]) { min-width:calc(var(--cols) * 48px + 8px); }\n.gfx-game-pad { grid-template-columns:repeat(3,44px); }\n.gfx-game-board[data-kind=shop] .gfx-shop-shelf { grid-template-columns:repeat(4,minmax(44px,1fr)); }\n:host([data-anywhere-game]) .gfx-game-utils button:first-child { display:none; }\n@media (max-width:600px) {\n  #panel { padding:8px; gap:6px; }\n  .gfx-load-games { flex-direction:column; align-items:stretch; gap:8px; }\n  .gfx-game-nav { flex:none; display:flex; flex-direction:row; flex-wrap:nowrap; justify-content:flex-start; overflow:auto; width:100%; max-height:none; padding:6px; gap:6px; }\n  .gfx-game-tab { flex:none; min-width:76px; }\n  .gfx-game-utils { flex:none; }\n  .gfx-game-content { flex:none; width:100%; padding:8px; max-height:none; overflow:visible; }\n  .gfx-game-tools { justify-content:flex-start; }\n  .gfx-game-levels { flex-wrap:wrap; }\n  :host([data-anywhere-game]) .gfx-load-games { height:auto; }\n  .gfx-game-board[data-kind=shop] { width:100%; }\n}\n@media (prefers-reduced-motion:reduce) { *,*::before,*::after { animation-duration:.01ms !important; transition:none !important; } }\n";
  const SETTINGS_KEY = `${APP_KEY}.settings`, POSITION_KEY = `${APP_KEY}.position`;
  const readLocal = key => { try { return JSON.parse(localStorage.getItem(key)); } catch { return null; } };
  const writeLocal = (key, value) => { try { localStorage.setItem(key, JSON.stringify(value)); } catch {} };
  const saved = readLocal(SETTINGS_KEY);
  const settings = { autoOpen: saved?.autoOpen !== false, autoClose: saved?.autoClose === true };
  const host = el('div'); host.id = APP_KEY;
  const shadow = host.attachShadow({ mode: 'open' });
  const style = el('style'); style.textContent = ADAPTER_CSS; shadow.append(style);
  const makeButton = (text, action, id) => {
    const button = el('button', '', text); button.type = 'button'; if (id) button.id = id;
    on(button, 'click', action); return button;
  };
  const launcher = makeButton('🎮', () => {
    if (suppressClick) { suppressClick = false; return; }
    panel.hidden ? openPanel(true) : closePanel();
  }, 'launcher');
  launcher.title = '미니게임 열기 · 위아래로 이동 · 길게 눌러 위치 초기화';
  launcher.setAttribute('aria-label', launcher.title);
  launcher.setAttribute('aria-controls', 'panel'); launcher.setAttribute('aria-expanded', 'false');
  const panel = el('section'); panel.id = 'panel'; panel.hidden = true; panel.tabIndex = -1;
  panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', '어디서나 미니게임');
  // Nonmodal by design: automatic opening must not steal the chat editor's focus.
  panel.setAttribute('aria-modal', 'false');
  const header = el('header'); header.append(el('strong', '', '🎮 어디서나 미니게임'));
  const close = makeButton('닫기', () => closePanel(), 'close'); header.append(close);
  const options = el('details'); options.id = 'settings';
  const summary = el('summary', '', '설정'); options.append(summary);
  function checkbox(key, label) {
    const row = el('label'), input = el('input'); input.type = 'checkbox'; input.id = key; input.checked = settings[key];
    on(input, 'change', () => {
      settings[key] = input.checked; writeLocal(SETTINGS_KEY, settings);
      if (key === 'autoOpen') { cancelOpening(); if (settings.autoOpen && streamingId) scheduleOpening(); }
    });
    row.append(input, el('span', '', label)); options.append(row);
  }
  checkbox('autoOpen', 'RP 생성 2.5초 뒤 자동 열기');
  checkbox('autoClose', '응답 도착 시 자동 닫기');
  options.append(makeButton('버튼 위치 초기화', resetPosition, 'reset-position'));
  const detectorStatus = el('p', '', '생성 감지 연결 중'); detectorStatus.id = 'detector-status'; options.append(detectorStatus);
  const arrival = el('div'); arrival.id = 'arrival'; arrival.hidden = true;
  arrival.append(el('span', '', '응답 도착'), makeButton('닫기', () => closePanel(), 'arrival-close'),
    makeButton('계속하기', () => { arrival.hidden = true; gameWrap?.shadowRoot.querySelector('.gfx-game-board')?.focus({ preventScroll: true }); }, 'continue'));
  const games = el('div'); games.id = 'games';
  panel.append(header, options, arrival, games);
  const toast = el('div'); toast.id = 'toast'; toast.hidden = true; toast.setAttribute('role', 'status'); toast.setAttribute('aria-live', 'polite');
  shadow.append(launcher, panel, toast); document.body.append(host);
  let gameWrap = null, gamePanel = null, previousFocus = null, toastTimer = 0;
  function createGames(wrap, anywhere = false) {
    wrap.setAttribute('data-gfx-minigames', '');
    if (anywhere) wrap.setAttribute('data-anywhere-game', '');
    const root = wrap.attachShadow({ mode: 'open' }), css = el('style');
    css.textContent = CSS + '\n' + ADAPTER_CSS;
    root.append(css);
    const content = makeLoadingGames(wrap); root.append(content); return content;
  }
  function openPanel(manual = false) {
    if (disposed || !panel.hidden) return;
    previousFocus = focusedElement(); panel.hidden = false; launcher.setAttribute('aria-expanded', 'true');
    if (!gamePanel) {
      gameWrap = el('div'); games.append(gameWrap); gamePanel = createGames(gameWrap, true);
    } else {
      gamePanel.resume();
      // Inherited games focus their board on resume; restore focus for automatic opening.
      if (!manual && previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
    }
    syncTheme();
    if (manual) close.focus({ preventScroll: true });
  }
  function closePanel(restore = true) {
    cancelOpening();
    const hadFocus = host === document.activeElement;
    panel.hidden = true; arrival.hidden = true; launcher.setAttribute('aria-expanded', 'false');
    gamePanel?.pause();
    if (restore && hadFocus) (previousFocus?.isConnected ? previousFocus : launcher).focus({ preventScroll: true });
  }
  panel.addEventListener('keydown', event => {
    if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); closePanel(); }
  }, { signal: life.signal, capture: true });

  // Right-edge vertical movement only. Pointer cancellation and a long press never open the panel.
  let position = readLocal(POSITION_KEY), drag = null, holdTimer = 0, suppressClick = false;
  const edge = 12, size = 48;
  function clampY(y) { return Math.max(edge, Math.min(Number.isFinite(y) ? y : innerHeight * .6, Math.max(edge, innerHeight - size - edge))); }
  function place(y, save = false) {
    position = clampY(y); launcher.style.top = `${position}px`;
    if (save) writeLocal(POSITION_KEY, position);
  }
  function resetPosition() { place(innerHeight * .6, true); }
  place(position);
  on(window, 'resize', () => place(position, true));
  on(launcher, 'pointerdown', event => {
    if (event.button !== 0 || drag) return;
    suppressClick = false; drag = { id: event.pointerId, y: event.clientY, start: position, moved: false };
    launcher.setPointerCapture?.(event.pointerId);
    holdTimer = setTimeout(() => { if (drag && !drag.moved) { resetPosition(); suppressClick = true; drag.reset = true; } }, 700);
  });
  on(launcher, 'pointermove', event => {
    if (!drag || drag.id !== event.pointerId || drag.reset) return;
    if (Math.abs(event.clientY - drag.y) > 5) { drag.moved = true; clearTimeout(holdTimer); suppressClick = true; }
    if (drag.moved) { event.preventDefault(); place(drag.start + event.clientY - drag.y); }
  });
  function endDrag(event) {
    if (!drag || drag.id !== event.pointerId) return;
    clearTimeout(holdTimer);
    if (event.type !== 'pointerup') suppressClick = true;
    if (drag.moved) place(position, true);
    drag = null;
  }
  for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) on(launcher, type, endDrag);
  launcher.addEventListener('keydown', event => {
    if (event.key === 'Home') { event.preventDefault(); resetPosition(); }
    if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
      event.preventDefault(); place(position + (event.key === 'ArrowUp' ? -20 : 20), true);
    }
  }, { signal: life.signal });

  const palettes = {
    cream: ['#FFFDF5', '#6B4528', '#5A3A24', '#FFF4D9', '#FFE17A', '#F0763A'],
    berry: ['#FFF8FA', '#7A2E45', '#6A2E45', '#FFE4EC', '#FFD3E0', '#F2557F'],
    mint: ['#F6FFFA', '#4A3424', '#3E2C1E', '#E1F7EC', '#BFEFD8', '#3FA57A'],
    lavender: ['#FCFBFF', '#4F3F85', '#43356F', '#EFE8FF', '#DCD0FF', '#8C6CF0'],
    night: ['#2A2E4D', '#14162A', '#F0EEFF', '#22253D', '#4A4F80', '#FFB84D'],
  };
  function syncTheme() {
    const source = [...document.querySelectorAll('[data-gfx-preset]')].find(node => node !== host)
      || document.querySelector(HOST_TAG) || document.documentElement;
    const preset = source.getAttribute('data-gfx-preset') || '';
    if (host.getAttribute('data-gfx-preset') !== preset) host.setAttribute('data-gfx-preset', preset);
    const computed = getComputedStyle(source);
    ['card', 'line', 'text', 'ink', 'pick', 'accent'].forEach((name, index) => {
      const key = `--gfx-${name}`, value = computed.getPropertyValue(key).trim();
      const color = value && CSSSupportsColor(value) ? value : (palettes[preset] || palettes.cream)[index];
      if (host.style.getPropertyValue(key) !== color) host.style.setProperty(key, color);
    });
    gamePanel?.retheme();
    mounted?.wrap.shadowRoot.querySelector('.gfx-load-games')?.retheme();
  }
  function CSSSupportsColor(value) { return window.CSS?.supports ? window.CSS.supports('color', value) : /^#[0-9a-f]{3,8}$/i.test(value); }

  // Preserve upstream Forge rules: 2.5 s uninterrupted generation, skip boot/cached chapters,
  // move the existing game into a replaced .forge-center, restore its positioning on release.
  let mounted = null, forgeSince = null, forgeEnabled = true;
  function releaseForge(remove = true) {
    if (!mounted) return;
    if (remove) { mounted.content.dispose(); mounted.wrap.remove(); }
    mounted.center.style.position = mounted.position; mounted = null;
  }
  function generating(h) {
    if (!writingLoad(h) || h._boot === 'idle' || h._boot === 'loading') return false;
    try { if (h._hudView === 'forge' && typeof h._chapterWritten === 'function' && h._chapterWritten()) return false; } catch {}
    return true;
  }
  function syncForge() {
    if (disposed || !forgeEnabled) return;
    const h = document.querySelector(HOST_TAG), now = performance.now();
    if (generating(h)) { if (forgeSince === null) forgeSince = now; } else forgeSince = null;
    const center = forgeSince !== null && (mounted || now - forgeSince >= 2500) ? h.shadowRoot.querySelector('.forge-center') : null;
    if (!center) { releaseForge(); return; }
    if (mounted && mounted.center !== center) {
      const { wrap, content } = mounted; releaseForge(false);
      mounted = { center, wrap, content, position: center.style.position };
    }
    if (!mounted) {
      const wrap = el('div'); const content = createGames(wrap);
      mounted = { center, wrap, content, position: center.style.position };
    }
    if (getComputedStyle(center).position === 'static') center.style.position = 'relative';
    if (mounted.wrap.parentNode !== center) { center.append(mounted.wrap); mounted.content.retheme(); }
  }
  // The original calls window[KEY]() before installing itself. Relinquish only Forge then;
  // the independent anywhere UI survives either installation order, with one Forge owner.
  function relinquishForge() { forgeEnabled = false; releaseForge(); }
  if (typeof window[KEY] === 'function') { try { window[KEY](); } catch {} }
  window[KEY] = relinquishForge;

  let streamingId = null, openingTimer = 0, startedAt = 0;
  function cancelOpening() { clearTimeout(openingTimer); openingTimer = 0; }
  function scheduleOpening() {
    cancelOpening();
    if (!settings.autoOpen || !streamingId) return;
    const id = streamingId;
    openingTimer = setTimeout(() => {
      openingTimer = 0;
      if (streamingId === id && settings.autoOpen) openPanel(false);
    }, Math.max(0, 2500 - (performance.now() - startedAt)));
  }
  function responseArrived() {
    toast.textContent = '응답 도착'; toast.hidden = false; clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toast.hidden = true; }, 5000);
    if (!panel.hidden) {
      if (settings.autoClose) closePanel(); else arrival.hidden = false;
    }
  }
  function setGeneration(id, complete = true) {
    if (id === streamingId) return;
    const old = streamingId; streamingId = id; cancelOpening();
    if (old && !id && complete) responseArrived();
    if (id) { startedAt = performance.now(); arrival.hidden = true; scheduleOpening(); }
  }
  let store = null, unsubscribe = null, pollController = null, pollingId = null;
  function readState(candidate = globalThis.__MARINARA_HOST__?.stores?.chat) {
    try { return candidate?.getState?.() || null; } catch { return null; }
  }
  function activeChatId() {
    const state = readState();
    if (typeof state?.activeChatId === 'string' && state.activeChatId) return state.activeChatId;
    // URL fallback is conservative: explicit chatId/chat query or /chat(s)/:id (also hash routes).
    try {
      const url = new URL(location.href), hash = url.hash.slice(1);
      const route = new URL(hash.startsWith('/') ? hash : '/', url.origin);
      return url.searchParams.get('chatId') || url.searchParams.get('chat') || route.searchParams.get('chatId')
        || decodeURIComponent((url.pathname.match(/\/(?:chat|chats)\/([^/]+)/) || route.pathname.match(/\/(?:chat|chats)\/([^/]+)/))?.[1] || '') || null;
    } catch { return null; }
  }
  function consumeState(state) {
    if (!state || typeof state.isStreaming !== 'boolean') return;
    // marinara-engine-ref/packages/client/src/stores/chat.store.ts:199-201,505-517:
    // isStreaming and streamingChatId are updated together; a stop clears streamingChatId.
    const id = state.isStreaming ? (state.streamingChatId || state.activeChatId) : null;
    setGeneration(typeof id === 'string' && id ? id : null);
  }
  function abortPoll() { pollController?.abort(); pollController = null; }
  function connectStore() {
    // packages/client/src/lib/marinara-host.ts:52-55,87-103 exposes the Zustand store itself.
    const candidate = globalThis.__MARINARA_HOST__?.stores?.chat;
    if (candidate === store && unsubscribe) return true;
    if (unsubscribe) { unsubscribe(); unsubscribe = null; store = null; setGeneration(null, false); }
    if (typeof candidate?.subscribe !== 'function' || typeof readState(candidate)?.isStreaming !== 'boolean') return false;
    try {
      const off = candidate.subscribe(consumeState);
      if (typeof off !== 'function') return false;
      unsubscribe = off; store = candidate; abortPoll(); pollingId = null;
      detectorStatus.textContent = '생성 감지: 채팅 스토어'; consumeState(readState(store)); return true;
    } catch { return false; }
  }
  async function poll() {
    if (disposed || connectStore()) return;
    const id = activeChatId();
    if (id !== pollingId) { abortPoll(); pollingId = id; setGeneration(null, false); }
    if (!id || typeof MARINARA?.fetch !== 'function') {
      detectorStatus.textContent = '생성 감지 대기: 활성 채팅 정보가 필요합니다'; return;
    }
    if (pollController) return; // Never overlap requests; navigation can cancel the old one.
    const controller = new AbortController(); pollController = controller;
    const deadline = setTimeout(() => controller.abort(), 5000);
    detectorStatus.textContent = '생성 감지: 1초 간격 상태 확인';
    try {
      // PersonalExtensionInjector.tsx:317 supplies authorized same-origin marinara.fetch.
      // packages/server/src/routes/generate.routes.ts:14860-14867 returns { active, translating }.
      const response = await MARINARA.fetch(`/api/generate/status/${encodeURIComponent(id)}`, { method: 'GET', signal: controller.signal });
      if (!response.ok) throw new Error('status unavailable');
      const status = await response.json();
      if (disposed || controller.signal.aborted || store || id !== activeChatId()) return;
      if (typeof status.active !== 'boolean') throw new Error('invalid status');
      setGeneration(status.active ? id : null);
    } catch {
      if (!disposed && !controller.signal.aborted && !store) detectorStatus.textContent = '생성 상태를 확인할 수 없어 재시도합니다';
      // A failed request is not evidence of generation completion.
    } finally {
      clearTimeout(deadline); if (pollController === controller) pollController = null;
    }
  }
  // PersonalExtensionInjector.tsx:339-342 registers cleanup on disable/reload/removal.
  function dispose() {
    if (disposed) return;
    disposed = true; cancelOpening(); abortPoll(); unsubscribe?.(); unsubscribe = null;
    life.abort(); lifetime.dispose(); gamePanel?.dispose(); releaseForge(); host.remove();
    if (window[KEY] === relinquishForge) delete window[KEY];
    if (window[APP_KEY]?.dispose === dispose) delete window[APP_KEY];
  }
  window[APP_KEY] = { dispose };
  MARINARA?.onCleanup?.(dispose);
  setInterval(syncForge, 200); syncForge();
  setInterval(() => { syncTheme(); void poll(); }, 1000); syncTheme(); void poll();

})();
